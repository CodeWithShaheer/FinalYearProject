"""
gui/common/widgets.py
Reusable widgets for SLEMS dashboards.

v2.1 — Fixed human_size import + Upload button object name.
Existing widgets UNCHANGED. NEW widgets added:
  - SectionHeader
  - ReadinessChip
  - SecurityOptionRow
  - SearchableCheckList
  - TimerBox
  - FileUploadRow
  - AddCourseDialog
"""
from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QColor, QFont
from PyQt5.QtWidgets import (
    QWidget, QLabel, QVBoxLayout, QHBoxLayout, QFrame,
    QGraphicsDropShadowEffect, QDialog, QPushButton, QApplication,
    QProgressBar, QLineEdit, QCheckBox, QScrollArea, QSizePolicy,
)

from gui.common import theme
import os


def _drop_shadow(blur=26, y_offset=5, color=QColor(16, 24, 40, 55)):
    eff = QGraphicsDropShadowEffect()
    eff.setBlurRadius(blur)
    eff.setOffset(0, y_offset)
    eff.setColor(color)
    return eff


# ===========================================================================
# EXISTING WIDGETS (UNCHANGED)
# ===========================================================================

class StatusPill(QLabel):
    """A colored pill/badge showing status."""
    def __init__(self, text, color, parent=None):
        super().__init__(text, parent)
        self.setStyleSheet(f"""
            background: {color};
            color: white;
            font-size: 12px;
            font-weight: 700;
            border-radius: 10px;
            padding: 4px 12px;
        """)
        self.setAlignment(Qt.AlignCenter)


class StudentFullscreenDialog(QDialog):
    """Fullscreen dialog shown when a student tile is clicked."""

    def __init__(self, student_id: str, name: str, status: str, roll_no: str = "", parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Student: {name}")
        self.setWindowFlags(Qt.Window | Qt.WindowMaximizeButtonHint | Qt.WindowCloseButtonHint)
        self.showMaximized()
        self.setStyleSheet(f"background: {theme.NAVY_DARK};")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(50, 50, 50, 50)
        layout.setSpacing(24)

        header = QHBoxLayout()
        title = QLabel(name)
        title.setStyleSheet("color: white; font-size: 38px; font-weight: 800;")
        header.addWidget(title)

        info_col = QVBoxLayout()
        id_lbl = QLabel(f"ID: {student_id}")
        id_lbl.setStyleSheet(f"color: {theme.GOLD_LIGHT}; font-size: 20px; font-weight: 600;")
        info_col.addWidget(id_lbl)
        if roll_no:
            roll_lbl = QLabel(f"Roll: {roll_no}")
            roll_lbl.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 18px;")
            info_col.addWidget(roll_lbl)
        header.addLayout(info_col)
        header.addStretch()

        status_badge = QLabel(theme.STATUS_LABELS.get(status, status))
        status_badge.setStyleSheet(
            f"background: {theme.STATUS_COLORS.get(status, theme.STATUS_NORMAL)}; color: white; "
            f"font-size: 18px; font-weight: 700; border-radius: 14px; padding: 8px 22px;"
        )
        header.addWidget(status_badge)

        close_btn = QPushButton("Close")
        close_btn.setFixedHeight(50)
        close_btn.setStyleSheet(f"""
            QPushButton {{
                background: {theme.STATUS_BEHAVIORAL};
                color: white;
                border: none;
                border-radius: 10px;
                padding: 10px 28px;
                font-size: 16px;
                font-weight: 700;
            }}
            QPushButton:hover {{ background: #C43030; }}
        """)
        close_btn.setCursor(Qt.PointingHandCursor)
        close_btn.clicked.connect(self.close)
        header.addWidget(close_btn)
        layout.addLayout(header)

        video_area = QFrame()
        video_area.setStyleSheet(f"""
            background: #050a14;
            border-radius: 20px;
            border: 4px solid {theme.STATUS_COLORS.get(status, theme.STATUS_NORMAL)};
        """)
        video_layout = QVBoxLayout(video_area)
        video_layout.setAlignment(Qt.AlignCenter)

        initials = QLabel(self._initials(name))
        initials.setStyleSheet(
            f"color: {theme.TEXT_ON_NAVY}; font-size: 100px; font-weight: 700; "
            f"background: {theme.NAVY}; border-radius: 80px;"
        )
        initials.setFixedSize(160, 160)
        initials.setAlignment(Qt.AlignCenter)
        video_layout.addWidget(initials, alignment=Qt.AlignCenter)

        placeholder = QLabel("Live Video Feed - WebRTC Placeholder")
        placeholder.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 20px; margin-top: 20px;")
        placeholder.setAlignment(Qt.AlignCenter)
        video_layout.addWidget(placeholder, alignment=Qt.AlignCenter)

        layout.addWidget(video_area, stretch=1)

        info_bar = QHBoxLayout()
        info_items = [
            ("Camera", "Active"),
            ("Microphone", "Muted"),
            ("Screen", "Sharing"),
            ("Session Time", "45 min remaining"),
        ]
        for label_text, value in info_items:
            card = QFrame()
            card.setStyleSheet(f"background: {theme.NAVY}; border-radius: 12px;")
            c_layout = QVBoxLayout(card)
            c_layout.setContentsMargins(20, 16, 20, 16)
            c_layout.setSpacing(6)

            lbl = QLabel(label_text)
            lbl.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 14px; font-weight: 600;")
            c_layout.addWidget(lbl)

            val = QLabel(value)
            val.setStyleSheet("color: white; font-size: 18px; font-weight: 700;")
            c_layout.addWidget(val)

            info_bar.addWidget(card)

        layout.addLayout(info_bar)

    @staticmethod
    def _initials(name: str) -> str:
        parts = name.split()
        return "".join(p[0] for p in parts[:2]).upper()


class StudentTile(QWidget):
    """A single student's live tile in the monitoring grid."""
    clicked = pyqtSignal(str)

    def __init__(self, student_id: str, name: str, status: str = "normal", roll_no: str = "", parent=None):
        super().__init__(parent)
        self.student_id = student_id
        self.name = name
        self.status = status
        self.roll_no = roll_no

        self.setObjectName("studentTile")
        self.setFixedSize(280, 260)
        self.setProperty("status", status)
        self.setGraphicsEffect(_drop_shadow())
        self.setCursor(Qt.PointingHandCursor)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        video = QFrame()
        video.setObjectName("tileVideoArea")
        video.setFixedHeight(170)
        video_layout = QVBoxLayout(video)
        video_layout.setAlignment(Qt.AlignCenter)
        initials = QLabel(self._initials(name))
        initials.setStyleSheet(
            f"color: {theme.TEXT_ON_NAVY}; font-size: 40px; font-weight: 700; "
            f"background: {theme.NAVY}; border-radius: 40px;"
        )
        initials.setFixedSize(80, 80)
        initials.setAlignment(Qt.AlignCenter)
        video_layout.addWidget(initials, alignment=Qt.AlignCenter)
        outer.addWidget(video)

        footer = QWidget()
        footer_layout = QVBoxLayout(footer)
        footer_layout.setContentsMargins(14, 12, 14, 12)
        footer_layout.setSpacing(4)

        top_row = QHBoxLayout()
        name_lbl = QLabel(name)
        name_lbl.setObjectName("tileName")
        top_row.addWidget(name_lbl)
        top_row.addStretch()
        badge = QLabel(theme.STATUS_LABELS.get(status, status))
        badge.setObjectName("tileStatusBadge")
        badge.setStyleSheet(
            f"background: {theme.STATUS_COLORS.get(status, theme.STATUS_NORMAL)}; color: white; "
            f"font-size: 13px; font-weight: 700; border-radius: 10px; padding: 4px 10px;"
        )
        top_row.addWidget(badge)
        footer_layout.addLayout(top_row)

        id_row = QHBoxLayout()
        id_lbl = QLabel(student_id)
        id_lbl.setObjectName("tileId")
        id_row.addWidget(id_lbl)
        if roll_no:
            roll_lbl = QLabel(f"Roll: {roll_no}")
            roll_lbl.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 13px; font-weight: 500;")
            id_row.addWidget(roll_lbl)
        id_row.addStretch()
        footer_layout.addLayout(id_row)

        outer.addWidget(footer)

    @staticmethod
    def _initials(name: str) -> str:
        parts = name.split()
        return "".join(p[0] for p in parts[:2]).upper()

    def set_status(self, status: str):
        self.status = status
        self.setProperty("status", status)
        self.style().unpolish(self)
        self.style().polish(self)

    def mousePressEvent(self, event):
        self.clicked.emit(self.student_id)
        dialog = StudentFullscreenDialog(self.student_id, self.name, self.status, self.roll_no, self)
        dialog.exec_()
        super().mousePressEvent(event)


class NotificationItem(QWidget):
    """A single alert row shown in the live notification feed."""

    def __init__(self, time_str: str, student: str, level: str, message: str, roll_no: str = "", parent=None):
        super().__init__(parent)
        self.setObjectName("notifItem")
        self.setProperty("level", level)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(6)

        top = QHBoxLayout()
        student_text = student
        if roll_no:
            student_text = f"{student} (Roll: {roll_no})"
        text_lbl = QLabel(f"{student_text} - {message}")
        text_lbl.setObjectName("notifText")
        text_lbl.setWordWrap(True)
        top.addWidget(text_lbl)
        layout.addLayout(top)

        time_lbl = QLabel(time_str)
        time_lbl.setObjectName("notifTime")
        layout.addWidget(time_lbl)


class StatCard(QFrame):
    """A statistics card with icon, label and value."""
    def __init__(self, label, value, card_type="total", parent=None):
        super().__init__(parent)
        card_ids = {
            "total": "statCardTotal",
            "submitted": "statCardSubmitted",
            "remaining": "statCardRemaining",
            "pending": "statCardPending",
        }
        self.setObjectName(card_ids.get(card_type, "statCard"))
        self.setMinimumHeight(140)
        self.setGraphicsEffect(_drop_shadow(blur=20, y_offset=4))

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(8)

        self.label = QLabel(label)
        self.label.setObjectName("statLabel")
        if card_type in ["total", "submitted", "remaining", "pending"]:
            self.label.setStyleSheet("color: rgba(255,255,255,0.85); font-size: 14px; font-weight: 600;")
        layout.addWidget(self.label)

        self.value = QLabel(str(value))
        if card_type in ["total", "submitted", "remaining", "pending"]:
            self.value.setStyleSheet("color: white; font-size: 36px; font-weight: 800;")
        else:
            self.value.setObjectName("statValueDark")
        layout.addWidget(self.value)

        layout.addStretch()


class SubmissionStatusRow(QWidget):
    """A row showing student submission status."""
    def __init__(self, name, roll_no, status, submitted_at=None, parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(16)

        initials = QLabel("".join(p[0] for p in name.split()[:2]).upper())
        initials.setStyleSheet(f"""
            background: {theme.NAVY};
            color: white;
            font-size: 16px;
            font-weight: 700;
            border-radius: 20px;
            padding: 4px;
        """)
        initials.setFixedSize(40, 40)
        initials.setAlignment(Qt.AlignCenter)
        layout.addWidget(initials)

        info_col = QVBoxLayout()
        info_col.setSpacing(2)
        name_lbl = QLabel(name)
        name_lbl.setStyleSheet(f"font-size: 16px; font-weight: 700; color: {theme.TEXT_PRIMARY};")
        info_col.addWidget(name_lbl)
        roll_lbl = QLabel(f"Roll: {roll_no}")
        roll_lbl.setStyleSheet(f"font-size: 13px; color: {theme.TEXT_SECONDARY};")
        info_col.addWidget(roll_lbl)
        layout.addLayout(info_col, stretch=1)

        if status == "submitted":
            status_lbl = StatusPill("Submitted", theme.STATUS_NORMAL)
            if submitted_at:
                time_lbl = QLabel(submitted_at)
                time_lbl.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 12px;")
                layout.addWidget(time_lbl)
        else:
            status_lbl = StatusPill("Not Submitted", theme.STATUS_BEHAVIORAL)
        layout.addWidget(status_lbl)


# ===========================================================================
# MOCK DATA (Phase 15 mein remove hoga)
# ===========================================================================

MOCK_STUDENTS = [
    {"id": "FSD-FL-201", "name": "Ali Raza", "status": "normal", "roll_no": "21F-1234"},
    {"id": "FSD-FL-202", "name": "Sara Khan", "status": "normal", "roll_no": "21F-1235"},
    {"id": "FSD-FL-203", "name": "Hamza Iqbal", "status": "behavioral", "roll_no": "21F-1236"},
    {"id": "FSD-FL-204", "name": "Ayesha Tariq", "status": "normal", "roll_no": "21F-1237"},
    {"id": "FSD-FL-205", "name": "Bilal Ahmed", "status": "service", "roll_no": "21F-1238"},
    {"id": "FSD-FL-206", "name": "Mahnoor Fatima", "status": "normal", "roll_no": "21F-1239"},
    {"id": "FSD-FL-207", "name": "Usman Ghani", "status": "disconnected", "roll_no": "21F-1240"},
    {"id": "FSD-FL-208", "name": "Zara Sheikh", "status": "normal", "roll_no": "21F-1241"},
    {"id": "FSD-FL-209", "name": "Fahad Malik", "status": "normal", "roll_no": "21F-1242"},
    {"id": "FSD-FL-210", "name": "Kinza Aslam", "status": "behavioral", "roll_no": "21F-1243"},
    {"id": "FSD-FL-211", "name": "Omar Farooq", "status": "normal", "roll_no": "21F-1244"},
    {"id": "FSD-FL-212", "name": "Iqra Yousaf", "status": "normal", "roll_no": "21F-1245"},
]

MOCK_NOTIFICATIONS = [
    ("10:42:03", "Hamza Iqbal", "behavioral", "Looking away from screen repeatedly", "21F-1236"),
    ("10:41:20", "Bilal Ahmed", "service", "Attempted to open chatgpt.com - blocked", "21F-1238"),
    ("10:39:55", "Kinza Aslam", "behavioral", "Mobile phone detected on desk", "21F-1243"),
    ("10:37:10", "Bilal Ahmed", "service", "Blocked process: WhatsApp.exe", "21F-1238"),
    ("10:33:44", "Usman Ghani", "service", "Connection lost - attempting reconnect", "21F-1240"),
]


# ===========================================================================
# NEW WIDGETS — Session Control redesign (v2.0)
# ===========================================================================

class SectionHeader(QWidget):
    """
    Numbered section header for Session Control page.
    Example:  (①)  EXAM DETAILS
    """
    def __init__(self, number: int, title: str, parent=None):
        super().__init__(parent)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(10)

        badge = QLabel(self._circled_number(number))
        badge.setObjectName("sectionBadge")
        badge.setAlignment(Qt.AlignCenter)
        badge.setFixedSize(26, 26)
        badge.setStyleSheet(f"""
            background: {theme.NAVY};
            color: white;
            font-size: 14px;
            font-weight: 700;
            border-radius: 13px;
        """)
        layout.addWidget(badge)

        title_lbl = QLabel(title.upper())
        title_lbl.setObjectName("sectionHeader")
        title_lbl.setStyleSheet(f"""
            font-size: 13px;
            font-weight: 800;
            color: {theme.NAVY_DARK};
            letter-spacing: 1px;
        """)
        layout.addWidget(title_lbl)
        layout.addStretch()

    @staticmethod
    def _circled_number(n: int) -> str:
        circles = {1: "①", 2: "②", 3: "③", 4: "④", 5: "⑤",
                   6: "⑥", 7: "⑦", 8: "⑧", 9: "⑨", 10: "⑩"}
        return circles.get(n, str(n))


class ReadinessChip(QWidget):
    """
    Small chip showing readiness state.
    Example:  [✓ Course selected]  (green)  or  [✗ Restrictions]  (gray)
    """
    def __init__(self, label: str, ok: bool = False, parent=None):
        super().__init__(parent)
        self._label_text = label
        self._ok = ok
        self._build()
        self.set_ok(ok)

    def _build(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 8, 16, 8)
        layout.setSpacing(8)

        self.icon_lbl = QLabel()
        self.icon_lbl.setFixedSize(20, 20)
        self.icon_lbl.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.icon_lbl)

        self.text_lbl = QLabel(self._label_text)
        self.text_lbl.setStyleSheet("font-size: 13px; font-weight: 600; background: transparent;")
        layout.addWidget(self.text_lbl)

        self.setStyleSheet(f"""
            ReadinessChip {{
                background: {theme.BG};
                border: 1px solid {theme.BORDER};
                border-radius: 16px;
            }}
        """)

    def set_ok(self, ok: bool):
        self._ok = ok
        if ok:
            self.icon_lbl.setText("✓")
            self.icon_lbl.setStyleSheet(
                f"color: white; background: {theme.STATUS_NORMAL}; "
                f"border-radius: 10px; font-size: 12px; font-weight: 700;"
            )
            self.text_lbl.setStyleSheet(
                f"font-size: 13px; font-weight: 700; color: {theme.STATUS_NORMAL}; background: transparent;"
            )
            self.setStyleSheet(
                f"ReadinessChip {{ background: #E7F6EC; border: 1px solid {theme.STATUS_NORMAL}; "
                f"border-radius: 16px; }}"
            )
        else:
            self.icon_lbl.setText("✗")
            self.icon_lbl.setStyleSheet(
                f"color: white; background: {theme.STATUS_DISCONNECTED}; "
                f"border-radius: 10px; font-size: 12px; font-weight: 700;"
            )
            self.text_lbl.setStyleSheet(
                f"font-size: 13px; font-weight: 600; color: {theme.TEXT_SECONDARY}; background: transparent;"
            )
            self.setStyleSheet(
                f"ReadinessChip {{ background: {theme.BG}; border: 1px solid {theme.BORDER}; "
                f"border-radius: 16px; }}"
            )


class SecurityOptionRow(QWidget):
    """A single checkbox row for Security Options panel."""
    def __init__(self, key: str, label: str, checked: bool = True, parent=None):
        super().__init__(parent)
        self.key = key

        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 4, 0, 4)
        layout.setSpacing(10)

        self.checkbox = QCheckBox(label)
        self.checkbox.setChecked(checked)
        self.checkbox.setStyleSheet(f"""
            QCheckBox {{
                font-size: 14px;
                color: {theme.TEXT_PRIMARY};
                spacing: 8px;
            }}
            QCheckBox::indicator {{
                width: 18px;
                height: 18px;
                border-radius: 4px;
                border: 2px solid {theme.BORDER};
            }}
            QCheckBox::indicator:checked {{
                background: {theme.NAVY};
                border: 2px solid {theme.NAVY};
            }}
        """)
        layout.addWidget(self.checkbox)
        layout.addStretch()

    def is_checked(self) -> bool:
        return self.checkbox.isChecked()

    def set_checked(self, v: bool):
        self.checkbox.setChecked(v)


class SearchableCheckList(QWidget):
    """
    Search + Select All / Clear All + scrollable checkbox list.
    Used for Blocked Applications and Blocked Websites.
    Emits `selection_changed` when any checkbox changes.
    """
    selection_changed = pyqtSignal()

    def __init__(self, items, default_checked=None, parent=None):
        super().__init__(parent)
        self._items = list(items)
        self._default_checked = set(default_checked or [])
        self._checkboxes = {}  # name -> QCheckBox

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        search_row = QHBoxLayout()
        search_row.setSpacing(6)

        self.search_box = QLineEdit()
        self.search_box.setObjectName("searchBox")
        self.search_box.setPlaceholderText("Search…")
        self.search_box.setMinimumHeight(32)
        self.search_box.textChanged.connect(self._apply_search_filter)
        search_row.addWidget(self.search_box, stretch=1)

        self.select_all_btn = QPushButton("Select All")
        self.select_all_btn.setObjectName("selectAllBtn")
        self.select_all_btn.setCursor(Qt.PointingHandCursor)
        self.select_all_btn.clicked.connect(self._select_all)
        search_row.addWidget(self.select_all_btn)

        self.clear_all_btn = QPushButton("Clear All")
        self.clear_all_btn.setObjectName("selectAllBtn")
        self.clear_all_btn.setCursor(Qt.PointingHandCursor)
        self.clear_all_btn.clicked.connect(self._clear_all)
        search_row.addWidget(self.clear_all_btn)

        layout.addLayout(search_row)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("background: transparent; border: none;")
        scroll.setMinimumHeight(180)

        host = QWidget()
        host.setStyleSheet("background: transparent;")
        self._host_layout = QVBoxLayout(host)
        self._host_layout.setContentsMargins(4, 4, 4, 4)
        self._host_layout.setSpacing(4)
        self._host_layout.setAlignment(Qt.AlignTop)

        for name in self._items:
            cb = QCheckBox(name)
            cb.setStyleSheet(f"""
                QCheckBox {{
                    font-size: 13px;
                    color: {theme.TEXT_PRIMARY};
                    spacing: 8px;
                    padding: 2px 0;
                }}
                QCheckBox::indicator {{
                    width: 16px;
                    height: 16px;
                    border-radius: 4px;
                    border: 2px solid {theme.BORDER};
                }}
                QCheckBox::indicator:checked {{
                    background: {theme.NAVY};
                    border: 2px solid {theme.NAVY};
                }}
            """)
            if name in self._default_checked:
                cb.setChecked(True)
            cb.stateChanged.connect(lambda _: self.selection_changed.emit())
            self._checkboxes[name] = cb
            self._host_layout.addWidget(cb)

        self._host_layout.addStretch()
        scroll.setWidget(host)
        layout.addWidget(scroll)

    def _apply_search_filter(self, text: str):
        text = (text or "").strip().lower()
        for name, cb in self._checkboxes.items():
            cb.setVisible(not text or text in name.lower())

    def _select_all(self):
        for name, cb in self._checkboxes.items():
            if cb.isVisible():
                cb.setChecked(True)
        self.selection_changed.emit()

    def _clear_all(self):
        for name, cb in self._checkboxes.items():
            if cb.isVisible():
                cb.setChecked(False)
        self.selection_changed.emit()

    def get_selected(self) -> list:
        return [name for name, cb in self._checkboxes.items() if cb.isChecked()]

    def count_selected(self) -> int:
        return sum(1 for cb in self._checkboxes.values() if cb.isChecked())

    def _find(self, name: str):
        low = (name or "").strip().lower()
        for key in self._checkboxes:
            if key.lower() == low:
                return key
        return None

    def add_item(self, name: str, checked: bool = False):
        """Append an entry that is not in the original list (used by presets)."""
        cb = QCheckBox(name)
        any_cb = next(iter(self._checkboxes.values()), None)
        if any_cb is not None:
            cb.setStyleSheet(any_cb.styleSheet())
        cb.setChecked(checked)
        cb.stateChanged.connect(lambda _: self.selection_changed.emit())
        self._checkboxes[name] = cb
        self._host_layout.insertWidget(self._host_layout.count() - 1, cb)

    def set_checked(self, names, checked: bool = True):
        """Tick / untick the given names (case-insensitive); unknown names are added."""
        self.blockSignals(True)
        for n in names:
            key = self._find(n)
            if key is None:
                if checked:
                    self.add_item(n, True)
            else:
                self._checkboxes[key].setChecked(checked)
        self.blockSignals(False)
        self.selection_changed.emit()

    def all_checked(self, names) -> bool:
        """True when every given name exists and is ticked (used to toggle preset buttons)."""
        for n in names:
            key = self._find(n)
            if key is None or not self._checkboxes[key].isChecked():
                return False
        return True


class TimerBox(QFrame):
    """
    Top-right timer box:  "EXAM TIME REMAINING  01:13:33 (hh:mm:ss)"
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("timerBox")
        self.setFixedWidth(240)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 12, 18, 12)
        layout.setSpacing(2)

        self.label = QLabel("EXAM TIME REMAINING")
        self.label.setObjectName("timerBoxLabel")
        self.label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.label)

        self.value = QLabel("00:00:00")
        self.value.setObjectName("timerBoxValue")
        self.value.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.value)

        self.sub_label = QLabel("(hh:mm:ss)")
        self.sub_label.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 10px;")
        self.sub_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.sub_label)

    def set_time(self, seconds: int):
        from utils.helpers import format_hms
        self.value.setText(format_hms(seconds))


class FileUploadRow(QFrame):
    """
    Exam paper upload row:  [PDF] filename.pdf  2.34 MB   [Upload/Replace]
    """
    file_selected = pyqtSignal(str)   # emits file path when selected

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("fileUploadRow")
        self._file_path = ""

        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(10)

        self.icon_lbl = QLabel("📄")
        self.icon_lbl.setStyleSheet("font-size: 22px;")
        layout.addWidget(self.icon_lbl)

        info_col = QVBoxLayout()
        info_col.setSpacing(2)
        self.name_lbl = QLabel("No file selected")
        self.name_lbl.setObjectName("fileUploadName")
        info_col.addWidget(self.name_lbl)
        self.size_lbl = QLabel("—")
        self.size_lbl.setObjectName("fileUploadSize")
        info_col.addWidget(self.size_lbl)
        layout.addLayout(info_col, stretch=1)

        self.btn = QPushButton("Upload")
        # ✅ FIXED: use uploadBtn (navy blue from theme)
        self.btn.setObjectName("uploadBtn")
        self.btn.setCursor(Qt.PointingHandCursor)
        self.btn.setMinimumHeight(34)
        self.btn.clicked.connect(self._on_click)
        layout.addWidget(self.btn)

    def _on_click(self):
        from PyQt5.QtWidgets import QFileDialog
        from config.settings import ALLOWED_EXAM_PAPER_EXTENSIONS
        exts = " ".join(f"*{e}" for e in ALLOWED_EXAM_PAPER_EXTENSIONS)
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Exam Paper", "",
            f"Documents ({exts});;All Files (*)"
        )
        if path:
            self.set_file(path)
            self.file_selected.emit(path)

    def set_file(self, path: str):
        # ✅ FIXED: removed the broken 'from utils.helpers import human_size' line
        self._file_path = path
        if not path:
            self.name_lbl.setText("No file selected")
            self.size_lbl.setText("—")
            self.btn.setText("Upload")
            return
        try:
            size_bytes = os.path.getsize(path)
        except OSError:
            size_bytes = 0
        self.name_lbl.setText(os.path.basename(path))
        self.size_lbl.setText(self._human_size(size_bytes))
        self.btn.setText("Replace")

    def get_file_path(self) -> str:
        return self._file_path

    def clear(self):
        self.set_file("")

    @staticmethod
    def _human_size(num_bytes: int) -> str:
        num = float(num_bytes)
        for unit in ("B", "KB", "MB", "GB"):
            if num < 1024.0:
                if unit == "B":
                    return f"{int(num)} {unit}"
                return f"{num:.2f} {unit}"
            num /= 1024.0
        return f"{num:.2f} TB"


class AddCourseDialog(QDialog):
    """
    Simple dialog to add a new course.
    Returns the new course name via .course_name after exec_() if accepted.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Add New Course")
        self.setModal(True)
        self.setFixedWidth(420)
        self.setStyleSheet(f"background: {theme.CARD_BG};")

        self.course_name = ""

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 22, 24, 22)
        layout.setSpacing(16)

        title = QLabel("Add New Course")
        title.setStyleSheet(f"font-size: 20px; font-weight: 800; color: {theme.NAVY_DARK};")
        layout.addWidget(title)

        subtitle = QLabel("Enter the course name. It will appear in the Course dropdown.")
        subtitle.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 13px;")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        self.input = QLineEdit()
        self.input.setPlaceholderText("e.g. Compiler Construction")
        self.input.setMinimumHeight(44)
        layout.addWidget(self.input)

        btn_row = QHBoxLayout()
        btn_row.addStretch()

        cancel_btn = QPushButton("Cancel")
        cancel_btn.setObjectName("ghostBtn")
        cancel_btn.setMinimumHeight(40)
        cancel_btn.setCursor(Qt.PointingHandCursor)
        cancel_btn.clicked.connect(self.reject)
        btn_row.addWidget(cancel_btn)

        save_btn = QPushButton("Save Course")
        save_btn.setObjectName("primaryBtn")
        save_btn.setMinimumHeight(40)
        save_btn.setCursor(Qt.PointingHandCursor)
        save_btn.clicked.connect(self._on_save)
        btn_row.addWidget(save_btn)

        layout.addLayout(btn_row)

    def _on_save(self):
        name = self.input.text().strip()
        if not name:
            from PyQt5.QtWidgets import QMessageBox
            QMessageBox.warning(self, "Missing Name", "Please enter a course name.")
            return
        self.course_name = name
        self.accept()