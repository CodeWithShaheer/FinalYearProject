"""
database package
PostgreSQL layer for SLEMS.

Repo modules are imported directly by callers:
    from database import sessions_repo
    from database import connections_repo

Do NOT add eager imports here — they cause circular imports
because repo files import from database.connection.
"""