"""
gui/teacher/violation_log.py
Teacher "Violation Log" page with three tabs:

  1. Violations   - filter by type / severity / roll no, sort by any column, mark
                    reviewed or dismiss false positives, export CSV      (plan UI-003)
  2. Block Events - every kill / block / pause with timestamp and launch->kill latency,
                    plus a summary ("N kills, avg X ms, Y within 2 s")   (S6)
  3. Audit Log    - teacher overrides, session start / end               (S4)

Shows the ACTIVE session if there is one, otherwise the most recent data.
"""
import logging
from datetime import datetime

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFrame, QTableWidget,
    QTableWidgetItem, QHeaderView, QFileDialog, QMessageBox, QTabWidget, QComboBox,
    QLineEdit, QCheckBox, QMenu, QGraphicsDropShadowEffect,
)

from gui.common import theme
from database import sessions_repo, violations_repo, block_events_repo, audit_repo
from utils.helpers import format_datetime

logger = logging.getLogger(__name__)

SEVERITY_COLORS = {"high": "#C43030", "medium": "#D98A00", "low": "#4A7BD0"}


def _shadow():
    eff = QGraphicsDropShadowEffect()
    eff.setBlurRadius(24)
    eff.setOffset(0, 6)
    eff.setColor(QColor(16, 24, 40, 40))
    return eff


def _card():
    w = QFrame()
    w.setObjectName("card")
    w.setGraphicsEffect(_shadow())
    lay = QVBoxLayout(w)
    lay.setContentsMargins(22, 18, 22, 18)
    lay.setSpacing(12)
    return w, lay


def _make_table(headers, stretch_col):
    t = QTableWidget(0, len(headers))
    t.setHorizontalHeaderLabels(headers)
    t.horizontalHeader().setSectionResizeMode(stretch_col, QHeaderView.Stretch)
    for c in range(len(headers)):
        if c != stretch_col:
            t.horizontalHeader().setSectionResizeMode(c, QHeaderView.ResizeToContents)
    t.setEditTriggers(QTableWidget.NoEditTriggers)
    t.setSelectionBehavior(QTableWidget.SelectRows)
    t.verticalHeader().setVisible(False)
    t.setSortingEnabled(True)
    return t


def _fmt_time(dt) -> str:
    return dt.strftime("%d %b %H:%M:%S") if dt else ""


class ViolationLogPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._violations = []
        self._events = []

        root = QVBoxLayout(self)
        root.setContentsMargins(28, 24, 28, 28)
        root.setSpacing(14)

        header = QHBoxLayout()
        title = QLabel("Session Violation Log")
        title.setObjectName("cardTitle")
        header.addWidget(title)
        self.scope_lbl = QLabel("")
        self.scope_lbl.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 13px;")
        header.addWidget(self.scope_lbl)
        header.addStretch()
        refresh = QPushButton("↻ Refresh")
        refresh.setObjectName("ghostBtn")
        refresh.setMinimumHeight(40)
        refresh.clicked.connect(self.refresh)
        header.addWidget(refresh)
        root.addLayout(header)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_violations_tab(), "Violations")
        self.tabs.addTab(self._build_events_tab(), "Block Events")
        self.tabs.addTab(self._build_audit_tab(), "Audit Log")
        root.addWidget(self.tabs, stretch=1)

        self.refresh()

    # ------------------------------------------------------------------ session scope
    def _session_id(self):
        try:
            active = sessions_repo.get_active_session()
            if active:
                return active.id
            recent = sessions_repo.get_sessions_with_student_count(limit=1)
            return recent[0].id if recent else None
        except Exception:
            logger.exception("could not pick a session")
            return None

    # ================================================================== tab 1
    def _build_violations_tab(self) -> QWidget:
        w, lay = _card()
        bar = QHBoxLayout()
        bar.setSpacing(10)

        self.type_combo = QComboBox()
        self.type_combo.addItems(["All types", "Behavioral", "Service"])
        self.sev_combo = QComboBox()
        self.sev_combo.addItems(["All severities", "High", "Medium", "Low"])
        self.roll_filter = QLineEdit()
        self.roll_filter.setPlaceholderText("Search roll no / name")
        self.roll_filter.setClearButtonEnabled(True)
        self.hide_dismissed = QCheckBox("Hide dismissed")
        self.hide_dismissed.setChecked(True)
        for wdg in (self.type_combo, self.sev_combo):
            wdg.currentIndexChanged.connect(self._load_violations)
            wdg.setMinimumHeight(36)
            bar.addWidget(wdg)
        self.roll_filter.setMinimumHeight(36)
        self.roll_filter.textChanged.connect(self._load_violations)
        bar.addWidget(self.roll_filter, stretch=1)
        self.hide_dismissed.stateChanged.connect(self._load_violations)
        bar.addWidget(self.hide_dismissed)

        export = QPushButton("Export CSV")
        export.setObjectName("primaryBtn")
        export.setMinimumHeight(40)
        export.clicked.connect(self._export_violations)
        bar.addWidget(export)
        lay.addLayout(bar)

        self.table = _make_table(
            ["Time", "Student", "Roll No", "Type", "Severity", "Detail", "Status"], 5)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._on_violation_menu)
        lay.addWidget(self.table)

        self.count_lbl = QLabel("")
        self.count_lbl.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 12px;")
        lay.addWidget(self.count_lbl)
        hint = QLabel("Tip: right-click a row to mark it reviewed or dismiss a false positive.")
        hint.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 12px;")
        lay.addWidget(hint)
        return w

    def _load_violations(self, *_):
        sid = self._session_id()
        vtype = {1: "behavioral", 2: "service"}.get(self.type_combo.currentIndex())
        sev = {1: "high", 2: "medium", 3: "low"}.get(self.sev_combo.currentIndex())
        try:
            rows = violations_repo.search_violations(
                session_id=sid, violation_type=vtype, severity=sev,
                include_dismissed=not self.hide_dismissed.isChecked(), limit=2000)
        except Exception:
            logger.exception("load violations failed")
            rows = []
        text = self.roll_filter.text().strip().lower()
        if text:
            rows = [v for v in rows if text in (v.roll_no or "").lower()
                    or text in (v.student_name or "").lower()]
        self._violations = rows

        self.table.setSortingEnabled(False)
        self.table.setRowCount(len(rows))
        for r, v in enumerate(rows):
            status = "Dismissed" if v.dismissed else ("Reviewed" if v.reviewed else "New")
            cells = [format_datetime(v.timestamp), v.student_name or "Student", v.roll_no or "",
                     "Behavioral" if v.violation_type == "behavioral" else "Service",
                     (v.severity or "").capitalize(), v.description, status]
            for c, txt in enumerate(cells):
                it = QTableWidgetItem(txt)
                if c == 4:
                    it.setForeground(QColor(SEVERITY_COLORS.get((v.severity or "").lower(), "#000")))
                if v.dismissed:
                    it.setForeground(QColor("#999999"))
                it.setData(Qt.UserRole, v.id)
                self.table.setItem(r, c, it)
        self.table.setSortingEnabled(True)
        self.count_lbl.setText(f"{len(rows)} violation(s)")

    def add_violation_live(self, payload: dict):
        """A violation just arrived over the network (it is already in the DB)."""
        self._load_violations()
        self._load_events()

    def _on_violation_menu(self, pos):
        item = self.table.itemAt(pos)
        if item is None:
            return
        vid = item.data(Qt.UserRole)
        menu = QMenu(self)
        a_rev = menu.addAction("Mark as reviewed")
        a_dis = menu.addAction("Dismiss (false positive)")
        a_new = menu.addAction("Reset to new")
        chosen = menu.exec_(self.table.viewport().mapToGlobal(pos))
        if chosen is a_rev:
            violations_repo.set_review_state(vid, reviewed=True, dismissed=False)
        elif chosen is a_dis:
            violations_repo.set_review_state(vid, reviewed=True, dismissed=True)
        elif chosen is a_new:
            violations_repo.set_review_state(vid, reviewed=False, dismissed=False)
        else:
            return
        self._load_violations()

    def _export_violations(self):
        path, _ = QFileDialog.getSaveFileName(self, "Export Violation Log", "violations.csv", "CSV (*.csv)")
        if not path:
            return
        ok, msg = violations_repo.export_violations_csv(self._violations, path)
        (QMessageBox.information if ok else QMessageBox.critical)(self, "Export", msg)

    # ================================================================== tab 2
    def _build_events_tab(self) -> QWidget:
        w, lay = _card()
        bar = QHBoxLayout()
        self.event_filter = QComboBox()
        self.event_filter.addItems(["All events", "process_killed", "allowlist_kill", "domain_blocked",
                                    "blocking_paused", "blocking_resumed", "client_offline"])
        self.event_filter.setMinimumHeight(36)
        self.event_filter.currentIndexChanged.connect(self._load_events)
        bar.addWidget(self.event_filter)
        self.stats_lbl = QLabel("")
        self.stats_lbl.setStyleSheet(f"color: {theme.NAVY_DARK}; font-size: 13px; font-weight: 700;")
        bar.addWidget(self.stats_lbl, stretch=1)
        export = QPushButton("Export CSV")
        export.setObjectName("primaryBtn")
        export.setMinimumHeight(40)
        export.clicked.connect(self._export_events)
        bar.addWidget(export)
        lay.addLayout(bar)

        self.events_table = _make_table(
            ["Time", "Roll No", "Student", "Event", "Target", "Latency (ms)", "Detail"], 6)
        lay.addWidget(self.events_table)
        return w

    def _load_events(self, *_):
        sid = self._session_id()
        etype = None if self.event_filter.currentIndex() == 0 else self.event_filter.currentText()
        try:
            events = block_events_repo.get_events(session_id=sid, event_type=etype, limit=2000)
            stats = block_events_repo.latency_stats(sid)
        except Exception:
            logger.exception("load block events failed")
            events, stats = [], {"count": 0}
        self._events = events

        self.events_table.setSortingEnabled(False)
        self.events_table.setRowCount(len(events))
        for r, e in enumerate(events):
            cells = [_fmt_time(e.created_at), e.roll_no, e.student_name, e.event_type, e.target,
                     "" if e.latency_ms is None else e.latency_ms, e.detail]
            for c, val in enumerate(cells):
                it = QTableWidgetItem()
                if c == 5 and val != "":
                    it.setData(Qt.DisplayRole, int(val))        # numeric sort
                    it.setTextAlignment(Qt.AlignCenter)
                    it.setForeground(QColor("#2E8B57" if int(val) <= 2000 else "#C43030"))
                else:
                    it.setText(str(val))
                self.events_table.setItem(r, c, it)
        self.events_table.setSortingEnabled(True)

        if stats.get("count"):
            self.stats_lbl.setText(
                f"{stats['count']} timed kills  |  min {stats['min_ms']} ms  |  avg {stats['avg_ms']} ms  |  "
                f"max {stats['max_ms']} ms  |  {stats['within_2s']} of {stats['count']} within 2 s")
        else:
            self.stats_lbl.setText("No timed kills yet (latency is recorded for apps launched during the exam).")

    def _export_events(self):
        path, _ = QFileDialog.getSaveFileName(self, "Export Block Events", "block_events.csv", "CSV (*.csv)")
        if not path:
            return
        ok, msg = block_events_repo.export_csv(self._events, path)
        (QMessageBox.information if ok else QMessageBox.critical)(self, "Export", msg)

    # ================================================================== tab 3
    def _build_audit_tab(self) -> QWidget:
        w, lay = _card()
        self.audit_table = _make_table(["Time", "Teacher", "Student", "Action", "Detail"], 4)
        lay.addWidget(self.audit_table)
        return w

    def _load_audit(self):
        try:
            entries = audit_repo.get_entries(session_id=self._session_id(), limit=1000)
        except Exception:
            logger.exception("load audit failed")
            entries = []
        self.audit_table.setSortingEnabled(False)
        self.audit_table.setRowCount(len(entries))
        for r, a in enumerate(entries):
            for c, txt in enumerate([_fmt_time(a.created_at), a.actor_name, a.roll_no, a.action, a.detail]):
                self.audit_table.setItem(r, c, QTableWidgetItem(txt))
        self.audit_table.setSortingEnabled(True)

    # ------------------------------------------------------------------
    def refresh(self):
        sid = self._session_id()
        self.scope_lbl.setText(f"   session #{sid}" if sid else "   no session yet")
        self._load_violations()
        self._load_events()
        self._load_audit()
