import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))  # run from anywhere
"""
test_integration.py  (TEMPORARY — delete after Phase 3 verification)

Runs TeacherServer + 2 StudentClient instances in the same asyncio loop.
Verifies: HELLO/WELCOME/JOIN/CONFIG, heartbeats, violations, disconnect.
"""
import asyncio
import logging
import sys

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)

from dotenv import load_dotenv
load_dotenv()

from database.migrations import init_db
from database import sessions_repo
from network.teacher_server import TeacherServer
from network.student_client import StudentClient


async def main():
    print("\n=== SETUP ===")
    init_db()

    # Ensure we have an active session
    active = sessions_repo.get_active_session()
    if not active:
        ok, s, msg = sessions_repo.create_session(
            course_name="Operating Systems",
            exam_title="Integration Test",
            duration_minutes=90,
            blocked_apps=["ChatGPT", "WhatsApp"],
            blocked_domains=["chatgpt.com"],
        )
        if not ok:
            print(f"Failed to create session: {msg}")
            return
        active = s
        print(f"Created session #{s.id}")
    else:
        print(f"Using active session #{active.id} ({active.course_name})")

    session_code = str(active.id)

    # ---- Start teacher server ----
    print("\n=== START TEACHER SERVER ===")
    server = TeacherServer()

    def on_teach_event(evt, payload):
        print(f"  [TEACHER] {evt}: {payload}")

    server.on_event(on_teach_event)
    await server.start()
    await asyncio.sleep(0.3)   # let server bind

    # ---- Create 2 student clients ----
    print("\n=== CREATE STUDENT CLIENTS ===")

    student1 = StudentClient()
    student2 = StudentClient()

    def s1_event(evt, payload):
        print(f"  [STUDENT1] {evt}: {payload}")

    def s2_event(evt, payload):
        print(f"  [STUDENT2] {evt}: {payload}")

    student1.on_event(s1_event)
    student2.on_event(s2_event)

    # ---- Connect ----
    print("\n=== STUDENT 1 CONNECT ===")
    ok, msg = await student1.connect("127.0.0.1", 5555, "21F-1234", session_code)
    print(f"Student1 connect: ok={ok} msg={msg}")
    assert ok, "Student1 failed to connect"

    print("\n=== STUDENT 2 CONNECT ===")
    ok, msg = await student2.connect("127.0.0.1", 5555, "21F-5678", session_code)
    print(f"Student2 connect: ok={ok} msg={msg}")
    assert ok, "Student2 failed to connect"

    # ---- Verify manager state ----
    await asyncio.sleep(0.3)
    print(f"\n=== SERVER STATE ===")
    print(f"Connected students: {server.manager.count()}")
    assert server.manager.count() == 2

    # ---- Heartbeat wait (client auto-sends every 5s) ----
    print("\n=== WAITING 6s FOR HEARTBEATS ===")
    await asyncio.sleep(6)

    # ---- Send violations ----
    print("\n=== VIOLATIONS ===")
    await student1.send_violation("behavioral", "Looking away", "high")
    await student2.send_violation("service", "Tried to open chatgpt.com", "medium")
    await asyncio.sleep(0.5)

    # ---- Disconnect student 1 ----
    print("\n=== DISCONNECT STUDENT 1 ===")
    await student1.disconnect(reason="test_done")
    await asyncio.sleep(0.5)

    print(f"\n=== FINAL SERVER STATE ===")
    print(f"Connected students: {server.manager.count()}")
    assert server.manager.count() == 1

    # ---- Teacher ends session (broadcast SESSION_END) ----
    print("\n=== TEACHER ENDS SESSION ===")
    from network import protocol as P
    await server.manager.broadcast(P.session_end())
    await asyncio.sleep(0.5)

    # ---- Disconnect student 2 ----
    await student2.disconnect(reason="test_done")
    await asyncio.sleep(0.3)

    # ---- Stop server ----
    print("\n=== STOP SERVER ===")
    await server.stop()

    # ---- Verify DB ----
    print("\n=== DB VERIFICATION ===")
    from database import connections_repo, violations_repo, students_repo
    print(f"Students in session: {students_repo.count_by_session(active.id)}")
    print(f"Violations in session: {violations_repo.count_violations_by_session(active.id)}")
    print(f"Active connections in DB: {connections_repo.count_active_connections(active.id)}")

    print("\n=== INTEGRATION TEST PASSED ===")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nInterrupted.")