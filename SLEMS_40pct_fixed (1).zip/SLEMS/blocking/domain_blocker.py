"""
blocking/domain_blocker.py
Higher-level domain blocking.
"""
import logging
from dataclasses import dataclass
from typing import List, Optional

try:
    import psutil
except ImportError:
    psutil = None

from blocking.hosts_manager import HostsManager

logger = logging.getLogger(__name__)


@dataclass
class BlockedConnection:
    pid: int
    process_name: str
    remote_ip: str
    remote_port: int
    domain_hint: str = ""


class DomainBlocker:
    def __init__(self, hosts_manager: Optional[HostsManager] = None):
        if psutil is None:
            raise ImportError("psutil not installed. Run: pip install psutil")
        self.hosts = hosts_manager or HostsManager()
        self._blocked: List[str] = []

    def set_blocked_domains(self, domains: List[str]):
        self._blocked = [d.strip().lower() for d in (domains or []) if d.strip()]

    def apply(self) -> bool:
        return self.hosts.block_domains(self._blocked)

    def restore(self) -> bool:
        return self.hosts.restore()

    def scan_active_connections(self) -> List[BlockedConnection]:
        suspicious: List[BlockedConnection] = []
        if not self._blocked:
            return suspicious
        try:
            connections = psutil.net_connections(kind="inet")
        except Exception:
            logger.exception("net_connections failed")
            return suspicious

        for conn in connections:
            if conn.status != psutil.CONN_ESTABLISHED:
                continue
            if not conn.raddr:
                continue
            try:
                raddr_ip = conn.raddr.ip
                raddr_port = conn.raddr.port
            except Exception:
                continue
            if raddr_port not in (80, 443, 8080, 8443, 53, 853):
                continue
            pid = conn.pid or 0
            pname = ""
            try:
                if pid:
                    pname = psutil.Process(pid).name()
            except Exception:
                pass
            hint = self._reverse_dns(raddr_ip)
            for blocked in self._blocked:
                if blocked and hint and blocked in hint:
                    suspicious.append(BlockedConnection(
                        pid=pid, process_name=pname,
                        remote_ip=raddr_ip, remote_port=raddr_port,
                        domain_hint=hint))
                    break
        return suspicious

    @staticmethod
    def _reverse_dns(ip: str, timeout: float = 0.5) -> str:
        import socket
        try:
            socket.setdefaulttimeout(timeout)
            host, _, _ = socket.gethostbyaddr(ip)
            return host.lower()
        except Exception:
            return ""

    @property
    def blocked_domains(self) -> List[str]:
        return list(self._blocked)

    @property
    def hosts_path(self) -> str:
        return self.hosts.hosts_path