import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))  # run from anywhere
import logging
import sys
from PyQt5.QtCore import QCoreApplication, QTimer

from blocking.blocking_engine import BlockingEngine

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)


def main():
    app = QCoreApplication(sys.argv)

    print("=== EXAM LOCKDOWN TEST — 60 seconds ===")
    print("Try to open: WhatsApp, ChatGPT, Notepad++, Chrome, Telegram...")
    print("Sab block hone chahiye!")

    engine = BlockingEngine(
        blocked_apps=[
            # AI Tools
            "ChatGPT", "Claude", "Gemini", "Copilot", "Perplexity",
            "Cursor", "Ollama",
            # Messaging
            "WhatsApp", "Telegram", "Discord", "Skype", "Slack",
            "Signal", "Messenger", "Zoom", "Teams",
            # Remote Desktop
            "TeamViewer", "AnyDesk", "VNC", "RDP",
            # Screen Recording
            "OBS",
            # Homework Help
            "Chegg", "Brainly", "Quizlet", "Photomath", "Mathway",
            "WolframAlpha",
            # Editors (cheating via notes)
            "Notepad++", "Sublime", "Vim",
            # Browsers (chatgpt.com etc via browser)
            "Chrome", "Edge", "Firefox", "Brave", "Opera",
            # Games
            "Steam", "Epic Games", "Valorant", "Minecraft", "Roblox",
            # VM (cheating via virtual machine)
            "VirtualBox", "VMware", "Docker",
            # Misc
            "Notion", "Evernote", "Obsidian",
        ],
        blocked_domains=[
            "chatgpt.com", "openai.com", "claude.ai", "anthropic.com",
            "gemini.google.com", "bard.google.com",
            "copilot.microsoft.com", "perplexity.ai",
            "chegg.com", "brainly.com", "quizlet.com",
            "photomath.com", "mathway.com", "wolframalpha.com",
            "web.whatsapp.com", "web.telegram.org",
            "discord.com", "facebook.com", "instagram.com",
            "twitter.com", "x.com", "tiktok.com",
            "youtube.com",
        ],
        security_options={
            "block_unauthorized_apps": True,
            "block_restricted_websites": True,
            "monitor_student_screens": True,
            "detect_suspicious_behavior": True,
            "monitor_student_connection": True,
            "enable_kiosk_mode": False,
        },
    )

    engine.blocking_started.connect(lambda d: print(f"[STARTED] {d}"))
    engine.blocked_process_killed.connect(lambda d: print(f"[KILLED] {d}"))
    engine.violation_detected.connect(lambda d: print(f">>> VIOLATION: {d}"))
    engine.error_occurred.connect(lambda e: print(f"[ERROR] {e}"))
    engine.status_update.connect(lambda d: None)

    engine.start()

    # 60 seconds test
    QTimer.singleShot(60_000, lambda: (engine.stop(), app.quit()))

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()