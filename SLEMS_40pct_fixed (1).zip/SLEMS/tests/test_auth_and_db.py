"""
tests/test_auth_and_db.py
Needs a running PostgreSQL with the slems_db from .env.
    python -m pytest tests/test_auth_and_db.py -v
"""
import sys
import uuid
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parent.parent / ".env")
except ImportError:
    pass

from database.migrations import init_db
from database.connection import db_cursor
from database import users_repo
from security.password import hash_password, verify_password, needs_rehash
import hashlib

init_db()


def _email():
    return f"t_{uuid.uuid4().hex[:8]}@numl.edu.pk"


def test_password_roundtrip_and_salt():
    h1, h2 = hash_password("secret123"), hash_password("secret123")
    assert h1 != h2                                  # salted
    assert verify_password("secret123", h1) and not verify_password("nope", h1)
    assert not needs_rehash(h1)


def test_legacy_sha256_accepted_and_upgraded():
    email, pw = _email(), "oldpass1"
    legacy = hashlib.sha256(pw.encode()).hexdigest()
    with db_cursor() as cur:
        cur.execute("INSERT INTO users (full_name,email,password_hash,role) VALUES (%s,%s,%s,'teacher')",
                    ("Old User", email, legacy))
    ok, user, _ = users_repo.login_user(email, pw)
    assert ok and user["email"] == email
    with db_cursor() as cur:
        cur.execute("SELECT password_hash FROM users WHERE email=%s", (email,))
        assert cur.fetchone()[0].startswith("$2")    # upgraded to bcrypt


def test_lockout_after_five_failures():
    email = _email()
    assert users_repo.register_user("Lock Test", email, "goodpass1")[0]
    for _ in range(4):
        ok, _, msg = users_repo.login_user(email, "wrong")
        assert not ok and msg == "Invalid email or password."
    ok, _, msg = users_repo.login_user(email, "wrong")          # 5th
    assert not ok and "locked" in msg.lower()
    ok, _, msg = users_repo.login_user(email, "goodpass1")      # even correct pw is refused
    assert not ok and "locked" in msg.lower()
    with db_cursor() as cur:                                     # simulate 5 minutes passing
        cur.execute("UPDATE users SET locked_until = NOW() - interval '1 second' WHERE email=%s", (email,))
    assert users_repo.login_user(email, "goodpass1")[0]


def test_unknown_email_gives_generic_error():
    ok, _, msg = users_repo.login_user("nobody@x.com", "whatever1")
    assert not ok and msg == "Invalid email or password."


def test_violation_filter_review_and_csv(tmp_path=None):
    import tempfile, os
    from database import violations_repo
    # direct SQL so this test does not depend on create_session's signature
    with db_cursor() as cur:
        cur.execute("INSERT INTO sessions (course_name,duration) VALUES ('X',30) RETURNING id")
        sid = cur.fetchone()[0]
        cur.execute("INSERT INTO students (session_id,student_id,full_name,roll_no) VALUES (%s,'S1','Ali','21F-1') RETURNING id", (sid,))
        stid = cur.fetchone()[0]
    assert violations_repo.add_violation(sid, stid, "behavioral", "Looking away", "medium", confidence=0.82)[0]
    assert violations_repo.add_violation(sid, stid, "service", "Blocked chrome", "high")[0]
    assert len(violations_repo.search_violations(session_id=sid)) == 2
    assert len(violations_repo.search_violations(session_id=sid, violation_type="service")) == 1
    v = violations_repo.search_violations(session_id=sid, severity="high")[0]
    assert violations_repo.set_review_state(v.id, reviewed=True, dismissed=True)
    assert len(violations_repo.search_violations(session_id=sid, include_dismissed=False)) == 1
    path = os.path.join(tempfile.gettempdir(), "viol_test.csv")
    ok, _ = violations_repo.export_violations_csv(violations_repo.search_violations(session_id=sid), path)
    assert ok and open(path, encoding="utf-8-sig").read().count("\n") == 3   # header + 2 rows
    with db_cursor() as cur:
        cur.execute("DELETE FROM sessions WHERE id=%s", (sid,))


def test_teacher_signup_needs_key_but_students_do_not():
    """S9: nobody can make themselves a teacher/admin."""
    import os
    old = os.environ.get("TEACHER_SIGNUP_KEY")
    try:
        os.environ["TEACHER_SIGNUP_KEY"] = "secret-key-123"
        ok, msg = users_repo.register_user("Sneaky", _email(), "password1", role="teacher")
        assert not ok and "key" in msg.lower()
        ok, msg = users_repo.register_user("Sneaky", _email(), "password1", role="admin", signup_key="wrong")
        assert not ok
        assert users_repo.register_user("Real Teacher", _email(), "password1", role="teacher",
                                        signup_key="secret-key-123")[0]
        assert users_repo.register_user("Student", _email(), "password1", role="student")[0]
        assert users_repo.register_user("Default", _email(), "password1")[0]          # default = student
        assert not users_repo.register_user("Hacker", _email(), "password1", role="superuser")[0]
        # no key configured + teachers already exist -> teacher sign-up is closed
        os.environ["TEACHER_SIGNUP_KEY"] = ""
        assert not users_repo.register_user("Late", _email(), "password1", role="teacher")[0]
    finally:
        if old is None:
            os.environ.pop("TEACHER_SIGNUP_KEY", None)
        else:
            os.environ["TEACHER_SIGNUP_KEY"] = old


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("PASS", name)
