# Dev/frozen path resolution.
"""
utils/paths.py
Path resolution helpers.

Centralizes all file system paths so we can change them in one place.
"""
from pathlib import Path
from config.settings import (
    PROJECT_ROOT,
    ASSETS_DIR,
    IMAGES_DIR,
    ICONS_DIR,
    DATA_DIR,
    SUBMISSIONS_DIR,
    LOGS_DIR,
    LOCAL_DIR,
)


def project_root() -> Path:
    return PROJECT_ROOT


def logo_path() -> Path:
    """Return the SLEMS logo path (checks a few known locations)."""
    candidates = [
        IMAGES_DIR / "slemslogo.png",
        PROJECT_ROOT / "slemslogo.png",   # legacy location
    ]
    for p in candidates:
        if p.exists():
            return p
    return candidates[0]  # return expected path even if missing


def submission_file_path(filename: str) -> Path:
    """Return full path for a submission file."""
    return SUBMISSIONS_DIR / filename


def log_file_path(name: str = "slems.log") -> Path:
    return LOGS_DIR / name


def offline_queue_path() -> Path:
    """Student-side offline SQLite buffer."""
    return LOCAL_DIR / "offline_queue.db"


def ensure_dir(path: Path) -> Path:
    """Ensure a directory exists, return it."""
    path.mkdir(parents=True, exist_ok=True)
    return path

def load_logo_pixmap(width: int, height: int):
    """
    Return the scaled SLEMS logo as a QPixmap, or None if the logo file is
    missing / empty / corrupt (avoids "QPixmap::scaled: Pixmap is a null pixmap").
    """
    from PyQt5.QtCore import Qt
    from PyQt5.QtGui import QPixmap
    lp = logo_path()
    try:
        if not lp or not lp.exists() or lp.stat().st_size == 0:
            return None
    except OSError:
        return None
    pm = QPixmap(str(lp))
    if pm.isNull():
        return None
    return pm.scaled(width, height, Qt.KeepAspectRatio, Qt.SmoothTransformation)
