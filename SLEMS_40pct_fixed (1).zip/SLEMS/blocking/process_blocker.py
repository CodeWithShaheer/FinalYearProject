"""
blocking/process_blocker.py
Terminates blocked processes — HARD kill on Windows.

v3.0:
    - Uses `taskkill /F /T /PID` on Windows
    - Falls back to psutil if taskkill not available
    - Kills parents FIRST
"""
import logging
import os
import platform
import subprocess
import time
from typing import List, Set

try:
    import psutil
except ImportError:
    psutil = None

from blocking.process_monitor import DetectedProcess

logger = logging.getLogger(__name__)


_IS_WINDOWS = platform.system().lower() == "windows"
_KILL_FAILED_PIDS: Set[int] = set()
_last_logged: dict = {}
_KILL_LOG_COOLDOWN = 2.0


class ProcessBlocker:
    def __init__(self):
        if psutil is None:
            raise ImportError("psutil not installed. Run: pip install psutil")

    # ------------------------------------------------------------------
    @staticmethod
    def protected_pids() -> Set[int]:
        """SLEMS itself and every ancestor (taskkill /T on an ancestor would kill SLEMS)."""
        pids = {os.getpid()}
        try:
            for parent in psutil.Process().parents():
                pids.add(parent.pid)
        except Exception:
            pass
        return pids

    # ------------------------------------------------------------------
    def terminate_all(self, detected: List[DetectedProcess]) -> List[DetectedProcess]:
        """Kill detected processes. Parents first."""
        if not detected:
            return []

        parents = [dp for dp in detected if dp.is_parent]
        children = [dp for dp in detected if not dp.is_parent]
        ordered = parents + children

        killed: List[DetectedProcess] = []
        killed_pids: Set[int] = set()
        protected = self.protected_pids()

        for dp in ordered:
            if dp.pid in killed_pids:
                continue
            if dp.pid in protected:
                logger.warning("Refusing to kill %s (pid=%d): it is SLEMS or its parent.",
                               dp.name, dp.pid)
                continue
            if not self._pid_still_alive(dp.pid):
                killed_pids.add(dp.pid)
                continue

            ok = self._terminate_one(dp)
            if ok:
                killed.append(dp)
                killed_pids.add(dp.pid)

        return killed

    # ------------------------------------------------------------------
    def _terminate_one(self, dp: DetectedProcess) -> bool:
        if _IS_WINDOWS:
            return self._terminate_one_windows(dp)
        return self._terminate_one_psutil(dp)

    # ------------------------------------------------------------------
    def _terminate_one_windows(self, dp: DetectedProcess) -> bool:
        """taskkill /F /T /PID <pid>"""
        try:
            creationflags = 0x08000000  # CREATE_NO_WINDOW
            result = subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(dp.pid)],
                capture_output=True,
                text=True,
                timeout=4.0,
                creationflags=creationflags,
            )
        except subprocess.TimeoutExpired:
            logger.warning("taskkill timed out for %s (pid=%d)", dp.name, dp.pid)
            return False
        except FileNotFoundError:
            return self._terminate_one_psutil(dp)
        except Exception:
            logger.exception("taskkill failed for %s (pid=%d)", dp.name, dp.pid)
            return False

        stdout = (result.stdout or "").strip()
        stderr = (result.stderr or "").strip()

        if result.returncode == 0:
            self._log_killed(dp.name, dp.pid, dp.matched_app)
            return True
        if result.returncode == 128:
            return False
        if "not found" in (stderr + stdout).lower():
            return False

        if "access is denied" in (stderr + stdout).lower():
            if dp.pid not in _KILL_FAILED_PIDS:
                logger.warning(
                    "taskkill AccessDenied for %s (pid=%d). Run as Administrator.",
                    dp.name, dp.pid,
                )
                _KILL_FAILED_PIDS.add(dp.pid)
            return False

        logger.debug("taskkill rc=%d out=%s err=%s",
                     result.returncode, stdout[:80], stderr[:80])
        return False

    # ------------------------------------------------------------------
    def _terminate_one_psutil(self, dp: DetectedProcess) -> bool:
        try:
            proc = psutil.Process(dp.pid)
        except psutil.NoSuchProcess:
            return False
        except Exception:
            return False

        try:
            name = proc.name()
        except Exception:
            name = dp.name

        try:
            for child in proc.children(recursive=True):
                try:
                    child.kill()
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

        try:
            proc.kill()
            try:
                proc.wait(timeout=1.0)
            except psutil.TimeoutExpired:
                pass
            self._log_killed(name, dp.pid, dp.matched_app)
            return True
        except psutil.AccessDenied:
            if dp.pid not in _KILL_FAILED_PIDS:
                logger.warning("AccessDenied killing %s (pid=%d)", name, dp.pid)
                _KILL_FAILED_PIDS.add(dp.pid)
            return False
        except psutil.NoSuchProcess:
            return False
        except Exception:
            logger.exception("psutil kill failed for %s (pid=%d)", name, dp.pid)
            return False

    # ------------------------------------------------------------------
    @staticmethod
    def _pid_still_alive(pid: int) -> bool:
        try:
            return psutil.pid_exists(pid)
        except Exception:
            return False

    # ------------------------------------------------------------------
    @staticmethod
    def _log_killed(name: str, pid: int, app: str):
        now = time.time()
        key = f"{name}:{app}"
        last = _last_logged.get(key, 0.0)
        if now - last >= _KILL_LOG_COOLDOWN:
            logger.info("Terminated %s (pid=%d, app=%s)", name, pid, app)
            _last_logged[key] = now