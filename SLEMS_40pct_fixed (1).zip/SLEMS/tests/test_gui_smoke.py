"""
tests/test_gui_smoke.py
Headless GUI test: the REAL TeacherDashboard and StudentDashboard windows, driven like a user.

  teacher: preset button -> roster -> Start Exam (creates a session with a 6-digit join code)
  student: joins with the code; stranger is refused (roster)
  teacher: table view shows the student; pauses blocking (emergency override); resumes
  student: blocked app is killed (block event + latency stored); time-up auto-submits the file
  teacher: presses End -> student is unlocked and hosts file is clean   (bug found while writing this)
  teacher: timer hits zero -> session ends by itself
  student: closes SLEMS mid-exam -> teacher sees OFFLINE + violation

    QT_QPA_PLATFORM=offscreen python tests/test_gui_smoke.py       (Linux CI)
On Windows run it as Administrator to exercise the real hosts file.
"""
import os
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parent.parent / ".env")
except ImportError:
    pass

from PyQt5.QtWidgets import QApplication, QMessageBox, QInputDialog
from PyQt5.QtCore import QTimer, QEventLoop

from gui.common import theme
from database.migrations import init_db
from database import (sessions_repo, students_repo, violations_repo, submissions_repo,
                      block_events_repo, audit_repo)
from blocking.hosts_manager import default_hosts_path, BLOCK_START

IS_WIN = os.name == "nt"


def pump(seconds):
    loop = QEventLoop()
    QTimer.singleShot(int(seconds * 1000), loop.quit)
    loop.exec_()


def hosts_text():
    with open(default_hosts_path(), "rb") as f:
        return f.read().decode("latin-1")


def hosts_blocked():
    return BLOCK_START in hosts_text()


def spawn_fake_app(tmpdir, name):
    if IS_WIN:
        exe = Path(tmpdir) / f"{name}.exe"
        shutil.copy(sys.executable, exe)
        return subprocess.Popen([str(exe), "-c", "import time; time.sleep(120)"])
    exe = Path(tmpdir) / name
    shutil.copy(shutil.which("sleep"), exe)
    return subprocess.Popen([str(exe), "120"])


def main():
    init_db()
    # leave nothing active from earlier runs
    for s in sessions_repo.get_sessions_with_student_count(limit=50):
        if s.status == "active":
            sessions_repo.end_session(s.id)

    app = QApplication.instance() or QApplication(sys.argv)
    app.setStyleSheet(theme.build_stylesheet())
    for name in ("information", "warning", "critical", "question"):          # no modal pop-ups
        setattr(QMessageBox, name, staticmethod(lambda *a, **k: QMessageBox.Yes))
    QInputDialog.getText = staticmethod(lambda *a, **k: ("PC problem", True))

    from gui.common.auth_window import AuthWindow
    from gui.teacher.dashboard import TeacherDashboard
    from gui.student.dashboard import StudentDashboard

    tmp = tempfile.mkdtemp()
    AuthWindow().show()                                           # login + sign-up screens build
    teacher = TeacherDashboard(user={"full_name": "Teacher", "role": "teacher", "id": None})
    teacher.show()
    pump(1.5)                                                     # network server starts

    # ---------------------------------------------------------------- teacher starts an exam
    sc = teacher.session_page
    if sc.course_combo.count() == 0:
        sc.course_combo.addItem("Operating Systems")
    sc.hours_spin.setValue(0)
    sc.minutes_spin.setValue(30)
    paper = Path(tmp) / "paper.pdf"
    paper.write_bytes(b"%PDF-1.4 test")
    sc.file_upload_row.set_file(str(paper))
    for key in sc.preset_buttons:                                 # S1: presets tick the lists
        pass
    sc.preset_buttons["AI assistants"].click()
    assert "chat.openai.com" in sc.domains_list.get_selected(), "preset did not tick its websites"
    assert any(a.lower() == "chatgpt" for a in sc.apps_list.get_selected()), "preset did not tick its apps"
    sc.preset_buttons["AI assistants"].click()                    # toggles off again
    assert "chat.openai.com" not in sc.domains_list.get_selected()
    sc.preset_buttons["AI assistants"].click()
    sc.roster_text.setPlainText("G-1, Ali Khan\nG-2, Sara Ahmed")
    sc.security_option_rows["require_roster"].set_checked(True)
    sc._on_start_exam()

    active = sessions_repo.get_active_session()
    assert active is not None and len(active.join_code) == 6, "session / join code not created"
    code = active.join_code
    assert students_repo.get_student_by_roll_in_session(active.id, "G-1").status == "registered"
    assert sc.sessions_table.item(0, 1).text() == code, "join code not shown in history table"
    print("OK  Start Exam created the session with join code", code, "and a roster of 2")

    # ---------------------------------------------------------------- students join
    stranger = StudentDashboard(user={"full_name": "X", "role": "student", "roll_no": "NOPE"})
    stranger.show()
    stranger._on_connect_requested("127.0.0.1", 5555, code, "NOPE")
    pump(2)
    assert stranger.central_stack.currentIndex() == 0, "unregistered student got in!"
    print("OK  student not on the roster was refused")

    student = StudentDashboard(user={"full_name": "Ali", "role": "student", "roll_no": "G-1"})
    student.show()
    student._on_connect_requested("127.0.0.1", 5555, code, "G-1")
    pump(3)
    assert student.central_stack.currentIndex() == 1, "student did not reach the exam screen"
    pump(1.5)
    assert hosts_blocked(), "domain block was not applied"
    text = hosts_text()
    assert "0.0.0.0 chat.openai.com" in text and ":: chat.openai.com" in text, "IPv4+IPv6 entries missing"
    live = teacher.live_page
    assert len(live._students) == 1
    print("OK  student joined with the code; websites blocked (IPv4 + IPv6); teacher sees the student")

    # ---------------------------------------------------------------- S10 table view
    live.view_btn.click()
    pump(0.3)
    assert live.view_stack.currentIndex() == 1 and live.table.rowCount() == 1
    assert live.table.item(0, 0).text() == "G-1" and live.table.item(0, 2).text() == "ONLINE"
    print("OK  teacher table view shows G-1 ONLINE")

    # ---------------------------------------------------------------- S4 pause / resume
    token = next(iter(live._students))
    live.pause_requested.emit(token, True, "PC problem")
    pump(1.5)
    assert student.blocking_engine.is_paused and not hosts_blocked(), "pause did not release blocking"
    assert live.table.item(0, 2).text() == "PAUSED"
    assert "PAUSED" in student.blocking_state_lbl.text()
    assert any(a.action == "blocking_paused" and a.detail == "PC problem"
               for a in audit_repo.get_entries(session_id=active.id)), "override not in audit log"
    live.pause_requested.emit(token, False, "")
    pump(1.5)
    assert not student.blocking_engine.is_paused and hosts_blocked()
    print("OK  emergency pause released hosts + logged to audit; resume re-blocked")

    # ---------------------------------------------------------------- S6 kill + latency evidence
    fake = spawn_fake_app(tmp, "chatgpt")
    deadline = time.time() + 5
    while time.time() < deadline and fake.poll() is None:
        pump(0.1)
    assert fake.poll() is not None, "blocked app was not killed"
    pump(1.0)
    ev = [e for e in block_events_repo.get_events(session_id=active.id) if e.event_type == "process_killed"]
    assert ev and ev[0].latency_ms is not None and ev[0].latency_ms <= 2000, "kill latency not recorded"
    pump(0.5)
    assert live._students[token]["kills"] >= 1
    teacher.log_page.refresh()
    assert teacher.log_page.events_table.rowCount() >= 1
    print(f"OK  blocked app killed in {ev[0].latency_ms} ms and logged in Block Events")

    # ---------------------------------------------------------------- S12 time-up auto-submit
    answer = Path(tmp) / "answer.pdf"
    answer.write_bytes(b"%PDF-1.4 student answer")
    student._selected_file_path = str(answer)
    student._total_seconds = 10
    student._remaining_seconds = 1
    student._tick()
    student._tick()                                               # reaches zero -> auto-submit
    pump(3)
    subs = submissions_repo.get_submissions_by_session(active.id)
    assert subs, "file was not auto-submitted at time zero"
    assert student._submitted, "student UI does not show SUBMITTED"
    print("OK  time-up auto-submitted the selected file to the teacher")

    # ---------------------------------------------------------------- teacher presses End
    student2 = StudentDashboard(user={"full_name": "Sara", "role": "student", "roll_no": "G-2"})
    student2.show()
    student2._on_connect_requested("127.0.0.1", 5555, code, "G-2")
    pump(3)
    assert student2.central_stack.currentIndex() == 1

    sc._end_specific_session(active.id)                           # the button on Session Control
    pump(2)
    assert student.central_stack.currentIndex() == 0 and student2.central_stack.currentIndex() == 0, \
        "students were NOT told the session ended"
    assert not hosts_blocked(), "HOSTS FILE LEFT BLOCKED after the teacher ended the session"
    assert not any("left the exam" in v.description or "connection was lost" in v.description
                   for v in violations_repo.get_violations_by_session(active.id)), \
        "normal end of exam was wrongly flagged as a violation"
    print("OK  End Session on the teacher page unlocked every student; hosts clean; no false alarms")

    # ---------------------------------------------------------------- S12 auto-end + S3 offline
    ok, s2, _ = sessions_repo.create_session("OS", "auto-end", 1, blocked_apps=["telegram"],
                                             blocked_domains=["chatgpt.com"])
    code2 = s2.join_code
    live.clear_all()
    student3 = StudentDashboard(user={"full_name": "Zed", "role": "student", "roll_no": "G-3"})
    student3.show()
    student3._on_connect_requested("127.0.0.1", 5555, code2, "G-3")
    pump(3)
    assert student3.central_stack.currentIndex() == 1 and hosts_blocked()

    student3.client_worker.stop()                                 # SLEMS closed mid-exam
    pump(2)
    offline_entry = next(iter(live._students.values()))
    assert offline_entry["offline"] and offline_entry["status"] == "disconnected", "tile not red/offline"
    assert any("left the exam" in v.description or "connection was lost" in v.description
               for v in violations_repo.get_violations_by_session(s2.id)), "leaving mid-exam not flagged"
    print("OK  student closing SLEMS mid-exam -> OFFLINE + high-severity violation")

    sc.current_session_id = s2.id
    sc._remaining_seconds = 0
    sc._tick_countdown()                                          # timer reached zero
    pump(1)
    assert sessions_repo.get_session_by_id(s2.id).status == "ended", "session did not auto-end"
    assert any(a.action == "session_ended_auto" for a in audit_repo.get_entries(session_id=s2.id))
    print("OK  timer at zero ended the session automatically")

    student3._shutdown_all()
    for w in (stranger, student, student2, student3):
        w.close()
    teacher.close()
    pump(0.5)
    assert not hosts_blocked(), "hosts file left blocked at the end of the test"
    print("PASS test_gui_smoke")


def test_gui_smoke():          # lets pytest run it too
    main()


if __name__ == "__main__":
    main()
