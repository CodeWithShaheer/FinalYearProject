"""
main.py
SLEMS entry point — final integration.

Flow:
    1. Load .env
    2. Setup logging
    3. init_db() (schema + seed courses)
    4. Show AuthWindow
    5. On login → role-based dashboard
        - teacher / admin → TeacherDashboard (auto-starts NetworkBridge)
        - student → StudentDashboard (shows Connect page)
    6. On logout → return to AuthWindow
"""
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

# Load .env before anything else
try:
    from dotenv import load_dotenv
    _env = SCRIPT_DIR / ".env"
    if _env.exists():
        load_dotenv(_env)
except ImportError:
    pass

from PyQt5.QtWidgets import QApplication, QMessageBox

from gui.common import theme
from utils.logger import setup_logging
from database.connection import test_connection
from database.migrations import init_db
from blocking.hosts_manager import install_safety_net, restore_all_active

from gui.common.auth_window import AuthWindow
from gui.teacher.dashboard import TeacherDashboard
from gui.student.dashboard import StudentDashboard


def _check_db_or_die():
    ok, msg = test_connection()
    if not ok:
        app = QApplication.instance() or QApplication(sys.argv)
        QMessageBox.critical(
            None, "Database Connection Failed",
            f"SLEMS could not connect to PostgreSQL.\n\n{msg}\n\n"
            f"Please ensure:\n"
            f"  1. PostgreSQL service is running\n"
            f"  2. .env has correct DB_PASSWORD\n"
            f"  3. Database 'slems_db' exists"
        )
        sys.exit(1)


def run_app():
    setup_logging()

    try:
        init_db()
    except Exception as e:
        print(f"[main] init_db() failed: {e}")

    # Crash-safe hosts file: removes a block left by a previous crash and
    # restores on exit / Ctrl+C / terminate.  Must run in the main thread.
    install_safety_net()

    app = QApplication(sys.argv)
    app.setStyleSheet(theme.build_stylesheet())
    app.aboutToQuit.connect(restore_all_active)

    _check_db_or_die()

    auth_win = AuthWindow()
    auth_win.show()

    dashboard = None

    def on_login(user: dict):
        nonlocal dashboard
        auth_win.hide()

        role = (user.get("role") or "student").lower()      # unknown -> least privilege
        if role in ("teacher", "admin"):
            dashboard = TeacherDashboard(user=user)
        else:                                   # student or anything unknown -> least privilege
            dashboard = StudentDashboard(user=user)

        dashboard.logout_requested.connect(on_logout)
        dashboard.show()

    def on_logout():
        nonlocal dashboard
        if dashboard:
            try:
                dashboard.close()
            except Exception:
                pass
            dashboard = None
        auth_win.show()
        auth_win._show_login()

    auth_win.authenticated.connect(on_login)

    sys.exit(app.exec_())


if __name__ == "__main__":
    run_app()