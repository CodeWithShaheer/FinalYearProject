"""
blocking package
Real-time service blocking on student PC.
"""