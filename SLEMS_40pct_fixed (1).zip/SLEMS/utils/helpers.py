# General helper functions.
"""
utils/helpers.py
Small helper functions used across GUI + backend.
"""
from datetime import datetime, timedelta
from typing import Optional


# ---------------------------------------------------------------------------
# Time formatting
# ---------------------------------------------------------------------------
def format_hms(seconds: int) -> str:
    """Format seconds as HH:MM:SS."""
    seconds = max(0, int(seconds))
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    return f"{h:02d}:{m:02d}:{s:02d}"


def format_duration_minutes(minutes: int) -> str:
    """Convert minutes to '1h 30m' or '45 min'."""
    minutes = max(0, int(minutes))
    h = minutes // 60
    m = minutes % 60
    if h and m:
        return f"{h}h {m}m"
    if h:
        return f"{h}h"
    return f"{m} min"


def format_datetime(dt: Optional[datetime]) -> str:
    """Format datetime as '12 Aug 2026, 08:30 AM'."""
    if dt is None:
        return "—"
    try:
        return dt.strftime("%d %b %Y, %I:%M %p")
    except Exception:
        return str(dt)


def format_time_only(dt: Optional[datetime]) -> str:
    """Format datetime as '10:42:03 AM'."""
    if dt is None:
        return "—"
    try:
        return dt.strftime("%I:%M:%S %p")
    except Exception:
        return str(dt)


def now() -> datetime:
    return datetime.now()


def seconds_until(end_time: datetime) -> int:
    """Return seconds from now until end_time (can be negative)."""
    if end_time is None:
        return 0
    delta = end_time - datetime.now()
    return int(delta.total_seconds())


# ---------------------------------------------------------------------------
# Validators
# ---------------------------------------------------------------------------
def is_valid_email(email: str) -> bool:
    email = (email or "").strip()
    return "@" in email and "." in email.split("@")[-1]


def is_valid_roll_no(roll: str) -> bool:
    roll = (roll or "").strip()
    return len(roll) >= 3 and any(c.isalnum() for c in roll)


def is_valid_session_code(code: str) -> bool:
    """Session code must be a positive integer."""
    try:
        return int((code or "").strip()) > 0
    except (ValueError, TypeError):
        return False


# ---------------------------------------------------------------------------
# Misc
# ---------------------------------------------------------------------------
def safe_int(value, default: int = 0) -> int:
    try:
        return int(value)
    except (ValueError, TypeError):
        return default


def truncate(text: str, max_len: int = 40) -> str:
    """Truncate long text with ellipsis."""
    text = str(text or "")
    if len(text) <= max_len:
        return text
    return text[:max_len - 1] + "…"