import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))  # run from anywhere
# test_ai_detectors.py
import time
import logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")

from ai.camera import CameraCapture
from ai.face_detector import FaceDetector
from ai.gaze_detector import GazeDetector
from ai.head_tracker import HeadTracker
from ai.object_detector import ObjectDetector

def main():
    print("\n=== Starting camera ===")
    cam = CameraCapture(index=0, width=640, height=480, fps=15)
    if not cam.start():
        print("Camera failed to open.")
        return

    time.sleep(1.0)  # let camera warm up

    print("\n=== Initializing detectors ===")
    face_det = FaceDetector()
    gaze_det = GazeDetector()
    head_det = HeadTracker()
    obj_det = ObjectDetector()

    print("\n=== Running 20 detections (0.5s apart) ===")
    print("Instructions: look at camera for first 5, then look away left/right/up/down.\n")

    for i in range(20):
        frame = cam.read()
        if frame is None:
            print(f"[{i}] no frame yet")
            time.sleep(0.5)
            continue

        t0 = time.time()
        face = face_det.detect(frame)
        gaze = gaze_det.detect(frame)
        head = head_det.detect(frame)
        obj = obj_det.detect(frame, face_box=face.box)
        dt = (time.time() - t0) * 1000

        print(
            f"[{i:02d}] dt={dt:5.0f}ms  "
            f"faces={face.face_count}  "
            f"gaze={gaze.direction:10s} (h={gaze.h_offset:+.2f}, v={gaze.v_offset:+.2f})  "
            f"head={head.direction:6s} (yaw={head.yaw:+.2f}, pitch={head.pitch:+.2f})  "
            f"hands={obj.hand_count} phone={obj.phone_suspected}"
        )
        time.sleep(0.5)

    print("\n=== Cleanup ===")
    cam.stop()
    face_det.close()
    gaze_det.close()
    head_det.close()
    obj_det.close()
    print("Done.")

if __name__ == "__main__":
    main()