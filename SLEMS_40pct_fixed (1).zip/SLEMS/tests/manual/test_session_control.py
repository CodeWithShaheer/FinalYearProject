import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))  # run from anywhere
# test_session_control.py  (temporary — delete after Phase 4)
import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout

from gui.common import theme
from gui.teacher.session_control import SessionControlPage
from database.migrations import init_db
from utils.logger import setup_logging


def main():
    setup_logging()
    init_db()

    app = QApplication(sys.argv)
    app.setStyleSheet(theme.build_stylesheet())

    win = QMainWindow()
    win.setWindowTitle("Session Control Test — SLEMS v2.0")
    win.resize(1500, 950)

    central = QWidget()
    layout = QVBoxLayout(central)
    layout.setContentsMargins(0, 0, 0, 0)

    sc = SessionControlPage()
    layout.addWidget(sc)

    win.setCentralWidget(central)
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()