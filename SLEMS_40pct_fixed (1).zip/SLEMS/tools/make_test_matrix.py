"""
tools/make_test_matrix.py
Runs the automated tests and writes the TEST MATRIX used in the report (S13):

    docs/TEST_MATRIX.md    - readable table (paste into the documentation)
    docs/TEST_MATRIX.csv   - open in Excel; fill the "Screenshot" column by hand

    python tools/make_test_matrix.py            # needs PostgreSQL running
Each row = requirement ID, what is tested, expected result, ACTUAL result from this run.
"""
import csv
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# test function -> (Req ID, requirement, expected result)
MATRIX = {
 # ---- Service Blocking Engine
 "test_monitor_detects_only_blocklisted": ("BLK-1", "Detect only blocklisted apps", "Listed app found; unlisted app ignored"),
 "test_blocker_kills_process": ("BLK-2", "Terminate a blocked process", "Process is gone after terminate_all"),
 "test_engine_kills_new_app_within_2_seconds": ("BLK-2", "Blocked app killed within 2 s of launch", "Killed in < 2000 ms; latency + violation recorded"),
 "test_never_kills_itself_or_parent": ("BLK-5", "Never kill SLEMS or its parent", "Own/parent process survives, monitor and blocker refuse"),
 "test_system_processes_are_whitelisted": ("BLK-5", "System processes protected", "explorer, svchost, lsass, winlogon, python whitelisted"),
 "test_unknown_app_name_gets_default_profile": ("BLK-1", "Unknown app names still match", "<name>.exe profile generated"),
 "test_block_then_restore_is_byte_identical": ("BLK-4", "Hosts file restored exactly", "File identical to the original, byte for byte"),
 "test_restore_is_idempotent": ("BLK-4", "Restore twice is safe", "No change, no error"),
 "test_block_twice_does_not_duplicate": ("BLK-3", "Re-blocking does not duplicate", "One SLEMS block only"),
 "test_crash_then_startup_recovery": ("BLK-4", "Crash recovery on next start", "Process killed mid-block -> next start cleans the file"),
 "test_missing_end_marker_does_not_eat_user_entries": ("BLK-4", "Damaged block never deletes user entries", "User line kept, SLEMS lines removed"),
 "test_missing_end_marker_also_removes_ipv6_lines": ("BLK-4", "Damaged block incl. IPv6 lines", "All SLEMS lines removed, user line kept"),
 "test_backup_is_clean_and_pruned": ("BLK-4", "Backups are clean and limited to 5", "No SLEMS block in backups; <= 5 files"),
 "test_normalize_domain": ("BLK-3", "Domain input cleaned", "URL/port/www stripped; invalid rejected"),
 "test_engine_restores_hosts_even_if_stopped_abruptly": ("BLK-4", "Engine always restores hosts", "Original hosts after stop_and_restore"),
 "test_presets_cover_subdomains_and_expand_cleanly": ("S1", "Presets list explicit sub-domains", "chat.openai.com etc. present; all entries valid"),
 "test_no_path_style_entries_are_offered_in_the_ui_lists": ("S1", "No misleading path entries", "No 'site.com/page' entries in lists"),
 "test_allowlist_only_closes_apps_that_are_not_allowed": ("S5", "Allow-list closes only unlisted apps", "Unlisted closed; allowed + system app survive"),
 "test_allowlist_refuses_empty_list": ("S5", "Empty allow-list refused", "Nothing is closed"),
 "test_engine_allowlist_mode_end_to_end": ("S5", "Allow-list inside the engine", "Unlisted app closed, allowed app kept"),
 "test_pause_releases_everything_and_resume_restores_it": ("S4", "Emergency pause / resume", "Paused: hosts clean + app survives; resumed: blocked again"),
 # ---- Database / auth
 "test_password_roundtrip_and_salt": ("DB-3", "bcrypt hashing is salted", "Same password -> different hashes; verify works"),
 "test_legacy_sha256_accepted_and_upgraded": ("DB-3", "Old accounts keep working", "Login ok and hash upgraded to bcrypt"),
 "test_lockout_after_five_failures": ("DB-3", "Lockout after 5 wrong passwords", "Locked, even correct password refused, unlocks later"),
 "test_unknown_email_gives_generic_error": ("DB-3", "No user enumeration", "Same message for unknown email"),
 "test_violation_filter_review_and_csv": ("DB-4", "Violation filter / review / CSV", "Filters work, dismiss hides, CSV has all rows"),
 "test_teacher_signup_needs_key_but_students_do_not": ("S9", "Teacher sign-up needs a key", "Wrong/missing key refused; students free"),
 # ---- Dashboard link
 "test_teacher_student_link": ("NET-1..5", "Join, config, violation, file upload, end", "All steps succeed; hash of uploaded file matches"),
 "test_wrong_code_brute_force_is_throttled": ("S7", "Join-code brute force blocked", "10 wrong codes -> locked out"),
 "test_roster_blocks_unregistered_students": ("S8", "Roster enforced", "Unregistered refused; registered becomes active"),
 "test_without_roster_requirement_anyone_can_join": ("S8", "Open mode still works", "Any roll number can join"),
 "test_student_closing_slems_mid_exam_is_flagged": ("S3", "Abrupt close flagged", "High-severity violation + client_offline event"),
 "test_student_logging_out_mid_exam_is_flagged": ("S3", "Logout mid-exam flagged", "'left the exam' violation"),
 "test_block_events_latency_and_emergency_override": ("S6/S4", "Block events, latency stats, override audit", "Events + stats + audit rows + CSV evidence"),
 # ---- GUI
 "test_gui_smoke": ("UI-1..3, S1,S4,S6,S10,S12", "Full scenario on the real screens", "Start Exam, join code, roster, table, pause, kill, auto-submit, End, auto-end, offline"),
}


def main():
    xml_path = Path(tempfile.gettempdir()) / "slems_junit.xml"
    cmd = [sys.executable, "-m", "pytest", "tests", "-q", "-p", "no:cacheprovider", f"--junitxml={xml_path}"]
    subprocess.run(cmd, cwd=ROOT, check=False)
    rows = []
    for tc in ET.parse(xml_path).getroot().iter("testcase"):
        name = tc.get("name")
        failed = tc.find("failure") is not None or tc.find("error") is not None
        skipped = tc.find("skipped") is not None
        req, what, expected = MATRIX.get(name, ("?", name, "(add this test to MATRIX)"))
        rows.append((req, what, expected, "FAIL" if failed else ("SKIP" if skipped else "PASS"),
                     f"{float(tc.get('time', 0)):.2f}", tc.get("classname", "").split(".")[-1] + "::" + name))
    rows.sort(key=lambda r: (r[0], r[1]))

    (ROOT / "docs").mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    passed = sum(1 for r in rows if r[3] == "PASS")
    md = ["# SLEMS test matrix (40% milestone)", "",
          f"Generated {stamp} - **{passed}/{len(rows)} passed**.  Screenshot column: fill in by hand.", "",
          "| Req | What is tested | Expected | Actual | Time (s) | Test | Screenshot |",
          "|---|---|---|---|---|---|---|"]
    for req, what, exp, res, t, test in rows:
        md.append(f"| {req} | {what} | {exp} | **{res}** | {t} | `{test}` | |")
    (ROOT / "docs" / "TEST_MATRIX.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    with open(ROOT / "docs" / "TEST_MATRIX.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["Req", "What is tested", "Expected", "Actual", "Time (s)", "Test", "Screenshot"])
        for r in rows:
            w.writerow(list(r) + [""])
    print(f"\nWrote docs/TEST_MATRIX.md and .csv  ({passed}/{len(rows)} passed)")
    return 0 if passed == len(rows) else 1


if __name__ == "__main__":
    sys.exit(main())
