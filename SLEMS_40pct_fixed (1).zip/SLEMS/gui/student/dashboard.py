"""
gui/student/dashboard.py
SLEMS Student Dashboard — network + WebRTC + AI + Blocking.

v5.0:
    - BlockingEngine starts after AI Worker (on connect)
    - Blocking violations forwarded to teacher via same TCP channel
    - AI panel shows blocking state
"""
import asyncio
import logging
import os
import shutil
import sys
from datetime import datetime

from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QThread
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QVBoxLayout, QHBoxLayout,
    QPushButton, QScrollArea, QFrame, QFileDialog, QMessageBox,
    QStackedWidget, QProgressBar, QGraphicsDropShadowEffect, QTableWidget,
    QTableWidgetItem, QHeaderView, QButtonGroup,
)
from PyQt5.QtGui import QColor

from gui.common import theme
from config.settings import SUBMISSIONS_DIR, MAX_EXAM_PAPER_SIZE_BYTES
from gui.student.connect_page import StudentConnectPage
from gui.student.ai_status_panel import AiStatusPanel
from network.student_client import (
    StudentClient,
    EVT_CONNECTED, EVT_CONFIG_RECEIVED, EVT_SESSION_ENDED,
    EVT_DISCONNECTED, EVT_ERROR, EVT_BLOCK_PAUSE, EVT_BLOCK_RESUME,
)
from config.settings import ENABLE_AI_MONITORING, ENABLE_P2P_STREAMING
from blocking.blocking_engine import BlockingEngine
from utils.helpers import format_hms


logger = logging.getLogger(__name__)


def _drop_shadow(blur=20, y_offset=4):
    eff = QGraphicsDropShadowEffect()
    eff.setBlurRadius(blur)
    eff.setOffset(0, y_offset)
    eff.setColor(QColor(16, 24, 40, 40))
    return eff


# ===========================================================================
class StudentClientWorker(QThread):
    connected = pyqtSignal(dict)
    config_received = pyqtSignal(dict)
    session_ended = pyqtSignal()
    disconnected = pyqtSignal(dict)
    error = pyqtSignal(str)
    submission_progress = pyqtSignal(int)
    submission_finished = pyqtSignal(bool, str)
    block_paused = pyqtSignal(str)
    block_resumed = pyqtSignal()

    def __init__(self, teacher_ip, teacher_port, session_code, roll_no, parent=None):
        super().__init__(parent)
        self.teacher_ip = teacher_ip
        self.teacher_port = teacher_port
        self.session_code = session_code
        self.roll_no = roll_no
        self._loop: asyncio.AbstractEventLoop = None
        self._client: StudentClient = None
        self._peer = None
        self._stop_flag = False

    def run(self):
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self._client = StudentClient()
        self._client.on_event(self._on_client_event)
        self._client.set_webrtc_handler(self._on_webrtc_message)
        try:
            ok, msg = self._loop.run_until_complete(
                self._client.connect(
                    self.teacher_ip, self.teacher_port,
                    self.roll_no, self.session_code,
                )
            )
            if not ok:
                self.error.emit(msg)
                return
            if ENABLE_P2P_STREAMING:
                self._loop.run_until_complete(self._start_webrtc())
            self._loop.run_forever()
        except Exception as e:
            logger.exception("StudentClientWorker crashed")
            self.error.emit(str(e))
        finally:
            try:
                if self._loop and not self._loop.is_closed():
                    if self._peer:
                        self._loop.run_until_complete(self._peer.close())
                    if self._client:
                        self._loop.run_until_complete(self._client.disconnect("worker_end"))
            except Exception:
                pass
            if self._loop:
                self._loop.close()

    async def _start_webrtc(self):
        try:
            from webrtc.student_peer import StudentPeer   # lazy: needs aiortc
            self._peer = StudentPeer(
                on_local_sdp=self._on_local_sdp,
                on_local_ice=self._on_local_ice,
            )
            await self._peer.start()
            offer = await self._peer.create_offer()
            await self._client.send_webrtc_offer(offer)
        except Exception:
            logger.exception("WebRTC start failed")

    def _on_client_event(self, event_type, payload):
        if event_type == EVT_CONNECTED: self.connected.emit(payload)
        elif event_type == EVT_CONFIG_RECEIVED: self.config_received.emit(payload)
        elif event_type == EVT_SESSION_ENDED: self.session_ended.emit()
        elif event_type == EVT_DISCONNECTED: self.disconnected.emit(payload)
        elif event_type == EVT_ERROR: self.error.emit(payload.get("message", "unknown"))
        elif event_type == EVT_BLOCK_PAUSE: self.block_paused.emit(payload.get("reason", ""))
        elif event_type == EVT_BLOCK_RESUME: self.block_resumed.emit()

    def _on_webrtc_message(self, kind, payload):
        if self._peer is None: return None
        if kind == "answer" and isinstance(payload, dict):
            return self._peer.set_remote_answer(payload)
        if kind == "ice" and isinstance(payload, dict):
            return self._peer.add_remote_ice(payload)
        return None

    def _on_local_sdp(self, sdp):
        if self._loop and self._client:
            asyncio.run_coroutine_threadsafe(
                self._client.send_webrtc_offer(sdp), self._loop)

    def _on_local_ice(self, candidate):
        if self._loop and self._client:
            asyncio.run_coroutine_threadsafe(
                self._client.send_webrtc_ice(candidate), self._loop)

    def upload_submission(self, file_path: str):
        """Start a file upload to the teacher (non-blocking; results via signals)."""
        if not (self._loop and self._client) or self._loop.is_closed():
            self.submission_finished.emit(False, "Not connected to the teacher.")
            return

        async def _run():
            ok, msg, _ = await self._client.send_submission(
                file_path, progress_cb=self.submission_progress.emit)
            self.submission_finished.emit(ok, msg)

        asyncio.run_coroutine_threadsafe(_run(), self._loop)

    def send_block_event(self, event_type, target="", pid=None, latency_ms=None, detail=""):
        """Tell the teacher about a kill / block (stored with timestamp + latency)."""
        if self._loop and self._client and not self._loop.is_closed():
            asyncio.run_coroutine_threadsafe(
                self._client.send_block_event(event_type, target, pid, latency_ms, detail),
                self._loop)

    def send_violation(self, vtype, desc, severity="medium"):
        if self._loop and self._client:
            asyncio.run_coroutine_threadsafe(
                self._client.send_violation(vtype, desc, severity), self._loop)

    def stop(self):
        """
        Safe to call at any time (before connect, after a failed connect,
        twice).  The worker's own `finally` block closes the WebRTC peer and
        disconnects the client, so we only need to stop the loop here.
        """
        self._stop_flag = True
        loop = self._loop
        if loop is None or loop.is_closed() or not self.isRunning():
            return
        try:
            loop.call_soon_threadsafe(loop.stop)
        except RuntimeError:
            pass        # loop closed between the check and the call
        self.wait(3000)


# ===========================================================================
class StudentDashboard(QMainWindow):
    logout_requested = pyqtSignal()

    NAV_ITEMS = [
        ("exam", "My Exam"),
        ("submissions", "My Submissions"),
        ("rules", "Exam Rules"),
    ]

    def __init__(self, user: dict = None):
        super().__init__()
        self.user = user or {"full_name": "Student", "role": "student"}
        self.setWindowTitle("SLEMS - Student Dashboard")
        self.resize(1400, 900)
        self.client_worker = None
        self.ai_worker = None
        self.blocking_engine = None
        self.session_meta = {}
        self._remaining_seconds = 0
        self._total_seconds = 1
        self._timer = None
        self._connected = False

        self.central_stack = QStackedWidget()
        self.setCentralWidget(self.central_stack)

        self.connect_page = StudentConnectPage(student_info=self.user)
        self.connect_page.connect_requested.connect(self._on_connect_requested)
        self.central_stack.addWidget(self.connect_page)

        self.main_widget = self._build_main_dashboard()
        self.central_stack.addWidget(self.main_widget)
        self.central_stack.setCurrentIndex(0)

    # ==================================================================
    def _build_main_dashboard(self):
        central = QWidget()
        central.setObjectName("centralArea")
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        root.addWidget(self._build_sidebar())

        right_col = QVBoxLayout()
        right_col.setContentsMargins(0, 0, 0, 0)
        right_col.setSpacing(0)
        right_col.addWidget(self._build_top_bar())

        self.stack = QStackedWidget()
        self.pages = {
            "exam": self._build_exam_page(),
            "submissions": self._build_submissions_page(),
            "rules": self._build_rules_page(),
        }
        for key, _ in self.NAV_ITEMS:
            self.stack.addWidget(self.pages[key])
        right_col.addWidget(self.stack, stretch=1)
        right_wrap = QWidget()
        right_wrap.setLayout(right_col)
        root.addWidget(right_wrap, stretch=1)
        self._select_nav("exam")
        return central

    # -------- Sidebar --------
    def _build_sidebar(self):
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(280)
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(24, 30, 24, 24)
        layout.setSpacing(8)
        logo = QLabel("SLEMS")
        logo.setObjectName("sidebarLogo")
        layout.addWidget(logo)
        sub = QLabel("NUML - Faisalabad Campus")
        sub.setObjectName("sidebarSubtitle")
        layout.addWidget(sub)
        layout.addSpacing(32)

        self.nav_buttons = {}
        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)
        for key, label in self.NAV_ITEMS:
            btn = QPushButton(label)
            btn.setObjectName("navButton")
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _, k=key: self._select_nav(k))
            self.nav_group.addButton(btn)
            self.nav_buttons[key] = btn
            layout.addWidget(btn)
        layout.addStretch()

        profile_card = QFrame()
        profile_card.setStyleSheet(f"QFrame {{ background: {theme.NAVY}; border-radius: 14px; }}")
        pl = QVBoxLayout(profile_card)
        pl.setContentsMargins(18, 16, 18, 16)
        pl.setSpacing(10)
        avatar = QLabel(self.user.get("full_name", "S")[:1].upper())
        avatar.setStyleSheet(f"""
            background: {theme.GOLD}; color: {theme.NAVY_DARK};
            font-size: 24px; font-weight: 800; border-radius: 25px;
        """)
        avatar.setFixedSize(50, 50)
        avatar.setAlignment(Qt.AlignCenter)
        pl.addWidget(avatar, alignment=Qt.AlignCenter)
        name_lbl = QLabel(self.user.get("full_name", "Student"))
        name_lbl.setStyleSheet(f"color: {theme.TEXT_ON_NAVY}; font-size: 16px; font-weight: 700;")
        name_lbl.setAlignment(Qt.AlignCenter)
        pl.addWidget(name_lbl)
        roll_lbl = QLabel(f"Roll: {self.user.get('roll_no', 'N/A')}")
        roll_lbl.setStyleSheet(f"color: {theme.GOLD_LIGHT}; font-size: 13px; font-weight: 600;")
        roll_lbl.setAlignment(Qt.AlignCenter)
        pl.addWidget(roll_lbl)
        line = QFrame()
        line.setStyleSheet(f"background: {theme.NAVY_LIGHT};")
        line.setFixedHeight(2)
        pl.addWidget(line)
        logout_btn = QPushButton("Logout")
        logout_btn.setFixedHeight(44)
        logout_btn.setStyleSheet(f"""
            QPushButton {{
                background: {theme.STATUS_BEHAVIORAL}; color: white;
                border: none; border-radius: 10px;
                font-size: 14px; font-weight: 700;
            }}
            QPushButton:hover {{ background: #C43030; }}
        """)
        logout_btn.setCursor(Qt.PointingHandCursor)
        logout_btn.clicked.connect(self._on_logout)
        pl.addWidget(logout_btn)
        layout.addWidget(profile_card)
        return sidebar

    def _on_logout(self):
        reply = QMessageBox.question(
            self, "Logout", "Disconnect from exam and logout?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            self._shutdown_all()
            self.logout_requested.emit()

    def closeEvent(self, event):
        self._shutdown_all()
        super().closeEvent(event)

    def _stop_blocking(self):
        """Stop process/domain blocking and make sure the hosts file is restored."""
        engine, self.blocking_engine = self.blocking_engine, None
        if engine is None:
            return
        try:
            engine.stop_and_restore(5000)
        except Exception:
            logger.exception("Stopping blocking engine failed")
            # last resort: clean the hosts file directly
            try:
                from blocking.hosts_manager import HostsManager
                HostsManager().restore()
            except Exception:
                logger.exception("Direct hosts restore failed")

    def _shutdown_all(self):
        self._stop_blocking()
        if self.ai_worker:
            try:
                self.ai_worker.stop()
                self.ai_worker.wait(2500)
            except Exception:
                logger.exception("Stopping AI worker failed")
            self.ai_worker = None
        if self.client_worker:
            try:
                self.client_worker.stop()
            except Exception:
                logger.exception("Stopping client worker failed")
            self.client_worker = None
        if self._timer:
            self._timer.stop()
        self._connected = False

    # -------- Top bar --------
    def _build_top_bar(self):
        bar = QFrame()
        bar.setObjectName("topBar")
        bar.setFixedHeight(80)
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(24, 12, 32, 12)
        layout.setSpacing(14)
        title_col = QVBoxLayout()
        title_col.setSpacing(2)
        self.page_title_lbl = QLabel("My Exam")
        self.page_title_lbl.setObjectName("topBarTitle")
        self.page_subtitle_lbl = QLabel("Smart Lab Exam Monitoring System")
        self.page_subtitle_lbl.setObjectName("topBarSubtitle")
        title_col.addWidget(self.page_title_lbl)
        title_col.addWidget(self.page_subtitle_lbl)
        layout.addLayout(title_col)
        layout.addStretch()
        timer_widget = QFrame()
        timer_widget.setStyleSheet(f"""
            QFrame {{
                background: {theme.BG}; border: 1px solid {theme.BORDER};
                border-radius: 10px;
            }}
        """)
        tl = QHBoxLayout(timer_widget)
        tl.setContentsMargins(12, 6, 12, 6)
        tl.setSpacing(6)
        clock_icon = QLabel("◷")
        clock_icon.setStyleSheet(f"color: {theme.NAVY}; font-size: 16px;")
        tl.addWidget(clock_icon)
        self.timer_lbl = QLabel("--:--:--")
        self.timer_lbl.setStyleSheet(f"color: {theme.NAVY}; font-size: 20px; font-weight: 700;")
        tl.addWidget(self.timer_lbl)
        layout.addWidget(timer_widget)
        return bar

    # -------- Exam page --------
    def _build_exam_page(self):
        page = QWidget()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("background: transparent; border: none;")
        container = QWidget()
        container.setStyleSheet("background: transparent;")
        root = QVBoxLayout(container)
        root.setContentsMargins(28, 24, 28, 28)
        root.setSpacing(20)

        # Session card
        self.session_card = QFrame()
        self.session_card.setStyleSheet(f"""
            QFrame {{
                background: {theme.CARD_BG}; border: 1px solid {theme.BORDER};
                border-radius: 14px;
            }}
        """)
        self.session_card.setGraphicsEffect(_drop_shadow(blur=24, y_offset=6))
        sl = QVBoxLayout(self.session_card)
        sl.setContentsMargins(24, 20, 24, 20)
        sl.setSpacing(16)
        header_row = QHBoxLayout()
        exam_icon = QLabel("◆")
        exam_icon.setStyleSheet(f"color: {theme.NAVY}; font-size: 18px; font-weight: 700;")
        header_row.addWidget(exam_icon)
        self.session_title = QLabel("Connecting…")
        self.session_title.setStyleSheet(f"font-size: 20px; font-weight: 700; color: {theme.NAVY_DARK};")
        header_row.addWidget(self.session_title)
        header_row.addStretch()
        self.session_status_badge = QLabel("WAITING")
        self.session_status_badge.setStyleSheet(f"""
            background: {theme.STATUS_SERVICE}; color: white;
            font-size: 12px; font-weight: 700; border-radius: 8px; padding: 4px 12px;
        """)
        header_row.addWidget(self.session_status_badge)
        sl.addLayout(header_row)

        details_row = QHBoxLayout()
        details_row.setSpacing(30)
        def _kv(t):
            col = QVBoxLayout()
            col.setSpacing(4)
            l = QLabel(t)
            l.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 13px; font-weight: 600;")
            col.addWidget(l)
            v = QLabel("--")
            v.setStyleSheet(f"color: {theme.TEXT_PRIMARY}; font-size: 16px; font-weight: 700;")
            col.addWidget(v)
            return col, v
        course_col, self.course_value = _kv("Course")
        dur_col, self.dur_value = _kv("Duration")
        time_col, self.time_value = _kv("Time Remaining")
        self.time_value.setStyleSheet(f"color: {theme.STATUS_BEHAVIORAL}; font-size: 16px; font-weight: 700;")
        details_row.addLayout(course_col)
        details_row.addLayout(dur_col)
        details_row.addLayout(time_col)
        details_row.addStretch()
        sl.addLayout(details_row)
        self.time_progress = QProgressBar()
        self.time_progress.setRange(0, 100)
        self.time_progress.setValue(0)
        self.time_progress.setTextVisible(False)
        self.time_progress.setFixedHeight(8)
        self.time_progress.setStyleSheet(f"""
            QProgressBar {{ border: none; border-radius: 4px; background: {theme.BORDER}; }}
            QProgressBar::chunk {{
                border-radius: 4px;
                background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 {theme.NAVY}, stop:1 {theme.GOLD});
            }}
        """)
        sl.addWidget(self.time_progress)
        root.addWidget(self.session_card)

        self.ai_panel = AiStatusPanel()
        root.addWidget(self.ai_panel)

        # NEW: Blocking status card
        self.blocking_card = QFrame()
        self.blocking_card.setStyleSheet(f"""
            QFrame {{
                background: {theme.CARD_BG}; border: 1px solid {theme.BORDER};
                border-radius: 14px;
            }}
        """)
        self.blocking_card.setGraphicsEffect(_drop_shadow(blur=16, y_offset=3))
        bcl = QVBoxLayout(self.blocking_card)
        bcl.setContentsMargins(20, 16, 20, 16)
        bcl.setSpacing(10)

        bch = QHBoxLayout()
        bt = QLabel("Exam Restrictions")
        bt.setStyleSheet(f"font-size: 16px; font-weight: 700; color: {theme.NAVY_DARK};")
        bch.addWidget(bt)
        bch.addStretch()
        self.blocking_state_lbl = QLabel("● inactive")
        self.blocking_state_lbl.setStyleSheet(
            f"color: {theme.STATUS_DISCONNECTED}; font-size: 12px; font-weight: 700;"
        )
        bch.addWidget(self.blocking_state_lbl)
        bcl.addLayout(bch)

        self.blocking_info_lbl = QLabel("Waiting for session config…")
        self.blocking_info_lbl.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 13px;")
        self.blocking_info_lbl.setWordWrap(True)
        bcl.addWidget(self.blocking_info_lbl)

        stats_row = QHBoxLayout()
        stats_row.setSpacing(10)
        self.killed_lbl = QLabel("Blocked processes: 0")
        self.killed_lbl.setStyleSheet(f"color: {theme.TEXT_PRIMARY}; font-size: 13px; font-weight: 600;")
        stats_row.addWidget(self.killed_lbl)
        stats_row.addStretch()
        self.hosts_lbl = QLabel("Hosts: —")
        self.hosts_lbl.setStyleSheet(f"color: {theme.TEXT_PRIMARY}; font-size: 13px; font-weight: 600;")
        stats_row.addWidget(self.hosts_lbl)
        bcl.addLayout(stats_row)

        root.addWidget(self.blocking_card)

        # Submission card
        submit_card = QFrame()
        submit_card.setStyleSheet(f"""
            QFrame {{
                background: {theme.CARD_BG}; border: 1px solid {theme.BORDER};
                border-radius: 14px;
            }}
        """)
        submit_card.setGraphicsEffect(_drop_shadow(blur=20, y_offset=4))
        subl = QVBoxLayout(submit_card)
        subl.setContentsMargins(24, 20, 24, 20)
        subl.setSpacing(16)
        sh = QHBoxLayout()
        st = QLabel("Submit Your Lab Exam")
        st.setStyleSheet(f"font-size: 18px; font-weight: 700; color: {theme.NAVY_DARK};")
        sh.addWidget(st)
        sh.addStretch()
        self.submit_status_badge = QLabel("NOT SUBMITTED")
        self.submit_status_badge.setStyleSheet(f"""
            background: {theme.STATUS_BEHAVIORAL}; color: white;
            font-size: 12px; font-weight: 700; border-radius: 8px; padding: 4px 12px;
        """)
        sh.addWidget(self.submit_status_badge)
        subl.addLayout(sh)
        self.selected_file_lbl = QLabel("No file selected")
        self.selected_file_lbl.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 14px; padding: 8px;")
        subl.addWidget(self.selected_file_lbl)
        btn_row = QHBoxLayout()
        self.browse_btn = QPushButton("Browse Files")
        self.browse_btn.setMinimumHeight(48)
        self.browse_btn.setStyleSheet(f"""
            QPushButton {{
                background: {theme.NAVY}; color: white;
                border: none; border-radius: 10px;
                padding: 12px 28px; font-size: 15px; font-weight: 700;
            }}
            QPushButton:hover {{ background: {theme.NAVY_LIGHT}; }}
            QPushButton:disabled {{ background: #B7BEC9; }}
        """)
        self.browse_btn.setCursor(Qt.PointingHandCursor)
        self.browse_btn.clicked.connect(self._browse_file)
        btn_row.addWidget(self.browse_btn)
        self.submit_btn = QPushButton("Submit Lab Exam")
        self.submit_btn.setMinimumHeight(48)
        self.submit_btn.setStyleSheet(f"""
            QPushButton {{
                background: {theme.STATUS_NORMAL}; color: white;
                border: none; border-radius: 10px;
                padding: 12px 28px; font-size: 15px; font-weight: 700;
            }}
            QPushButton:hover {{ background: #25963F; }}
            QPushButton:disabled {{ background: #B7BEC9; }}
        """)
        self.submit_btn.setCursor(Qt.PointingHandCursor)
        self.submit_btn.setEnabled(False)
        self.submit_btn.clicked.connect(self._submit_file)
        btn_row.addWidget(self.submit_btn)
        btn_row.addStretch()
        subl.addLayout(btn_row)
        root.addWidget(submit_card)

        # Blocked reminder
        blocked_card = QFrame()
        blocked_card.setStyleSheet(f"""
            QFrame {{
                background: {theme.CARD_BG}; border: 1px solid {theme.BORDER};
                border-radius: 14px;
            }}
        """)
        bl = QVBoxLayout(blocked_card)
        bl.setContentsMargins(24, 20, 24, 20)
        bl.setSpacing(12)
        bt = QLabel("Restricted During Exam")
        bt.setStyleSheet(f"font-size: 16px; font-weight: 700; color: {theme.NAVY_DARK};")
        bl.addWidget(bt)
        self.blocked_apps_lbl = QLabel("—")
        self.blocked_apps_lbl.setStyleSheet(
            f"color: {theme.STATUS_BEHAVIORAL}; font-size: 12px; font-weight: 600;"
            f" background: #FDECEC; border-radius: 6px; padding: 8px 12px;")
        self.blocked_apps_lbl.setWordWrap(True)
        bl.addWidget(self.blocked_apps_lbl)
        self.blocked_domains_lbl = QLabel("—")
        self.blocked_domains_lbl.setStyleSheet(
            f"color: {theme.STATUS_BEHAVIORAL}; font-size: 12px; font-weight: 600;"
            f" background: #FDECEC; border-radius: 6px; padding: 8px 12px;")
        self.blocked_domains_lbl.setWordWrap(True)
        bl.addWidget(self.blocked_domains_lbl)
        root.addWidget(blocked_card)
        root.addStretch()

        scroll.setWidget(container)
        wrapper = QWidget()
        wl = QVBoxLayout(wrapper)
        wl.setContentsMargins(0, 0, 0, 0)
        wl.addWidget(scroll)
        return wrapper

    def _build_submissions_page(self):
        page = QWidget()
        root = QVBoxLayout(page)
        root.setContentsMargins(28, 24, 28, 28)
        root.setSpacing(20)
        header = QLabel("My Submissions")
        header.setStyleSheet(f"font-size: 24px; font-weight: 800; color: {theme.NAVY_DARK};")
        root.addWidget(header)
        sub = QLabel("Local copy of submissions made on this device.")
        sub.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 14px;")
        root.addWidget(sub)
        self.submissions_table = QTableWidget(0, 3)
        self.submissions_table.setHorizontalHeaderLabels(["File Name", "Size", "Submitted At"])
        self.submissions_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        for col in [1, 2]:
            self.submissions_table.horizontalHeader().setSectionResizeMode(col, QHeaderView.ResizeToContents)
        self.submissions_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.submissions_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.submissions_table.verticalHeader().setVisible(False)
        self.submissions_table.setMinimumHeight(300)
        root.addWidget(self.submissions_table)
        root.addStretch()
        self._refresh_local_submissions()
        return page

    def _refresh_local_submissions(self):
        try:
            files = sorted(
                [f for f in os.listdir(SUBMISSIONS_DIR)
                 if os.path.isfile(os.path.join(SUBMISSIONS_DIR, f))],
                key=lambda x: os.path.getmtime(os.path.join(SUBMISSIONS_DIR, x)),
                reverse=True)
        except OSError:
            files = []
        self.submissions_table.setRowCount(len(files))
        for row, f in enumerate(files):
            path = os.path.join(SUBMISSIONS_DIR, f)
            try:
                size = os.path.getsize(path)
                mtime = datetime.fromtimestamp(os.path.getmtime(path)).strftime("%d %b %Y, %I:%M %p")
            except OSError:
                size, mtime = 0, "—"
            self.submissions_table.setItem(row, 0, QTableWidgetItem(f))
            self.submissions_table.setItem(row, 1, QTableWidgetItem(f"{size/1024:.1f} KB"))
            self.submissions_table.setItem(row, 2, QTableWidgetItem(mtime))

    def _build_rules_page(self):
        page = QWidget()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("background: transparent; border: none;")
        container = QWidget()
        root = QVBoxLayout(container)
        root.setContentsMargins(28, 24, 28, 28)
        root.setSpacing(20)
        header = QLabel("Exam Rules & Guidelines")
        header.setStyleSheet(f"font-size: 24px; font-weight: 800; color: {theme.NAVY_DARK};")
        root.addWidget(header)
        rules = [
            ("1. Academic Integrity", "All submitted work must be your own."),
            ("2. Prohibited Software", "ChatGPT, WhatsApp, Discord, TeamViewer, and AI tools are prohibited."),
            ("3. Browser Restrictions", "External help sites are blocked."),
            ("4. Camera & Screen Monitoring", "Camera and screen may be monitored in real-time."),
            ("5. Time Limit", "Submit within the allocated time."),
            ("6. File Format", "Submit as .docx, .pdf, or .zip."),
            ("7. Single Submission", "Only the last submission before deadline is evaluated."),
            ("8. Technical Issues", "Raise your hand immediately."),
        ]
        for title, desc in rules:
            rc = QFrame()
            rc.setStyleSheet(f"""
                QFrame {{
                    background: {theme.CARD_BG}; border: 1px solid {theme.BORDER};
                    border-radius: 12px;
                }}
            """)
            rc.setGraphicsEffect(_drop_shadow(blur=12, y_offset=2))
            rl = QVBoxLayout(rc)
            rl.setContentsMargins(20, 16, 20, 16)
            rl.setSpacing(8)
            tl = QLabel(title)
            tl.setStyleSheet(f"font-size: 16px; font-weight: 700; color: {theme.NAVY_DARK};")
            rl.addWidget(tl)
            dl = QLabel(desc)
            dl.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 14px;")
            dl.setWordWrap(True)
            rl.addWidget(dl)
            root.addWidget(rc)
        root.addStretch()
        scroll.setWidget(container)
        wrapper = QWidget()
        wl = QVBoxLayout(wrapper)
        wl.setContentsMargins(0, 0, 0, 0)
        wl.addWidget(scroll)
        return wrapper

    def _select_nav(self, key):
        self.nav_buttons[key].setChecked(True)
        index = [k for k, _ in self.NAV_ITEMS].index(key)
        self.stack.setCurrentIndex(index)
        titles = {"exam": "My Exam", "submissions": "My Submissions", "rules": "Exam Rules"}
        self.page_title_lbl.setText(titles[key])
        if key == "submissions":
            self._refresh_local_submissions()

    def _on_connect_requested(self, ip, port, code, roll):
        if self.client_worker:
            self.client_worker.stop()
            self.client_worker = None
        self.client_worker = StudentClientWorker(ip, port, code, roll, parent=self)
        self.client_worker.connected.connect(self._on_client_connected)
        self.client_worker.config_received.connect(self._on_client_config)
        self.client_worker.session_ended.connect(self._on_session_ended)
        self.client_worker.disconnected.connect(self._on_client_disconnected)
        self.client_worker.error.connect(self._on_client_error)
        self.client_worker.submission_progress.connect(self._on_submit_progress)
        self.client_worker.submission_finished.connect(self._on_submit_finished)
        self.client_worker.block_paused.connect(self._on_block_paused)
        self.client_worker.block_resumed.connect(self._on_block_resumed)
        self.client_worker.start()

    def _on_client_connected(self, payload):
        self._connected = True
        self.connect_page.on_connect_result(True, "Connected.")

    def _on_client_config(self, payload):
        self.session_meta = payload
        self.central_stack.setCurrentIndex(1)

        course = payload.get("course_name", "—")
        duration = int(payload.get("duration") or 0)
        title = payload.get("exam_title") or course
        blocked_apps = payload.get("blocked_apps", []) or []
        blocked_domains = payload.get("blocked_domains", []) or []
        security_options = payload.get("security_options", {}) or {}

        self.session_title.setText(f"Active Exam: {title}")
        self.session_status_badge.setText("ACTIVE")
        self.session_status_badge.setStyleSheet(f"""
            background: {theme.STATUS_NORMAL}; color: white;
            font-size: 12px; font-weight: 700; border-radius: 8px; padding: 4px 12px;
        """)
        self.course_value.setText(course)
        h, m = duration // 60, duration % 60
        self.dur_value.setText(f"{h}h {m}m" if h else f"{m} min")

        self.blocked_apps_lbl.setText(
            "Apps: " + (", ".join(blocked_apps) or "None"))
        self.blocked_domains_lbl.setText(
            "Domains: " + (", ".join(blocked_domains) or "None"))

        self._remaining_seconds = duration * 60
        self._submitted = False
        self._auto_submitted = False
        self._total_seconds = max(1, self._remaining_seconds)
        if self._timer is None:
            self._timer = QTimer(self)
            self._timer.timeout.connect(self._tick)
        self._timer.start(1000)

        # AI model is not part of the 40% milestone (ENABLE_AI_MONITORING=0)
        if ENABLE_AI_MONITORING:
            self._start_ai_worker()

        # Start blocking engine
        self._start_blocking_engine(blocked_apps, blocked_domains, security_options)

    # ==================================================================
    def _start_ai_worker(self):
        if self.ai_worker is not None:
            return
        self.ai_panel.set_pipeline_state("starting")
        from ai.ai_worker import AIWorker               # lazy: needs mediapipe/ultralytics
        self.ai_worker = AIWorker(camera_index=0, rate_hz=15.0)
        self.ai_worker.started_ok.connect(self._on_ai_started)
        self.ai_worker.stopped_ok.connect(self._on_ai_stopped)
        self.ai_worker.error_occurred.connect(self._on_ai_error)
        self.ai_worker.status_update.connect(self._on_ai_status)
        self.ai_worker.violation_detected.connect(self._on_ai_violation)
        self.ai_worker.start()

    def _on_ai_started(self):
        self.ai_panel.set_pipeline_state("running")

    def _on_ai_stopped(self):
        self.ai_panel.set_pipeline_state("idle")

    def _on_ai_error(self, msg):
        self.ai_panel.set_pipeline_state("error")
        logger.warning("AI error: %s", msg)

    def _on_ai_status(self, payload):
        self.ai_panel.update_status(payload)

    def _on_ai_violation(self, event):
        try:
            vtype = getattr(event, "violation_type", "behavioral")
            desc = getattr(event, "description", "AI detection")
            severity = getattr(event, "severity", "medium")
        except Exception:
            vtype, desc, severity = "behavioral", "AI detection", "medium"
        logger.info("AI violation: %s — %s", vtype, desc)
        if self.client_worker:
            self.client_worker.send_violation(vtype, desc, severity)

    # ==================================================================
    def _start_blocking_engine(self, blocked_apps, blocked_domains, security_options):
        if self.blocking_engine is not None:
            return
        self.blocking_state_lbl.setText("● starting…")
        self.blocking_state_lbl.setStyleSheet(
            f"color: {theme.STATUS_WARNING}; font-size: 12px; font-weight: 700;")

        self.blocking_engine = BlockingEngine(
            blocked_apps=blocked_apps,
            blocked_domains=blocked_domains,
            security_options=security_options,
        )
        self.blocking_engine.blocking_started.connect(self._on_blocking_started)
        self.blocking_engine.blocking_stopped.connect(self._on_blocking_stopped)
        self.blocking_engine.violation_detected.connect(self._on_blocking_violation)
        self.blocking_engine.blocked_process_killed.connect(self._on_blocking_kill)
        self.blocking_engine.status_update.connect(self._on_blocking_status)
        self.blocking_engine.error_occurred.connect(self._on_blocking_error)
        self._last_blocking_info = ""
        self.blocking_engine.start()

    def _on_blocking_started(self, payload):
        self.blocking_state_lbl.setText("● active")
        self.blocking_state_lbl.setStyleSheet(
            f"color: {theme.STATUS_NORMAL}; font-size: 12px; font-weight: 700;")
        n_apps = len(payload.get("blocked_apps", []))
        n_domains = len(payload.get("blocked_domains", []))
        hosts_applied = payload.get("hosts_applied", False)
        admin = payload.get("admin", False)
        parts = []
        parts.append(f"{n_apps} app(s) blocked")
        parts.append(f"{n_domains} site(s) blocked")
        if not admin:
            parts.append("(not running as admin — some blocks may not apply)")
        self.blocking_info_lbl.setText(" · ".join(parts))
        self.hosts_lbl.setText(f"Hosts: {'applied' if hosts_applied else 'not applied'}")
        self._last_blocking_info = self.blocking_info_lbl.text()
        if hosts_applied and n_domains and self.client_worker:
            self.client_worker.send_block_event(
                "domain_blocked", target=f"{n_domains} websites",
                detail="hosts file updated (IPv4 + IPv6)")

    def _on_blocking_stopped(self):
        self.blocking_state_lbl.setText("● inactive")
        self.blocking_state_lbl.setStyleSheet(
            f"color: {theme.STATUS_DISCONNECTED}; font-size: 12px; font-weight: 700;")

    def _on_blocking_violation(self, payload):
        vtype = payload.get("vtype", "service")
        desc = payload.get("description", "Blocked")
        severity = payload.get("severity", "medium")
        logger.info("Blocking violation: %s", desc)
        if self.client_worker:
            self.client_worker.send_violation(vtype, desc, severity)

    def _on_blocking_kill(self, payload):
        logger.info("Killed: %s (pid=%s, latency=%s ms)", payload.get("name"),
                    payload.get("pid"), payload.get("latency_ms"))
        if self.client_worker:
            self.client_worker.send_block_event(
                "allowlist_kill" if payload.get("allowlist") else "process_killed",
                target=payload.get("name", ""), pid=payload.get("pid"),
                latency_ms=payload.get("latency_ms"), detail=payload.get("app", ""))

    # ---- S4: teacher emergency override -------------------------------------------------
    def _on_block_paused(self, reason: str):
        if self.blocking_engine is not None:
            self.blocking_engine.pause()
        self.blocking_state_lbl.setText("● PAUSED by teacher")
        self.blocking_state_lbl.setStyleSheet(
            f"color: {theme.STATUS_WARNING}; font-size: 12px; font-weight: 700;")
        self.blocking_info_lbl.setText(
            "Your teacher paused blocking" + (f": {reason}" if reason else "."))
        self.hosts_lbl.setText("Hosts: released")

    def _on_block_resumed(self):
        if self.blocking_engine is not None:
            self.blocking_engine.resume()
        self.blocking_state_lbl.setText("● active")
        self.blocking_state_lbl.setStyleSheet(
            f"color: {theme.STATUS_NORMAL}; font-size: 12px; font-weight: 700;")
        self.blocking_info_lbl.setText(getattr(self, "_last_blocking_info", "") or "Blocking resumed.")
        self.hosts_lbl.setText("Hosts: applied")

    def _on_blocking_status(self, payload):
        killed = payload.get("killed_total", 0)
        self.killed_lbl.setText(f"Blocked processes: {killed}")

    def _on_blocking_error(self, msg):
        logger.warning("Blocking error: %s", msg)

    # ==================================================================
    def _tick(self):
        if self._remaining_seconds > 0:
            self._remaining_seconds -= 1
            self.timer_lbl.setText(format_hms(self._remaining_seconds))
            self.time_value.setText(format_hms(self._remaining_seconds))
            progress = int((1 - self._remaining_seconds / self._total_seconds) * 100)
            self.time_progress.setValue(progress)
            if self._remaining_seconds < 300:
                self.time_value.setStyleSheet(
                    f"color: {theme.STATUS_BEHAVIORAL}; font-size: 16px; font-weight: 700;")
        else:
            self.timer_lbl.setText("00:00:00")
            self.time_value.setText("TIME UP")
            if self._timer:
                self._timer.stop()
            self.browse_btn.setEnabled(False)
            self.submit_btn.setEnabled(False)
            self._on_time_up()

    def _on_session_ended(self):
        QMessageBox.information(self, "Session Ended",
                                "The teacher has ended this exam session.")
        self._shutdown_all()
        self.central_stack.setCurrentIndex(0)
        self.connect_page.status_lbl.setText("Session ended. You may disconnect.")

    def _on_client_disconnected(self, payload):
        self._connected = False
        # Link to the teacher is gone: do not leave the student's PC locked down.
        self._stop_blocking()

    def _on_client_error(self, msg):
        logger.warning("Client error: %s", msg)
        self.connect_page.on_connect_result(False, msg)

    def _browse_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Lab Exam File", "",
            "Documents (*.docx *.pdf *.zip *.rar);;All Files (*)")
        if not path:
            return
        size = os.path.getsize(path)
        if size > MAX_EXAM_PAPER_SIZE_BYTES:
            QMessageBox.warning(self, "File Too Large",
                f"Maximum allowed size is 20 MB. Your file is {size/(1024*1024):.2f} MB.")
            return
        self._selected_file_path = path
        self.selected_file_lbl.setText(f"Selected: {os.path.basename(path)} ({size/1024:.1f} KB)")
        self.submit_btn.setEnabled(True)

    def _on_time_up(self):
        """S12: time is over -> send the selected file automatically (once), then lock."""
        if getattr(self, "_submitted", False) or getattr(self, "_auto_submitted", False):
            return
        self._auto_submitted = True
        path = getattr(self, "_selected_file_path", None)
        if path and os.path.exists(path):
            self.submit_status_badge.setText("TIME UP - AUTO-SUBMITTING")
            self._submit_file(auto=True)
        else:
            self.submit_status_badge.setText("TIME UP - NOTHING SUBMITTED")

    def _submit_file(self, auto: bool = False):
        if not hasattr(self, "_selected_file_path") or not self._selected_file_path:
            if not auto:
                QMessageBox.warning(self, "No File", "Please select a file to submit.")
            return
        roll = self.user.get("roll_no", "UNKNOWN")
        ts = datetime.now().strftime("%H%M%S")
        safe_name = f"{roll}_{ts}_{os.path.basename(self._selected_file_path)}"
        dest = os.path.join(SUBMISSIONS_DIR, safe_name)
        try:
            shutil.copy2(self._selected_file_path, dest)
        except OSError as e:
            if not auto:
                QMessageBox.critical(self, "Error", f"Could not save file:\n{e}")
            self.submit_status_badge.setText("SAVE FAILED")
            return
        self._last_saved_name = safe_name
        self._refresh_local_submissions()

        if self.client_worker and self._connected:
            self.submit_btn.setEnabled(False)
            self.browse_btn.setEnabled(False)
            self.submit_status_badge.setText("UPLOADING 0%")
            self.client_worker.upload_submission(dest)
        else:
            self.submit_status_badge.setText("SAVED LOCALLY")
            if auto:
                return
            QMessageBox.warning(self, "Not Connected",
                "Your file was saved on this PC, but you are not connected to the "
                "teacher, so it has NOT been sent.\nReconnect and submit again.")

    def _on_submit_progress(self, percent: int):
        self.submit_status_badge.setText(f"UPLOADING {percent}%")

    def _on_submit_finished(self, ok: bool, message: str):
        self.browse_btn.setEnabled(self._remaining_seconds > 0)
        if ok:
            self._submitted = True
            self.submit_status_badge.setText("SUBMITTED")
            self.submit_status_badge.setStyleSheet(f"""
                background: {theme.STATUS_NORMAL}; color: white;
                font-size: 12px; font-weight: 700; border-radius: 8px; padding: 4px 12px;
            """)
            self.selected_file_lbl.setText(f"Submitted: {getattr(self, '_last_saved_name', '')}")
            self.submit_btn.setEnabled(False)
            if not getattr(self, "_auto_submitted", False):
                QMessageBox.information(self, "Submitted", message)
        else:
            self.submit_status_badge.setText("UPLOAD FAILED")
            self.submit_btn.setEnabled(self._remaining_seconds > 0)   # allow retry
            if getattr(self, "_auto_submitted", False):
                return          # time is up: the local copy is saved; badge already says FAILED
            QMessageBox.warning(self, "Upload Failed",
                f"{message}\n\nYour file is saved on this PC. You can press Submit again.")


def main(user: dict = None):
    app = QApplication(sys.argv)
    app.setStyleSheet(theme.build_stylesheet())
    win = StudentDashboard(user=user)
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()