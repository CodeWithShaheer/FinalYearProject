"""
gui.common package
Shared GUI code (theme, widgets, auth window).
"""