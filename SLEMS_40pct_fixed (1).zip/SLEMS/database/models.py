"""
database/models.py
Python dataclasses representing SLEMS entities.

These mirror the PostgreSQL tables but give us typed Python objects
for cleaner GUI + business logic code.
"""
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Optional, List, Dict, Any
import json


# ---------------------------------------------------------------------------
# User
# ---------------------------------------------------------------------------
@dataclass
class User:
    id: Optional[int] = None
    full_name: str = ""
    email: str = ""
    password_hash: str = ""
    role: str = "teacher"           # teacher / admin / student
    campus: str = "Faisalabad"
    created_at: Optional[datetime] = None

    @classmethod
    def from_row(cls, row: Dict[str, Any]) -> "User":
        return cls(
            id=row.get("id"),
            full_name=row.get("full_name", ""),
            email=row.get("email", ""),
            password_hash=row.get("password_hash", ""),
            role=row.get("role", "teacher"),
            campus=row.get("campus", "Faisalabad"),
            created_at=row.get("created_at"),
        )

    def to_public_dict(self) -> dict:
        """Dict safe to pass to GUI (no password)."""
        return {
            "id": self.id,
            "full_name": self.full_name,
            "email": self.email,
            "role": self.role,
            "campus": self.campus,
        }


# ---------------------------------------------------------------------------
# Course
# ---------------------------------------------------------------------------
@dataclass
class Course:
    id: Optional[int] = None
    name: str = ""
    created_at: Optional[datetime] = None

    @classmethod
    def from_row(cls, row: Dict[str, Any]) -> "Course":
        return cls(
            id=row.get("id"),
            name=row.get("name", ""),
            created_at=row.get("created_at"),
        )


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------
@dataclass
class Session:
    id: Optional[int] = None
    course_name: str = ""
    exam_title: str = ""
    duration: int = 0                 # minutes
    exam_paper: str = ""
    exam_paper_size: int = 0          # bytes
    blocked_apps: List[str] = field(default_factory=list)
    blocked_domains: List[str] = field(default_factory=list)
    security_options: Dict[str, bool] = field(default_factory=dict)
    status: str = "active"            # active / ended
    created_at: Optional[datetime] = None
    ended_at: Optional[datetime] = None
    join_code: str = ""               # random 6-digit code students type to join

    # Live field — populated by students_repo.count_by_session() when needed
    student_count: int = 0

    @classmethod
    def from_row(cls, row: Dict[str, Any]) -> "Session":
        # blocked_apps / blocked_domains stored as comma-separated TEXT
        apps_raw = row.get("blocked_apps") or ""
        domains_raw = row.get("blocked_domains") or ""
        apps = [a.strip() for a in apps_raw.split(",") if a.strip()]
        domains = [d.strip() for d in domains_raw.split(",") if d.strip()]

        # security_options stored as JSON string
        sec_raw = row.get("security_options") or "{}"
        try:
            sec = json.loads(sec_raw) if sec_raw else {}
        except (json.JSONDecodeError, TypeError):
            sec = {}

        return cls(
            id=row.get("id"),
            course_name=row.get("course_name", ""),
            exam_title=row.get("exam_title") or "",
            duration=row.get("duration", 0),
            exam_paper=row.get("exam_paper") or "",
            exam_paper_size=row.get("exam_paper_size") or 0,
            blocked_apps=apps,
            blocked_domains=domains,
            security_options=sec,
            status=row.get("status", "active"),
            created_at=row.get("created_at"),
            ended_at=row.get("ended_at"),
            join_code=row.get("join_code") or "",
        )


# ---------------------------------------------------------------------------
# Student
# ---------------------------------------------------------------------------
@dataclass
class Student:
    id: Optional[int] = None
    session_id: Optional[int] = None
    student_id: str = ""              # e.g. FSD-FL-201
    full_name: str = ""
    roll_no: str = ""
    status: str = "active"
    created_at: Optional[datetime] = None

    @classmethod
    def from_row(cls, row: Dict[str, Any]) -> "Student":
        return cls(
            id=row.get("id"),
            session_id=row.get("session_id"),
            student_id=row.get("student_id", ""),
            full_name=row.get("full_name", ""),
            roll_no=row.get("roll_no", ""),
            status=row.get("status", "active"),
            created_at=row.get("created_at"),
        )


# ---------------------------------------------------------------------------
# Submission
# ---------------------------------------------------------------------------
@dataclass
class Submission:
    id: Optional[int] = None
    session_id: Optional[int] = None
    student_id: Optional[int] = None
    file_path: str = ""
    file_name: str = ""
    file_size: int = 0
    submitted_at: Optional[datetime] = None

    # Joined fields (populated by repo queries)
    student_name: str = ""
    roll_no: str = ""

    @classmethod
    def from_row(cls, row: Dict[str, Any]) -> "Submission":
        return cls(
            id=row.get("id"),
            session_id=row.get("session_id"),
            student_id=row.get("student_id"),
            file_path=row.get("file_path") or "",
            file_name=row.get("file_name") or "",
            file_size=row.get("file_size") or 0,
            submitted_at=row.get("submitted_at"),
            student_name=row.get("student_name", "") or row.get("full_name", ""),
            roll_no=row.get("roll_no", ""),
        )


# ---------------------------------------------------------------------------
# Violation
# ---------------------------------------------------------------------------
@dataclass
class Violation:
    id: Optional[int] = None
    session_id: Optional[int] = None
    student_id: Optional[int] = None
    violation_type: str = "behavioral"   # behavioral / service
    description: str = ""
    severity: str = "medium"             # low / medium / high
    timestamp: Optional[datetime] = None
    synced: bool = True
    confidence: Optional[float] = None
    reviewed: bool = False
    dismissed: bool = False

    # Joined fields
    student_name: str = ""
    roll_no: str = ""

    @classmethod
    def from_row(cls, row: Dict[str, Any]) -> "Violation":
        return cls(
            id=row.get("id"),
            session_id=row.get("session_id"),
            student_id=row.get("student_id"),
            violation_type=row.get("violation_type", "behavioral"),
            description=row.get("description") or "",
            severity=row.get("severity") or "medium",
            timestamp=row.get("timestamp"),
            synced=row.get("synced", True),
            confidence=row.get("confidence"),
            reviewed=bool(row.get("reviewed", False)),
            dismissed=bool(row.get("dismissed", False)),
            student_name=row.get("student_name", "") or row.get("full_name", ""),
            roll_no=row.get("roll_no", ""),
        )


# ---------------------------------------------------------------------------
# Connection  (network layer — Phase 3)
# ---------------------------------------------------------------------------
@dataclass
class Connection:
    id: Optional[int] = None
    student_id: Optional[int] = None
    session_id: Optional[int] = None
    ip_address: str = ""
    session_token: str = ""
    status: str = "connected"           # connected / reconnecting / offline
    connected_at: Optional[datetime] = None
    last_heartbeat: Optional[datetime] = None

    @classmethod
    def from_row(cls, row: Dict[str, Any]) -> "Connection":
        return cls(
            id=row.get("id"),
            student_id=row.get("student_id"),
            session_id=row.get("session_id"),
            ip_address=row.get("ip_address") or "",
            session_token=row.get("session_token") or "",
            status=row.get("status") or "connected",
            connected_at=row.get("connected_at"),
            last_heartbeat=row.get("last_heartbeat"),
        )


# ---------------------------------------------------------------------------
# Helper: convert list of model instances to list of dicts
# ---------------------------------------------------------------------------
def to_dict_list(items) -> List[dict]:
    """Convert [Model, Model, ...] to [dict, dict, ...]."""
    return [asdict(i) for i in items]