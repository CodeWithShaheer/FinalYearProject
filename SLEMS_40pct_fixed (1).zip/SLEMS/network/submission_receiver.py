"""
network/submission_receiver.py
Teacher-side receiver for student exam-file uploads (chunked, ordered, SHA-256 verified).

Flow:  META -> (ACK_META + upload_id) -> CHUNK x N -> COMPLETE -> (ACK_COMPLETE + submission_id)
The file is written to <name>.part and only renamed into SUBMISSIONS_DIR once the
size and hash check out, so a dropped connection never leaves a half file that looks real.
"""
import base64
import binascii
import hashlib
import logging
import os
import re
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional, Tuple

from config.settings import SUBMISSIONS_DIR, MAX_EXAM_PAPER_SIZE_BYTES
from database import submissions_repo

logger = logging.getLogger(__name__)

BLOCKED_EXTENSIONS = {".exe", ".bat", ".cmd", ".msi", ".scr", ".com", ".vbs", ".ps1", ".dll", ".lnk"}
MAX_CHUNKS = 400                      # 400 x 256 KB  > 20 MB limit
_SAFE_NAME = re.compile(r"[^A-Za-z0-9._ \-()]")


def safe_file_name(name: str) -> str:
    """Strip any path and unsafe characters (blocks '../../x', 'C:\\x', control chars)."""
    name = (name or "").replace("\\", "/").split("/")[-1].strip()
    name = _SAFE_NAME.sub("_", name).lstrip(".")
    return name[:120] or "submission"


@dataclass
class _Upload:
    upload_id: str
    token: str
    session_id: int
    student_db_id: int
    roll_no: str
    file_name: str
    file_size: int
    total_chunks: int
    sha256: str
    part_path: Path
    final_path: Path
    next_index: int = 0
    received: int = 0
    started: float = field(default_factory=time.time)
    hasher: "hashlib._Hash" = field(default_factory=hashlib.sha256)


class SubmissionReceiver:
    def __init__(self, dest_dir: Optional[Path] = None):
        self.dest_dir = Path(dest_dir) if dest_dir else Path(SUBMISSIONS_DIR)
        self.dest_dir.mkdir(parents=True, exist_ok=True)
        self._uploads: Dict[str, _Upload] = {}          # upload_id -> upload

    # ------------------------------------------------------------------
    def start(self, *, token: str, session_id: int, student_db_id: int, roll_no: str,
              file_name: str, file_size, total_chunks, sha256: str = "") -> Tuple[bool, str, str]:
        """Returns (accepted, upload_id, reason)."""
        try:
            file_size = int(file_size)
            total_chunks = int(total_chunks or 0)
        except (TypeError, ValueError):
            return False, "", "Invalid file size."
        name = safe_file_name(file_name)
        if Path(name).suffix.lower() in BLOCKED_EXTENSIONS:
            return False, "", f"File type '{Path(name).suffix}' is not allowed."
        if file_size <= 0:
            return False, "", "Empty file."
        if file_size > MAX_EXAM_PAPER_SIZE_BYTES:
            return False, "", "File is larger than the 20 MB limit."
        if total_chunks <= 0 or total_chunks > MAX_CHUNKS:
            return False, "", "Invalid chunk count."

        self.abort_for_token(token)                      # one upload at a time per student
        ts = time.strftime("%Y%m%d_%H%M%S")
        base = f"{safe_file_name(roll_no)}_s{session_id}_{ts}_{name}"
        upload_id = uuid.uuid4().hex[:16]
        up = _Upload(upload_id, token, session_id, student_db_id, roll_no, name,
                     file_size, total_chunks, (sha256 or "").lower(),
                     self.dest_dir / (base + ".part"), self.dest_dir / base)
        try:
            up.part_path.write_bytes(b"")
        except OSError as e:
            return False, "", f"Cannot write on teacher PC: {e}"
        self._uploads[upload_id] = up
        return True, upload_id, ""

    # ------------------------------------------------------------------
    def add_chunk(self, token: str, upload_id: str, chunk_index, data_b64: str) -> Tuple[bool, str]:
        up = self._uploads.get(upload_id)
        if up is None or up.token != token:
            return False, "Unknown upload."
        try:
            idx = int(chunk_index)
            raw = base64.b64decode(data_b64, validate=True)
        except (ValueError, TypeError, binascii.Error):
            self._discard(up)
            return False, "Corrupt chunk."
        if idx != up.next_index:
            self._discard(up)
            return False, f"Chunk out of order (expected {up.next_index}, got {idx})."
        if up.received + len(raw) > up.file_size:
            self._discard(up)
            return False, "More data than announced."
        try:
            with open(up.part_path, "ab") as f:
                f.write(raw)
        except OSError as e:
            self._discard(up)
            return False, f"Disk write failed: {e}"
        up.hasher.update(raw)
        up.received += len(raw)
        up.next_index += 1
        return True, ""

    # ------------------------------------------------------------------
    def complete(self, token: str, upload_id: str, sha256: str = "") -> Tuple[bool, Optional[int], str, str]:
        """Returns (ok, submission_id, saved_path, reason)."""
        up = self._uploads.get(upload_id)
        if up is None or up.token != token:
            return False, None, "", "Unknown upload."
        if up.received != up.file_size or up.next_index != up.total_chunks:
            self._discard(up)
            return False, None, "", "Upload incomplete."
        digest = up.hasher.hexdigest()
        expected = (sha256 or up.sha256 or "").lower()
        if expected and digest != expected:
            self._discard(up)
            return False, None, "", "File was corrupted in transfer (hash mismatch)."
        try:
            os.replace(up.part_path, up.final_path)
        except OSError as e:
            self._discard(up)
            return False, None, "", f"Could not save file: {e}"
        ok, sub, msg = submissions_repo.upsert_submission(
            up.session_id, up.student_db_id, str(up.final_path), up.file_name)
        self._uploads.pop(upload_id, None)
        if not ok or sub is None:
            return False, None, str(up.final_path), msg
        logger.info("Submission saved: %s (%d bytes) from %s", up.final_path.name,
                    up.file_size, up.roll_no)
        return True, sub.id, str(up.final_path), ""

    # ------------------------------------------------------------------
    def abort_for_token(self, token: str):
        for up in [u for u in self._uploads.values() if u.token == token]:
            self._discard(up)

    def _discard(self, up: _Upload):
        self._uploads.pop(up.upload_id, None)
        try:
            up.part_path.unlink(missing_ok=True)
        except OSError:
            pass
