import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))  # run from anywhere
"""
test_ai_worker.py
Simple GUI test: shows live AI status + fires violations.

Instructions:
  1. Look at camera normally for 5 sec (no violations)
  2. Look away left for 4 sec → LOOKING_AWAY violation
  3. Turn head right for 4 sec → HEAD_TURNED violation
  4. Hold real phone near face for 3 sec → PHONE_DETECTED violation
  5. Cover face / move away from camera for 4 sec → NO_FACE violation
"""
import sys
import logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QPushButton, QTextEdit,
)

from ai.ai_worker import AIWorker


class TestWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("AI Worker Test — SLEMS")
        self.resize(800, 600)

        root = QVBoxLayout(self)
        root.setContentsMargins(20, 20, 20, 20)
        root.setSpacing(12)

        # Status card
        status_card = QFrame()
        status_card.setStyleSheet("QFrame { background: #FFFFFF; border: 1px solid #E0E4EC; border-radius: 12px; }")
        sl = QVBoxLayout(status_card)
        sl.setContentsMargins(18, 16, 18, 16)
        sl.setSpacing(8)

        title = QLabel("Live AI Status")
        title.setStyleSheet("font-size: 18px; font-weight: 800; color: #0A1F44;")
        sl.addWidget(title)

        self.status_lbl = QLabel("Waiting for AI worker…")
        self.status_lbl.setStyleSheet("font-size: 14px; color: #101828; font-family: Consolas;")
        self.status_lbl.setWordWrap(True)
        sl.addWidget(self.status_lbl)

        root.addWidget(status_card)

        # Violation feed
        vf_card = QFrame()
        vf_card.setStyleSheet("QFrame { background: #FFFFFF; border: 1px solid #E0E4EC; border-radius: 12px; }")
        vl = QVBoxLayout(vf_card)
        vl.setContentsMargins(18, 16, 18, 16)
        vl.setSpacing(8)

        vf_title = QLabel("Violations (live)")
        vf_title.setStyleSheet("font-size: 18px; font-weight: 800; color: #0A1F44;")
        vl.addWidget(vf_title)

        self.feed = QTextEdit()
        self.feed.setReadOnly(True)
        self.feed.setStyleSheet("font-family: Consolas; font-size: 13px;")
        vl.addWidget(self.feed)

        root.addWidget(vf_card, stretch=1)

        # Buttons
        btns = QHBoxLayout()
        self.start_btn = QPushButton("Start AI")
        self.start_btn.setStyleSheet(
            "QPushButton { background: #0F2C5C; color: white; padding: 10px 20px; "
            "border: none; border-radius: 8px; font-weight: 700; font-size: 14px; }"
            "QPushButton:hover { background: #1E4488; }"
        )
        self.start_btn.clicked.connect(self._start_ai)
        btns.addWidget(self.start_btn)

        self.stop_btn = QPushButton("Stop AI")
        self.stop_btn.setEnabled(False)
        self.stop_btn.setStyleSheet(
            "QPushButton { background: #E23D3D; color: white; padding: 10px 20px; "
            "border: none; border-radius: 8px; font-weight: 700; font-size: 14px; }"
            "QPushButton:disabled { background: #B7BEC9; }"
        )
        self.stop_btn.clicked.connect(self._stop_ai)
        btns.addWidget(self.stop_btn)

        btns.addStretch()
        root.addLayout(btns)

        self.worker = None

    def _start_ai(self):
        self.worker = AIWorker(rate_hz=6.0, enable_yolo=True, yolo_frame_interval=5)
        self.worker.status_update.connect(self._on_status)
        self.worker.violation_detected.connect(self._on_violation)
        self.worker.error_occurred.connect(self._on_error)
        self.worker.started_ok.connect(lambda: self.feed.append("[AI] Worker started."))
        self.worker.stopped_ok.connect(lambda: self.feed.append("[AI] Worker stopped."))
        self.worker.start()

        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)

    def _stop_ai(self):
        if self.worker:
            self.worker.stop()
            self.worker.wait(3000)
            self.worker = None
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)

    def _on_status(self, s: dict):
        active = s.get("active_signals", {})
        active_str = ", ".join(f"{k}={v}s" for k, v in active.items()) if active else "—"
        self.status_lbl.setText(
            f"faces={s['face_count']}  gaze={s['gaze']}  head={s['head']}  hands={s['hand_count']}\n"
            f"phone_heur={s['phone_suspected']}  yolo_phone={s['yolo_phone']} (conf={s['yolo_phone_conf']:.2f})\n"
            f"inference={s['inference_ms']}ms  active_signals: {active_str}"
        )

    def _on_violation(self, ev):
        line = (
            f"[VIOLATION] {ev.rule_key}  "
            f"({ev.severity})  duration={ev.duration_sec}s\n"
            f"    → {ev.description}"
        )
        self.feed.append(line)

    def _on_error(self, msg):
        self.feed.append(f"[ERROR] {msg}")

    def closeEvent(self, event):
        self._stop_ai()
        super().closeEvent(event)


def main():
    app = QApplication(sys.argv)
    win = TestWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()