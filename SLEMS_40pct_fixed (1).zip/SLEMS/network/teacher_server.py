"""
network/teacher_server.py
Asyncio TCP server run by the teacher PC.

v2.0: WEBRTC_OFFER / WEBRTC_ICE events now include the sender token
so the NetworkBridge can route them to the correct TeacherPeer.
"""
import asyncio
import logging
import time
from typing import Callable, Dict, List, Optional, Set

from network import protocol as P
from network.connection_manager import ConnectionManager, StudentConnection
from network.submission_receiver import SubmissionReceiver
from security import session_security as SS
from security import message_validation as MV
from database import (
    sessions_repo, students_repo, connections_repo,
    block_events_repo, audit_repo,
)
from config.network_config import (
    TEACHER_HOST, TEACHER_TCP_PORT,
    HEARTBEAT_TIMEOUT_RECONNECT, HEARTBEAT_TIMEOUT_OFFLINE,
)

logger = logging.getLogger(__name__)


# Event types
EVT_STUDENT_CONNECTED    = "student_connected"
EVT_STUDENT_DISCONNECTED = "student_disconnected"
EVT_STUDENT_HEARTBEAT    = "student_heartbeat"
EVT_VIOLATION            = "violation"
EVT_SUBMISSION_META      = "submission_meta"
EVT_SUBMISSION_CHUNK     = "submission_chunk"
EVT_SUBMISSION_COMPLETE  = "submission_complete"
EVT_BLOCK_EVENT          = "block_event"
EVT_BLOCKING_PAUSED      = "blocking_paused"
EVT_WEBRTC_OFFER         = "webrtc_offer"
EVT_WEBRTC_ICE           = "webrtc_ice"
EVT_ERROR                = "error"


class TeacherServer:
    def __init__(self):
        self.manager = ConnectionManager()
        self._server: Optional[asyncio.AbstractServer] = None
        self._running = False
        self._event_cb: Optional[Callable] = None
        self._heartbeat_task: Optional[asyncio.Task] = None
        self.receiver = SubmissionReceiver()
        self._ended_sessions: Set[int] = set()          # sessions the teacher ended on purpose
        self._failed_joins: Dict[str, List[float]] = {}  # ip -> timestamps of wrong codes

    # ==================================================================
    async def start(self):
        if self._running:
            return
        self._server = await asyncio.start_server(
            self._handle_client,
            host=TEACHER_HOST,
            port=TEACHER_TCP_PORT,
            limit=P.MAX_MESSAGE_SIZE,      # default 64 KB is too small for upload chunks
        )
        self._running = True
        addrs = ", ".join(str(s.getsockname()) for s in self._server.sockets)
        logger.info("TeacherServer listening on %s", addrs)
        self._heartbeat_task = asyncio.create_task(self._heartbeat_monitor())

    async def stop(self):
        if not self._running:
            return
        self._running = False
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                pass
        if self._server:
            self._server.close()
            try:
                await self._server.wait_closed()
            except Exception:
                pass
        await self.manager.close_all()
        logger.info("TeacherServer stopped.")

    def on_event(self, cb: Callable):
        self._event_cb = cb

    def _emit(self, event_type: str, payload: dict):
        if self._event_cb:
            try:
                self._event_cb(event_type, payload)
            except Exception:
                logger.exception("Event callback failed for %s", event_type)

    # ==================================================================
    async def _handle_client(self, reader, writer):
        peer = writer.get_extra_info("peername")
        ip = peer[0] if peer else "unknown"
        logger.info("New connection from %s", ip)

        try:
            await self._do_handshake(reader, writer, ip)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            logger.exception("Handshake failed for %s: %s", ip, e)
        finally:
            try:
                writer.close()
                try:
                    await writer.wait_closed()
                except Exception:
                    pass
            except Exception:
                pass

    async def _do_handshake(self, reader, writer, ip):
        msg = await self._read_message(reader)
        if msg is None:
            return
        if msg.get("type") != P.MSG_HELLO:
            await self._send_error(writer, "Expected HELLO first")
            return
        if not MV.is_valid_hello(msg):
            await self._send_error(writer, "Invalid HELLO payload")
            return

        roll_no = str(msg["roll_no"]).strip().upper()

        # --- brute-force protection: 10 wrong codes in 5 minutes -> locked out for that window
        now = time.time()
        recent = [t for t in self._failed_joins.get(ip, []) if now - t < 300]
        self._failed_joins[ip] = recent
        if len(recent) >= 10:
            await self._send_error(writer, "Too many wrong session codes. Wait a few minutes.")
            self._emit(EVT_ERROR, {"ip": ip, "reason": "join_throttled"})
            return

        session = sessions_repo.get_session_by_join_code(str(msg["session_code"]))
        if session is None:
            self._failed_joins[ip].append(now)
            await self._send_error(writer, "Wrong or expired session code")
            self._emit(EVT_ERROR, {"ip": ip, "reason": "session_inactive"})
            return

        student = students_repo.get_student_by_roll_in_session(session.id, roll_no)
        if student is None:
            if session.security_options.get("require_roster"):
                await self._send_error(
                    writer, f"Roll number {roll_no} is not registered for this exam")
                self._emit(EVT_ERROR, {"ip": ip, "reason": "not_in_roster", "roll_no": roll_no})
                return
            ok, student, err = students_repo.add_student(
                session_id=session.id,
                student_id=f"AUTO-{roll_no}",
                full_name=f"Student {roll_no}",
                roll_no=roll_no,
                status="active",
            )
            if not ok:
                await self._send_error(writer, "Student not registered in session")
                return
        else:
            students_repo.mark_joined(student.id)

        if self.manager.has_roll(roll_no):
            await self._send_error(writer, "This roll number is already connected")
            return

        token = SS.issue_token(
            session_id=session.id,
            student_id=student.student_id,
            student_db_id=student.id,
            ip=ip,
            roll_no=roll_no,
        )

        welcome = P.welcome(
            token=token,
            session_id=session.id,
            duration=session.duration,
            student_db_id=student.id,
            course_name=session.course_name,
            exam_title=session.exam_title or "",
        )
        writer.write(welcome)
        await writer.drain()
        logger.info("WELCOME sent to %s (session=%s)", roll_no, session.id)

        msg = await self._read_message(reader, timeout=15)
        if msg is None or msg.get("type") != P.MSG_JOIN:
            await self._send_error(writer, "Expected JOIN")
            SS.unregister_token(token)
            return
        if msg.get("token") != token:
            await self._send_error(writer, "Token mismatch in JOIN")
            SS.unregister_token(token)
            return

        conn = StudentConnection(
            token=token,
            reader=reader,
            writer=writer,
            session_id=session.id,
            student_db_id=student.id,
            student_id=student.student_id,
            roll_no=roll_no,
            full_name=student.full_name,
            ip_address=ip,
        )
        await self.manager.add(conn)

        connections_repo.register_connection(
            student_id=student.id,
            session_id=session.id,
            ip_address=ip,
            session_token=token,
        )

        cfg = P.session_config(
            blocked_apps=session.blocked_apps,
            blocked_domains=session.blocked_domains,
            security_options=session.security_options,
        )
        await conn.send(cfg)

        self._emit(EVT_STUDENT_CONNECTED, {
            "token": token,
            "roll_no": roll_no,
            "full_name": student.full_name,
            "student_db_id": student.id,
            "session_id": session.id,
            "ip": ip,
        })

        await self._student_loop(conn)

    # ==================================================================
    async def _student_loop(self, conn: StudentConnection):
        token = conn.token
        try:
            while True:
                msg = await self._read_message(conn.reader)
                if msg is None:
                    logger.info("Student %s closed connection", conn.roll_no)
                    break

                meta, err = MV.validate_message(msg)
                if err:
                    await conn.send(P.error_message(err, code="VALIDATION"))
                    continue

                mtype = msg["type"]

                if mtype == P.MSG_HEARTBEAT:
                    conn.touch()
                    connections_repo.update_heartbeat(token)
                    self._emit(EVT_STUDENT_HEARTBEAT, {"token": token, "roll_no": conn.roll_no})

                elif mtype == P.MSG_BLOCK_EVENT:
                    await self._handle_block_event(conn, msg)

                elif mtype == P.MSG_VIOLATION:
                    await self._handle_violation(conn, msg)

                elif mtype == P.MSG_SUBMISSION_META:
                    ok, upload_id, reason = self.receiver.start(
                        token=token, session_id=conn.session_id,
                        student_db_id=conn.student_db_id, roll_no=conn.roll_no,
                        file_name=msg.get("file_name"), file_size=msg.get("file_size"),
                        total_chunks=msg.get("total_chunks"), sha256=msg.get("file_sha256", ""))
                    await conn.send(P.submission_ack_meta(upload_id, accepted=ok, reason=reason))
                    if ok:
                        self._emit(EVT_SUBMISSION_META, {
                            "token": token, "roll_no": conn.roll_no,
                            "file_name": msg.get("file_name"),
                            "file_size": msg.get("file_size"),
                        })

                elif mtype == P.MSG_SUBMISSION_CHUNK:
                    ok, reason = self.receiver.add_chunk(
                        token, msg.get("upload_id", ""), msg.get("chunk_index"), msg.get("data"))
                    if not ok:                       # only failures are acknowledged
                        await conn.send(P.encode(P.MSG_SUBMISSION_ACK_CHUNK,
                                                 upload_id=msg.get("upload_id", ""),
                                                 chunk_index=msg.get("chunk_index"),
                                                 ok=False, reason=reason))

                elif mtype == P.MSG_SUBMISSION_COMPLETE:
                    ok, sub_id, path, reason = self.receiver.complete(
                        token, msg.get("upload_id", ""), msg.get("file_sha256", ""))
                    if ok:
                        await conn.send(P.submission_ack_complete(msg.get("upload_id", ""), sub_id, path))
                        self._emit(EVT_SUBMISSION_COMPLETE, {
                            "token": token, "roll_no": conn.roll_no,
                            "full_name": conn.full_name, "session_id": conn.session_id,
                            "submission_id": sub_id, "path": path,
                        })
                    else:
                        await conn.send(P.encode(P.MSG_SUBMISSION_ACK_COMPLETE,
                                                 upload_id=msg.get("upload_id", ""),
                                                 submission_id=None, reason=reason))

                elif mtype == P.MSG_WEBRTC_OFFER:
                    self._emit(EVT_WEBRTC_OFFER, {
                        "token": token,
                        "roll_no": conn.roll_no,
                        "sdp": msg.get("sdp"),
                    })

                elif mtype == P.MSG_WEBRTC_ICE:
                    self._emit(EVT_WEBRTC_ICE, {
                        "token": token,
                        "roll_no": conn.roll_no,
                        "candidate": msg.get("candidate"),
                    })

                elif mtype == P.MSG_DISCONNECT:
                    logger.info("Student %s requested disconnect", conn.roll_no)
                    conn.left_gracefully = True
                    break

        except (ConnectionError, OSError) as e:
            logger.warning("Connection error for %s: %s", conn.roll_no, e)
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("Unexpected error in student loop for %s", conn.roll_no)
        finally:
            await self._cleanup_student(conn)

    async def _handle_violation(self, conn: StudentConnection, msg: dict):
        from database import violations_repo
        vtype = msg.get("vtype", "behavioral")
        desc = msg.get("desc", "")
        severity = msg.get("severity", "medium")

        ok, violation, db_err = violations_repo.add_violation(
            session_id=conn.session_id,
            student_id=conn.student_db_id,
            violation_type=vtype,
            description=desc,
            severity=severity,
        )
        if ok and violation:
            await conn.send(P.violation_ack(violation.id))
            self._emit(EVT_VIOLATION, {
                "token": conn.token,
                "roll_no": conn.roll_no,
                "full_name": conn.full_name,
                "vtype": vtype,
                "description": desc,
                "severity": severity,
                "violation_id": violation.id,
            })
        else:
            await conn.send(P.error_message(db_err or "Violation save failed", code="DB"))

    # ==================================================================
    # Send messages to a specific student (used by NetworkBridge for WebRTC)
    # ==================================================================
    async def send_to_token(self, token: str, frame: bytes) -> bool:
        conn = self.manager.get(token)
        if conn is None:
            return False
        return await conn.send(frame)

    # ==================================================================
    async def _cleanup_student(self, conn: StudentConnection):
        self.receiver.abort_for_token(conn.token)
        await self._alert_if_left_early(conn)
        SS.unregister_token(conn.token)
        connections_repo.mark_disconnected(conn.token)
        await self.manager.remove(conn.token)
        await conn.close()
        self._emit(EVT_STUDENT_DISCONNECTED, {
            "token": conn.token,
            "roll_no": conn.roll_no,
            "session_id": conn.session_id,
        })

    async def _alert_if_left_early(self, conn: StudentConnection):
        """S3: a student whose SLEMS closes / crashes / loses network mid-exam is a violation."""
        if not self._running or conn.session_id in self._ended_sessions:
            return
        try:
            session = sessions_repo.get_session_by_id(conn.session_id)
        except Exception:
            return
        if session is None or session.status != "active":
            return                                     # exam already over - normal disconnect
        if conn.left_gracefully:
            desc = "Student left the exam (logged out / closed SLEMS)"
        else:
            desc = "Student's SLEMS was closed or the connection was lost"
        block_events_repo.add_event(conn.session_id, conn.student_db_id, "client_offline",
                                    target=conn.roll_no, detail=desc)
        from database import violations_repo
        ok, violation, _ = violations_repo.add_violation(
            session_id=conn.session_id, student_id=conn.student_db_id,
            violation_type="service", description=desc, severity="high")
        if ok and violation:
            self._emit(EVT_VIOLATION, {
                "token": conn.token, "roll_no": conn.roll_no, "full_name": conn.full_name,
                "vtype": "service", "description": desc, "severity": "high",
                "violation_id": violation.id,
            })

    async def _handle_block_event(self, conn: StudentConnection, msg: dict):
        """S6: store every kill / block with its timestamp and launch->kill latency."""
        etype = msg.get("event_type", "")
        ok, _ = block_events_repo.add_event(
            conn.session_id, conn.student_db_id, etype,
            target=str(msg.get("target", "")), pid=msg.get("pid"),
            latency_ms=msg.get("latency_ms"), detail=str(msg.get("detail", "")))
        if ok:
            self._emit(EVT_BLOCK_EVENT, {
                "token": conn.token, "roll_no": conn.roll_no, "event_type": etype,
                "target": msg.get("target", ""), "latency_ms": msg.get("latency_ms"),
            })

    # ==================================================================
    # Teacher actions
    # ==================================================================
    async def announce_session_end(self, session_id: Optional[int] = None) -> int:
        """Tell students the exam is over (they release blocking and show the end screen)."""
        if session_id is not None:
            self._ended_sessions.add(session_id)       # their disconnects are NOT violations
        else:
            self._ended_sessions.update(c.session_id for c in self.manager.all_connections())
        return await self.manager.broadcast(P.session_end(), session_id)

    async def set_blocking_paused(self, token: str, paused: bool, reason: str = "",
                                  actor_user_id: Optional[int] = None) -> bool:
        """S4: emergency override.  Pauses / resumes blocking on ONE student and logs it."""
        conn = self.manager.get(token)
        if conn is None:
            return False
        frame = P.block_pause(reason) if paused else P.block_resume()
        if not await conn.send(frame):
            return False
        conn.blocking_paused = paused
        etype = "blocking_paused" if paused else "blocking_resumed"
        block_events_repo.add_event(conn.session_id, conn.student_db_id, etype,
                                    target=conn.roll_no, detail=reason)
        audit_repo.log(etype, session_id=conn.session_id, actor_user_id=actor_user_id,
                       student_id=conn.student_db_id,
                       detail=reason or ("override on" if paused else "override off"))
        self._emit(EVT_BLOCKING_PAUSED, {"token": token, "roll_no": conn.roll_no,
                                         "paused": paused, "reason": reason})
        return True

    async def _heartbeat_monitor(self):
        try:
            while self._running:
                await asyncio.sleep(5)
                for conn in await self.manager.find_stale(HEARTBEAT_TIMEOUT_RECONNECT):
                    if conn.status == "connected":
                        conn.status = "reconnecting"
                        connections_repo.update_status(conn.token, "reconnecting")
                        logger.info("Student %s → reconnecting", conn.roll_no)
                for conn in await self.manager.find_stale(HEARTBEAT_TIMEOUT_OFFLINE):
                    logger.info("Student %s idle too long — closing", conn.roll_no)
                    await conn.close()
        except asyncio.CancelledError:
            pass
        except Exception:
            logger.exception("Heartbeat monitor crashed")

    async def _read_message(self, reader, timeout=None):
        try:
            if timeout is not None:
                line = await asyncio.wait_for(
                    reader.readuntil(P.FRAME_TERMINATOR), timeout=timeout
                )
            else:
                line = await reader.readuntil(P.FRAME_TERMINATOR)
        except asyncio.IncompleteReadError:
            return None
        except asyncio.TimeoutError:
            return None
        except (ConnectionError, OSError) as e:
            logger.debug("read error: %s", e)
            return None
        except asyncio.LimitOverrunError:
            logger.warning("Message exceeded line limit")
            return None

        try:
            return P.decode_line(line)
        except P.ProtocolError as e:
            logger.warning("Bad message: %s", e)
            return None

    async def _send_error(self, writer, message, code=None):
        try:
            writer.write(P.error_message(message, code=code))
            await writer.drain()
        except Exception:
            pass


async def _run_standalone():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
    from utils.logger import setup_logging
    from database.migrations import init_db
    setup_logging()
    init_db()

    server = TeacherServer()

    def on_event(evt, payload):
        print(f"\n[EVENT] {evt}: {payload}\n")

    server.on_event(on_event)
    await server.start()

    print(f"\nTeacherServer running on port {TEACHER_TCP_PORT}")
    print("Press Ctrl+C to stop.\n")

    try:
        while True:
            await asyncio.sleep(3600)
    except KeyboardInterrupt:
        print("\nShutting down…")
    finally:
        await server.stop()


if __name__ == "__main__":
    try:
        asyncio.run(_run_standalone())
    except KeyboardInterrupt:
        pass