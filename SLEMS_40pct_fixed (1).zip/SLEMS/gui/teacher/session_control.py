"""
gui/teacher/session_control.py
Session Control page — redesigned v2.0.

Sections:
  ① EXAM DETAILS       — Course dropdown (+Add New), Exam Title, Duration, Exam Paper
  ② SECURITY & RESTRICTIONS — Blocked Apps, Blocked Domains, Security Options
  ③ SESSION READINESS  — 5 live chips + Review & Start Exam button
  ④ SESSION HISTORY    — Table with live student count + Monitor / View Report actions

Footer note: "Only one active session is allowed at a time..."

All data is read from PostgreSQL via database/*_repo modules.
"""
import json
import logging
import os

from PyQt5.QtCore import Qt, QTimer, pyqtSignal
from PyQt5.QtGui import QColor, QFont
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton,
    QComboBox, QLineEdit, QSpinBox, QTableWidget, QTableWidgetItem,
    QHeaderView, QMessageBox, QScrollArea, QGraphicsDropShadowEffect,
    QSizePolicy, QDialog, QTextEdit, QPlainTextEdit, QFileDialog,
)

from gui.common import theme
from gui.common.widgets import (
    SectionHeader, ReadinessChip, SecurityOptionRow,
    SearchableCheckList, TimerBox, FileUploadRow, AddCourseDialog,
)
from database import courses_repo, sessions_repo, students_repo, audit_repo
from blocking.presets import preset_names, expand_presets
from config.settings import (
    DEFAULT_BLOCKED_APPS, DEFAULT_BLOCKED_DOMAINS,
    AVAILABLE_BLOCKED_APPS, AVAILABLE_BLOCKED_DOMAINS,
    DEFAULT_SECURITY_OPTIONS, SECURITY_OPTION_LABELS,
    MAX_EXAM_PAPER_SIZE_BYTES, MAX_EXAM_PAPER_SIZE_MB,
    ALLOWED_EXAM_PAPER_EXTENSIONS,
)
from utils.helpers import format_duration_minutes, format_datetime


logger = logging.getLogger(__name__)


def _drop_shadow(blur=20, y_offset=4):
    eff = QGraphicsDropShadowEffect()
    eff.setBlurRadius(blur)
    eff.setOffset(0, y_offset)
    eff.setColor(QColor(16, 24, 40, 40))
    return eff


def _card_frame() -> QFrame:
    """Returns a styled card frame."""
    f = QFrame()
    f.setObjectName("card")
    f.setStyleSheet(f"""
        #card {{
            background: {theme.CARD_BG};
            border: 1px solid {theme.BORDER};
            border-radius: 14px;
        }}
    """)
    f.setGraphicsEffect(_drop_shadow())
    return f


class SessionControlPage(QWidget):
    """
    Full Session Control page.
    Emits `monitor_requested(session_id)` when Monitor button clicked,
    and `report_requested(session_id)` when View Report clicked.
    TeacherDashboard connects these to switch pages.
    """

    monitor_requested = pyqtSignal(int)
    report_requested = pyqtSignal(int)
    session_started = pyqtSignal(int)   # emits new session id
    session_ended = pyqtSignal(int)     # emits id of the session that just ended (manual or auto)

    def __init__(self, parent=None):
        super().__init__(parent)

        # --- State ---
        self._remaining_seconds = 0
        self.current_session_id = None
        self.actor_user_id = None        # logged-in teacher (set by TeacherDashboard) for the audit log
        self._auto_ending = False

        # --- Build UI ---
        self._build_ui()

        # --- Load data ---
        self._load_courses()
        self._load_sessions()
        self._refresh_timer_from_active_session()
        self._update_readiness()

        # --- Timer for live countdown in the TimerBox ---
        self._countdown_timer = QTimer(self)
        self._countdown_timer.timeout.connect(self._tick_countdown)
        self._countdown_timer.start(1000)

        # --- Timer for refreshing live student counts in history table ---
        self._refresh_timer = QTimer(self)
        self._refresh_timer.timeout.connect(self._refresh_live_counts)
        self._refresh_timer.start(5000)  # every 5 s


    # ==================================================================
    # UI BUILD
    # ==================================================================
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 22, 28, 22)
        root.setSpacing(18)

        # ---------- TOP ROW: Page title + TimerBox ----------
        top_row = QHBoxLayout()
        title_col = QVBoxLayout()
        title_col.setSpacing(2)
        page_title = QLabel("Session Control")
        page_title.setStyleSheet(f"font-size: 24px; font-weight: 800; color: {theme.NAVY_DARK};")
        title_col.addWidget(page_title)
        page_sub = QLabel("Smart Lab Exam Monitoring System")
        page_sub.setStyleSheet(f"font-size: 13px; color: {theme.TEXT_SECONDARY};")
        title_col.addWidget(page_sub)
        top_row.addLayout(title_col)
        top_row.addStretch()

        self.timer_box = TimerBox()
        top_row.addWidget(self.timer_box)
        root.addLayout(top_row)

        # ---------- Scrollable content ----------
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("background: transparent; border: none;")
        content = QWidget()
        content.setStyleSheet("background: transparent;")
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 6, 0, 6)
        content_layout.setSpacing(18)

        content_layout.addWidget(self._build_exam_details_section())
        content_layout.addWidget(self._build_security_section())
        content_layout.addWidget(self._build_readiness_section())
        content_layout.addWidget(self._build_history_section())

        # Footer note
        footer = QLabel(
            "ℹ  Only one active session is allowed at a time. "
            "Please end the current session to create a new one."
        )
        footer.setObjectName("infoFooter")
        content_layout.addWidget(footer)

        content_layout.addStretch()
        scroll.setWidget(content)
        root.addWidget(scroll, stretch=1)

    # ==================================================================
    # ① EXAM DETAILS
    # ==================================================================
    def _build_exam_details_section(self) -> QFrame:
        card = _card_frame()
        v = QVBoxLayout(card)
        v.setContentsMargins(22, 18, 22, 20)
        v.setSpacing(14)

        v.addWidget(SectionHeader(1, "Exam Details"))

        # 4-column row: Course | Exam Title | Duration | Exam Paper
        row = QHBoxLayout()
        row.setSpacing(14)

        # --- Course ---
        course_col = QVBoxLayout()
        course_col.setSpacing(6)
        lbl_course = QLabel("Course")
        lbl_course.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 12px; font-weight: 700;")
        course_col.addWidget(lbl_course)

        course_row = QHBoxLayout()
        course_row.setSpacing(6)
        self.course_combo = QComboBox()
        self.course_combo.setMinimumHeight(42)
        self.course_combo.setStyleSheet(f"""
            QComboBox {{
                border: 1px solid {theme.BORDER};
                border-radius: 8px;
                padding: 8px 12px;
                font-size: 14px;
                background: {theme.CARD_BG};
            }}
            QComboBox:focus {{ border: 1px solid {theme.NAVY}; }}
        """)
        self.course_combo.currentIndexChanged.connect(self._update_readiness)
        course_row.addWidget(self.course_combo, stretch=1)

        self.add_course_btn = QPushButton("+ New")
        self.add_course_btn.setObjectName("addCourseBtn")
        self.add_course_btn.setCursor(Qt.PointingHandCursor)
        self.add_course_btn.setFixedHeight(42)
        self.add_course_btn.clicked.connect(self._on_add_course)
        course_row.addWidget(self.add_course_btn)
        course_col.addLayout(course_row)
        row.addLayout(course_col, stretch=3)

        # --- Exam Title ---
        title_col = QVBoxLayout()
        title_col.setSpacing(6)
        lbl_title = QLabel("Exam Title")
        lbl_title.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 12px; font-weight: 700;")
        title_col.addWidget(lbl_title)
        self.exam_title_input = QLineEdit()
        self.exam_title_input.setPlaceholderText("e.g. Lab Final Examination")
        self.exam_title_input.setMinimumHeight(42)
        self.exam_title_input.setStyleSheet(f"""
            QLineEdit {{
                border: 1px solid {theme.BORDER};
                border-radius: 8px;
                padding: 8px 12px;
                font-size: 14px;
                background: {theme.CARD_BG};
            }}
            QLineEdit:focus {{ border: 1px solid {theme.NAVY}; }}
        """)
        self.exam_title_input.textChanged.connect(self._update_readiness)
        title_col.addWidget(self.exam_title_input)
        row.addLayout(title_col, stretch=3)

        # --- Duration ---
        dur_col = QVBoxLayout()
        dur_col.setSpacing(6)
        lbl_dur = QLabel("Duration")
        lbl_dur.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 12px; font-weight: 700;")
        dur_col.addWidget(lbl_dur)
        dur_row = QHBoxLayout()
        dur_row.setSpacing(6)

        self.hours_spin = QSpinBox()
        self.hours_spin.setRange(0, 8)
        self.hours_spin.setValue(1)
        self.hours_spin.setSuffix(" hr")
        self.hours_spin.setMinimumHeight(42)
        self.hours_spin.setStyleSheet(self._spinbox_style())
        self.hours_spin.valueChanged.connect(self._update_readiness)
        dur_row.addWidget(self.hours_spin)

        self.minutes_spin = QSpinBox()
        self.minutes_spin.setRange(0, 59)
        self.minutes_spin.setValue(0)
        self.minutes_spin.setSuffix(" min")
        self.minutes_spin.setMinimumHeight(42)
        self.minutes_spin.setStyleSheet(self._spinbox_style())
        self.minutes_spin.valueChanged.connect(self._update_readiness)
        dur_row.addWidget(self.minutes_spin)

        dur_col.addLayout(dur_row)
        row.addLayout(dur_col, stretch=2)

        # --- Exam Paper ---
        paper_col = QVBoxLayout()
        paper_col.setSpacing(6)
        lbl_paper = QLabel("Exam Paper")
        lbl_paper.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 12px; font-weight: 700;")
        paper_col.addWidget(lbl_paper)

        self.file_upload_row = FileUploadRow()
        self.file_upload_row.file_selected.connect(self._on_exam_paper_selected)
        paper_col.addWidget(self.file_upload_row)
        row.addLayout(paper_col, stretch=4)

        v.addLayout(row)
        return card

    # ==================================================================
    # ② SECURITY & RESTRICTIONS
    # ==================================================================
    def _build_security_section(self) -> QFrame:
        card = _card_frame()
        v = QVBoxLayout(card)
        v.setContentsMargins(22, 18, 22, 20)
        v.setSpacing(14)

        v.addWidget(SectionHeader(2, "Security & Restrictions"))

        # ---- S1: one-click presets -------------------------------------------------
        preset_row = QHBoxLayout()
        preset_row.setSpacing(8)
        preset_lbl = QLabel("Quick presets:")
        preset_lbl.setStyleSheet(f"color: {theme.NAVY_DARK}; font-size: 13px; font-weight: 700;")
        preset_row.addWidget(preset_lbl)
        self.preset_buttons = {}
        for name in preset_names():
            b = QPushButton(name)
            b.setObjectName("ghostBtn")
            b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            b.setMinimumHeight(32)
            b.setToolTip("Tick / untick every app and website in this group")
            b.clicked.connect(lambda checked, n=name: self._on_preset_toggled(n, checked))
            self.preset_buttons[name] = b
            preset_row.addWidget(b)
        preset_row.addStretch()
        v.addLayout(preset_row)

        row = QHBoxLayout()
        row.setSpacing(14)

        # --- Blocked Apps ---
        apps_col = QVBoxLayout()
        apps_col.setSpacing(8)
        apps_lbl = QLabel("Blocked Applications")
        apps_lbl.setStyleSheet(f"color: {theme.NAVY_DARK}; font-size: 13px; font-weight: 700;")
        apps_col.addWidget(apps_lbl)

        self.apps_list = SearchableCheckList(
            AVAILABLE_BLOCKED_APPS,
            default_checked=DEFAULT_BLOCKED_APPS,
        )
        self.apps_list.selection_changed.connect(self._update_readiness)
        apps_col.addWidget(self.apps_list)
        apps_container = QFrame()
        apps_container.setStyleSheet(f"""
            QFrame {{
                background: {theme.CARD_BG};
                border: 1px solid {theme.BORDER};
                border-radius: 10px;
            }}
        """)
        apps_container.setLayout(apps_col)
        apps_col.setContentsMargins(14, 12, 14, 12)
        row.addWidget(apps_container, stretch=1)

        # --- Blocked Domains ---
        domains_col = QVBoxLayout()
        domains_col.setSpacing(8)
        domains_lbl = QLabel("Blocked Websites")
        domains_lbl.setStyleSheet(f"color: {theme.NAVY_DARK}; font-size: 13px; font-weight: 700;")
        domains_col.addWidget(domains_lbl)

        self.domains_list = SearchableCheckList(
            AVAILABLE_BLOCKED_DOMAINS,
            default_checked=DEFAULT_BLOCKED_DOMAINS,
        )
        self.domains_list.selection_changed.connect(self._update_readiness)
        domains_col.addWidget(self.domains_list)
        domains_container = QFrame()
        domains_container.setStyleSheet(f"""
            QFrame {{
                background: {theme.CARD_BG};
                border: 1px solid {theme.BORDER};
                border-radius: 10px;
            }}
        """)
        domains_container.setLayout(domains_col)
        domains_col.setContentsMargins(14, 12, 14, 12)
        row.addWidget(domains_container, stretch=1)

        # --- Security Options ---
        sec_col = QVBoxLayout()
        sec_col.setSpacing(8)
        sec_lbl = QLabel("Security Options")
        sec_lbl.setStyleSheet(f"color: {theme.NAVY_DARK}; font-size: 13px; font-weight: 700;")
        sec_col.addWidget(sec_lbl)

        self.security_option_rows = {}
        for key, label in SECURITY_OPTION_LABELS:
            checked = DEFAULT_SECURITY_OPTIONS.get(key, True)
            row_w = SecurityOptionRow(key, label, checked)
            self.security_option_rows[key] = row_w
            sec_col.addWidget(row_w)

        sec_col.addSpacing(6)
        self.advanced_btn = QPushButton("⚙  Advanced Settings")
        self.advanced_btn.setObjectName("ghostBtn")
        self.advanced_btn.setMinimumHeight(38)
        self.advanced_btn.setCursor(Qt.PointingHandCursor)
        self.advanced_btn.clicked.connect(self._on_advanced_settings)
        sec_col.addWidget(self.advanced_btn)
        sec_col.addStretch()

        sec_container = QFrame()
        sec_container.setStyleSheet(f"""
            QFrame {{
                background: {theme.CARD_BG};
                border: 1px solid {theme.BORDER};
                border-radius: 10px;
            }}
        """)
        sec_container.setLayout(sec_col)
        sec_col.setContentsMargins(14, 12, 14, 12)
        row.addWidget(sec_container, stretch=2)

        v.addLayout(row)

        # ---- row 2: roster (S8) + allow-list apps (S5) ----------------------------------
        row2 = QHBoxLayout()
        row2.setSpacing(14)

        roster_col = QVBoxLayout()
        roster_col.setSpacing(6)
        roster_lbl = QLabel("Roster - registered students (optional)")
        roster_lbl.setStyleSheet(f"color: {theme.NAVY_DARK}; font-size: 13px; font-weight: 700;")
        roster_col.addWidget(roster_lbl)
        self.roster_text = QPlainTextEdit()
        self.roster_text.setPlaceholderText("One student per line:\n21F-1001, Ali Khan\n21F-1002, Sara Ahmed")
        self.roster_text.setMinimumHeight(90)
        self.roster_text.setMaximumHeight(120)
        self.roster_text.textChanged.connect(self._on_roster_changed)
        roster_col.addWidget(self.roster_text)
        roster_btn_row = QHBoxLayout()
        self.roster_import_btn = QPushButton("Import CSV / TXT…")
        self.roster_import_btn.setObjectName("ghostBtn")
        self.roster_import_btn.setCursor(Qt.PointingHandCursor)
        self.roster_import_btn.clicked.connect(self._on_import_roster)
        roster_btn_row.addWidget(self.roster_import_btn)
        self.roster_count_lbl = QLabel("0 students")
        self.roster_count_lbl.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 12px;")
        roster_btn_row.addWidget(self.roster_count_lbl)
        roster_btn_row.addStretch()
        roster_col.addLayout(roster_btn_row)
        roster_box = QFrame()
        roster_box.setStyleSheet(f"QFrame {{ background: {theme.CARD_BG}; border: 1px solid {theme.BORDER}; border-radius: 10px; }}")
        roster_box.setLayout(roster_col)
        roster_col.setContentsMargins(14, 12, 14, 12)
        row2.addWidget(roster_box, stretch=1)

        allow_col = QVBoxLayout()
        allow_col.setSpacing(6)
        allow_lbl = QLabel("Allowed applications (for allow-list mode)")
        allow_lbl.setStyleSheet(f"color: {theme.NAVY_DARK}; font-size: 13px; font-weight: 700;")
        allow_col.addWidget(allow_lbl)
        self.allowed_apps_input = QLineEdit()
        self.allowed_apps_input.setPlaceholderText("e.g. code, notepad, winword, devenv")
        self.allowed_apps_input.setMinimumHeight(38)
        self.allowed_apps_input.setEnabled(False)
        allow_col.addWidget(self.allowed_apps_input)
        allow_help = QLabel("Only windows of these programs may stay open. System programs and SLEMS "
                            "are always protected. Windows only.")
        allow_help.setWordWrap(True)
        allow_help.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 12px;")
        allow_col.addWidget(allow_help)
        allow_col.addStretch()
        allow_box = QFrame()
        allow_box.setStyleSheet(f"QFrame {{ background: {theme.CARD_BG}; border: 1px solid {theme.BORDER}; border-radius: 10px; }}")
        allow_box.setLayout(allow_col)
        allow_col.setContentsMargins(14, 12, 14, 12)
        row2.addWidget(allow_box, stretch=1)
        v.addLayout(row2)

        self.security_option_rows["allowlist_mode"].checkbox.stateChanged.connect(
            lambda _: self.allowed_apps_input.setEnabled(self.security_option_rows["allowlist_mode"].is_checked()))
        return card

    # ---- S1 preset handling ----------------------------------------------------------
    def _on_preset_toggled(self, name: str, checked: bool):
        apps, domains = expand_presets([name])
        self.apps_list.set_checked(apps, checked)
        self.domains_list.set_checked(domains, checked)
        self._update_readiness()

    # ---- S8 roster handling ----------------------------------------------------------
    def _roster_rows(self):
        return students_repo.parse_roster_text(self.roster_text.toPlainText())

    def _on_roster_changed(self):
        n = len(self._roster_rows())
        self.roster_count_lbl.setText(f"{n} student{'s' if n != 1 else ''}")
        self._update_readiness()

    def _on_import_roster(self):
        path, _ = QFileDialog.getOpenFileName(self, "Import roster", "", "CSV / text (*.csv *.txt);;All files (*)")
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8-sig") as f:
                self.roster_text.setPlainText(f.read())
        except (OSError, UnicodeDecodeError) as e:
            QMessageBox.warning(self, "Import failed", f"Could not read the file:\n{e}")

    # ==================================================================
    # ③ SESSION READINESS
    # ==================================================================
    def _build_readiness_section(self) -> QFrame:
        card = _card_frame()
        v = QVBoxLayout(card)
        v.setContentsMargins(22, 18, 22, 20)
        v.setSpacing(14)

        v.addWidget(SectionHeader(3, "Session Readiness"))

        row = QHBoxLayout()
        row.setSpacing(10)

        # 5 chips
        self.chip_course = ReadinessChip("Course selected")
        self.chip_duration = ReadinessChip("Duration configured")
        self.chip_paper = ReadinessChip("Exam paper uploaded")
        self.chip_restrictions = ReadinessChip("Restrictions configured")
        self.chip_students = ReadinessChip("Roster loaded (optional)")

        for c in (self.chip_course, self.chip_duration, self.chip_paper,
                  self.chip_restrictions, self.chip_students):
            row.addWidget(c)

        row.addStretch()

        # Review & Start Exam button
        self.start_btn = QPushButton("▶  Review & Start Exam")
        self.start_btn.setObjectName("goldBtn")
        self.start_btn.setMinimumHeight(48)
        self.start_btn.setMinimumWidth(220)
        self.start_btn.setCursor(Qt.PointingHandCursor)
        self.start_btn.clicked.connect(self._on_start_exam)
        row.addWidget(self.start_btn)

        v.addLayout(row)
        return card

    # ==================================================================
    # ④ SESSION HISTORY
    # ==================================================================
    def _build_history_section(self) -> QFrame:
        card = _card_frame()
        v = QVBoxLayout(card)
        v.setContentsMargins(22, 18, 22, 20)
        v.setSpacing(14)

        header_row = QHBoxLayout()
        header_row.addWidget(SectionHeader(4, "Session History"))
        header_row.addStretch()

        self.refresh_btn = QPushButton("↻  Refresh")
        self.refresh_btn.setObjectName("ghostBtn")
        self.refresh_btn.setMinimumHeight(36)
        self.refresh_btn.setCursor(Qt.PointingHandCursor)
        self.refresh_btn.clicked.connect(self._load_sessions)
        header_row.addWidget(self.refresh_btn)

        v.addLayout(header_row)

        # Table
        self.sessions_table = QTableWidget(0, 8)
        self.sessions_table.setHorizontalHeaderLabels(
            ["ID", "Join Code", "Course", "Duration", "Status", "Students", "Created", "Actions"]
        )
        self.sessions_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        for col in [0, 1, 3, 4, 5, 6, 7]:
            self.sessions_table.horizontalHeader().setSectionResizeMode(col, QHeaderView.ResizeToContents)
        self.sessions_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.sessions_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.sessions_table.verticalHeader().setVisible(False)
        self.sessions_table.setMinimumHeight(280)
        self.sessions_table.setStyleSheet(f"""
            QTableWidget {{
                font-size: 14px;
                background: {theme.CARD_BG};
                border: 1px solid {theme.BORDER};
                border-radius: 10px;
                gridline-color: {theme.BORDER};
            }}
            QHeaderView::section {{
                background: {theme.NAVY_DARK};
                color: {theme.TEXT_ON_NAVY};
                padding: 10px 12px;
                font-weight: 700;
                font-size: 13px;
                border: none;
            }}
            QTableWidget::item {{
                padding: 10px 12px;
                border-bottom: 1px solid {theme.BORDER};
            }}
        """)
        v.addWidget(self.sessions_table)

        return card

    # ==================================================================
    # HELPERS
    # ==================================================================
    @staticmethod
    def _spinbox_style() -> str:
        return f"""
            QSpinBox {{
                border: 1px solid {theme.BORDER};
                border-radius: 8px;
                padding: 8px;
                font-size: 14px;
                background: {theme.CARD_BG};
                min-width: 90px;
            }}
            QSpinBox:focus {{ border: 1px solid {theme.NAVY}; }}
        """

    # ==================================================================
    # DATA LOADING
    # ==================================================================
    def _load_courses(self):
        """Populate course dropdown from PostgreSQL."""
        self.course_combo.blockSignals(True)
        self.course_combo.clear()
        try:
            courses = courses_repo.get_all_courses()
            for c in courses:
                self.course_combo.addItem(c.name, userData=c.id)
        except Exception as e:
            logger.exception("Failed to load courses")
            QMessageBox.warning(self, "DB Error", f"Could not load courses:\n{e}")
        self.course_combo.blockSignals(False)

    def _load_sessions(self):
        """Populate Session History table with live student count."""
        try:
            sessions = sessions_repo.get_sessions_with_student_count(limit=100)
        except Exception as e:
            logger.exception("Failed to load sessions")
            QMessageBox.warning(self, "DB Error", f"Could not load sessions:\n{e}")
            return

        self.sessions_table.setRowCount(len(sessions))

        for row_idx, s in enumerate(sessions):
            # ID
            id_item = QTableWidgetItem(str(s.id))
            id_item.setTextAlignment(Qt.AlignCenter)
            self.sessions_table.setItem(row_idx, 0, id_item)

            # Course
            code_item = QTableWidgetItem(s.join_code if s.status == "active" and s.join_code else "-")
            code_item.setTextAlignment(Qt.AlignCenter)
            if s.status == "active" and s.join_code:
                cf = code_item.font(); cf.setBold(True); cf.setPointSize(cf.pointSize() + 3)
                code_item.setFont(cf)
            self.sessions_table.setItem(row_idx, 1, code_item)
            self.sessions_table.setItem(row_idx, 2, QTableWidgetItem(s.course_name))

            # Duration
            dur_item = QTableWidgetItem(format_duration_minutes(s.duration))
            dur_item.setTextAlignment(Qt.AlignCenter)
            self.sessions_table.setItem(row_idx, 3, dur_item)

            # Status
            status_item = QTableWidgetItem(s.status.upper())
            status_item.setTextAlignment(Qt.AlignCenter)
            if s.status == "active":
                status_item.setForeground(Qt.green)
                f = status_item.font()
                f.setBold(True)
                status_item.setFont(f)
            else:
                status_item.setForeground(Qt.gray)
            self.sessions_table.setItem(row_idx, 4, status_item)

            # Students (live count)
            cnt_item = QTableWidgetItem(str(s.student_count))
            cnt_item.setTextAlignment(Qt.AlignCenter)
            f = cnt_item.font()
            f.setBold(True)
            cnt_item.setFont(f)
            self.sessions_table.setItem(row_idx, 5, cnt_item)

            # Created
            self.sessions_table.setItem(
                row_idx, 6, QTableWidgetItem(format_datetime(s.created_at))
            )

            # Actions
            actions_w = QWidget()
            al = QHBoxLayout(actions_w)
            al.setContentsMargins(4, 4, 4, 4)
            al.setSpacing(6)

            if s.status == "active":
                mon_btn = QPushButton("Monitor")
                mon_btn.setObjectName("monitorBtn")
                mon_btn.setCursor(Qt.PointingHandCursor)
                mon_btn.clicked.connect(lambda _, sid=s.id: self.monitor_requested.emit(sid))
                al.addWidget(mon_btn)

                end_btn = QPushButton("End")
                end_btn.setObjectName("monitorBtn")
                end_btn.setStyleSheet(f"""
                    QPushButton {{
                        background: {theme.STATUS_BEHAVIORAL};
                        color: white;
                        border: none;
                        border-radius: 6px;
                        padding: 6px 14px;
                        font-size: 12px;
                        font-weight: 700;
                    }}
                    QPushButton:hover {{ background: #C43030; }}
                """)
                end_btn.setCursor(Qt.PointingHandCursor)
                end_btn.clicked.connect(lambda _, sid=s.id: self._end_specific_session(sid))
                al.addWidget(end_btn)
            else:
                rep_btn = QPushButton("View Report")
                rep_btn.setObjectName("reportBtn")
                rep_btn.setCursor(Qt.PointingHandCursor)
                rep_btn.clicked.connect(lambda _, sid=s.id: self.report_requested.emit(sid))
                al.addWidget(rep_btn)

            al.addStretch()
            self.sessions_table.setCellWidget(row_idx, 7, actions_w)

        # Update readiness (student chip)
        self._update_readiness()

    def _refresh_live_counts(self):
        """Refresh student counts every 5 s without rebuilding the whole table."""
        try:
            sessions = sessions_repo.get_sessions_with_student_count(limit=100)
        except Exception:
            return
        for row_idx, s in enumerate(sessions):
            if row_idx >= self.sessions_table.rowCount():
                break
            item = self.sessions_table.item(row_idx, 5)
            if item:
                item.setText(str(s.student_count))

    def _refresh_timer_from_active_session(self):
        """Set TimerBox from the currently active session, if any."""
        try:
            active = sessions_repo.get_active_session()
        except Exception:
            active = None

        if active and active.created_at:
            from datetime import datetime
            elapsed = (datetime.now() - active.created_at).total_seconds()
            total = active.duration * 60
            self._remaining_seconds = max(0, int(total - elapsed))
            self.current_session_id = active.id
        else:
            self._remaining_seconds = 0
            self.current_session_id = None

        self.timer_box.set_time(self._remaining_seconds)

    def _tick_countdown(self):
        if self._remaining_seconds > 0:
            self._remaining_seconds -= 1
            self.timer_box.set_time(self._remaining_seconds)

        # S12: time is up -> end the session by itself and tell the students
        if self._remaining_seconds <= 0 and self.current_session_id and not self._auto_ending:
            self._auto_ending = True
            sid = self.current_session_id
            try:
                ok, msg = self._finish_session(sid, auto=True)
                if ok:
                    QMessageBox.information(
                        self, "Time Up",
                        f"Session #{sid} reached its time limit and was ended automatically.\n"
                        "Students were told to stop and their files were auto-submitted.")
                else:
                    self.current_session_id = None          # already ended elsewhere
            finally:
                self._auto_ending = False

    def _finish_session(self, session_id: int, auto: bool = False):
        """End in DB, write the audit trail, tell the dashboard (-> students).  (ok, message)"""
        ok, msg = sessions_repo.end_session(session_id)
        if not ok:
            return False, msg
        audit_repo.log("session_ended_auto" if auto else "session_ended",
                       session_id=session_id, actor_user_id=self.actor_user_id,
                       detail="time limit reached" if auto else "ended by teacher")
        if self.current_session_id == session_id:
            self.current_session_id = None
            self._remaining_seconds = 0
            self.timer_box.set_time(0)
        self._load_sessions()
        self.session_ended.emit(session_id)        # TeacherDashboard broadcasts SESSION_END
        return True, msg

    # ==================================================================
    # READINESS LOGIC
    # ==================================================================
    def _update_readiness(self):
        # 1. Course selected
        course_ok = self.course_combo.currentIndex() >= 0 and bool(self.course_combo.currentText().strip())

        # 2. Duration configured
        duration_ok = (self.hours_spin.value() * 60 + self.minutes_spin.value()) > 0

        # 3. Exam paper uploaded
        paper_ok = bool(self.file_upload_row.get_file_path())

        # 4. Restrictions configured (at least 1 app OR 1 domain)
        restrictions_ok = (
            self.apps_list.count_selected() > 0
            or self.domains_list.count_selected() > 0
        )

        # 5. Roster pasted / imported (optional)
        students_ok = len(self._roster_rows()) > 0 if hasattr(self, "roster_text") else False

        self.chip_course.set_ok(course_ok)
        self.chip_duration.set_ok(duration_ok)
        self.chip_paper.set_ok(paper_ok)
        self.chip_restrictions.set_ok(restrictions_ok)
        self.chip_students.set_ok(students_ok)

        # Enable Start button only if the first 4 are ready
        # (5th chip is optional — students join after start)
        can_start = course_ok and duration_ok and paper_ok and restrictions_ok
        self.start_btn.setEnabled(can_start)

    # ==================================================================
    # EVENT HANDLERS
    # ==================================================================
    def _on_add_course(self):
        dlg = AddCourseDialog(self)
        if dlg.exec_() == QDialog.Accepted and dlg.course_name:
            ok, course, msg = courses_repo.add_course(dlg.course_name)
            if ok:
                self._load_courses()
                # Select the newly added course
                idx = self.course_combo.findText(course.name)
                if idx >= 0:
                    self.course_combo.setCurrentIndex(idx)
                QMessageBox.information(self, "Course Added", msg)
            else:
                QMessageBox.warning(self, "Failed", msg)

    def _on_exam_paper_selected(self, path: str):
        """Validate size + extension."""
        if not path:
            return

        ext = os.path.splitext(path)[1].lower()
        if ext not in ALLOWED_EXAM_PAPER_EXTENSIONS:
            QMessageBox.warning(
                self, "Invalid File",
                f"Only {', '.join(ALLOWED_EXAM_PAPER_EXTENSIONS)} files are allowed."
            )
            self.file_upload_row.clear()
            self._update_readiness()
            return

        try:
            size = os.path.getsize(path)
        except OSError:
            size = 0

        if size > MAX_EXAM_PAPER_SIZE_BYTES:
            QMessageBox.warning(
                self, "File Too Large",
                f"Maximum allowed size is {MAX_EXAM_PAPER_SIZE_MB} MB.\n"
                f"Your file is {size / (1024*1024):.2f} MB."
            )
            self.file_upload_row.clear()
            self._update_readiness()
            return

        self._update_readiness()

    def _on_advanced_settings(self):
        QMessageBox.information(
            self, "Advanced Settings",
            "Advanced settings will be added in a future phase."
        )

    def _on_start_exam(self):
        # One active session rule
        try:
            active = sessions_repo.get_active_session()
        except Exception as e:
            QMessageBox.critical(self, "DB Error", f"Could not check active session:\n{e}")
            return

        if active:
            QMessageBox.warning(
                self, "Active Session Exists",
                f"Session #{active.id} ({active.course_name}) is already active.\n"
                f"Please end it before creating a new session."
            )
            return

        # Gather inputs
        course_name = self.course_combo.currentText().strip()
        exam_title = self.exam_title_input.text().strip() or "Lab Exam"
        duration_min = self.hours_spin.value() * 60 + self.minutes_spin.value()
        exam_paper_path = self.file_upload_row.get_file_path()
        exam_paper_size = os.path.getsize(exam_paper_path) if exam_paper_path and os.path.exists(exam_paper_path) else 0
        blocked_apps = self.apps_list.get_selected()
        blocked_domains = self.domains_list.get_selected()
        security_options = {k: r.is_checked() for k, r in self.security_option_rows.items()}
        allowed_apps = [a.strip() for a in self.allowed_apps_input.text().split(",") if a.strip()]
        security_options["allowed_apps"] = allowed_apps
        roster = self._roster_rows()

        # Final safety checks
        if not course_name:
            QMessageBox.warning(self, "Missing", "Please select a course.")
            return
        if duration_min <= 0:
            QMessageBox.warning(self, "Missing", "Duration must be greater than 0.")
            return
        if not exam_paper_path:
            QMessageBox.warning(self, "Missing", "Please upload the exam paper.")
            return
        if not (blocked_apps or blocked_domains):
            QMessageBox.warning(self, "Missing", "Select at least one app or website to block.")
            return
        if security_options.get("allowlist_mode") and not allowed_apps:
            QMessageBox.warning(self, "Allow-list is empty",
                "Allow-list mode would close EVERY window, including the exam editor.\n"
                "Type the allowed programs (e.g. code, notepad) or turn the option off.")
            return
        if security_options.get("require_roster") and not roster:
            QMessageBox.warning(self, "Roster is empty",
                "\"Only registered students may join\" needs a roster.\n"
                "Paste or import the student list, or turn the option off.")
            return

        # Confirmation dialog
        summary = (
            f"<b>Course:</b> {course_name}<br>"
            f"<b>Exam Title:</b> {exam_title}<br>"
            f"<b>Duration:</b> {format_duration_minutes(duration_min)}<br>"
            f"<b>Exam Paper:</b> {os.path.basename(exam_paper_path)} "
            f"({exam_paper_size/(1024*1024):.2f} MB)<br>"
            f"<b>Blocked Apps:</b> {len(blocked_apps)}<br>"
            f"<b>Blocked Domains:</b> {len(blocked_domains)}<br>"
            f"<b>Roster:</b> {len(roster)} student(s)<br>"
            f"<b>Security Options:</b> {sum(1 for k, v in security_options.items() if v is True)} enabled"
        )
        reply = QMessageBox.question(
            self, "Confirm Start Exam",
            f"<b>Start this exam session?</b><br><br>{summary}",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if reply != QMessageBox.Yes:
            return

        # Create session
        ok, session, msg = sessions_repo.create_session(
            course_name=course_name,
            exam_title=exam_title,
            duration_minutes=duration_min,
            exam_paper_path=exam_paper_path,
            exam_paper_size=exam_paper_size,
            blocked_apps=blocked_apps,
            blocked_domains=blocked_domains,
            security_options=security_options,
        )

        if not ok:
            QMessageBox.critical(self, "Failed", msg)
            return

        if roster:
            students_repo.add_roster(session.id, roster)
        audit_repo.log("session_started", session_id=session.id, actor_user_id=self.actor_user_id,
                       detail=f"{course_name}; {len(blocked_apps)} apps, {len(blocked_domains)} sites, "
                              f"{len(roster)} roster")

        # Reset UI
        self.current_session_id = session.id
        self._remaining_seconds = duration_min * 60
        self.timer_box.set_time(self._remaining_seconds)

        self.file_upload_row.clear()
        self.exam_title_input.clear()
        self.roster_text.clear()
        self._load_sessions()
        self._update_readiness()

        QMessageBox.information(
            self, "Session Started",
            f"Session #{session.id} '{session.course_name}' started successfully!\n\n"
            f"JOIN CODE:  {session.join_code}\n\n"
            f"Give students this 6-digit code. It only works while this session is active."
        )

        self.session_started.emit(session.id)

    def _end_specific_session(self, session_id: int):
        reply = QMessageBox.question(
            self, "End Session",
            f"End session #{session_id}?\n\n"
            "This will finalize the session. Students can no longer join.",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if reply != QMessageBox.Yes:
            return

        ok, msg = self._finish_session(session_id, auto=False)
        if ok:
            QMessageBox.information(self, "Session Ended",
                                    msg + "\nStudents have been told to stop and are unlocked.")
        else:
            QMessageBox.warning(self, "Could not end session", msg)
