# SLEMS - 5-minute demo script (40% milestone)

**Setup before the audience arrives (2 PCs on the same Wi-Fi/LAN, both run SLEMS as Administrator)**
- Teacher PC: PostgreSQL running, `python main.py`, logged in as teacher. Student PC: `python main.py`.
- Teacher PC IP written on a sticky note (`ipconfig`). A small exam paper file (PDF) ready. Browser open on the student PC.
- Run `python restore_hosts.py` on the student PC once so you start clean.

| Time | Who | Do this | Say / show |
|---|---|---|---|
| 0:00 | Teacher | Open **Session Control**. Choose course, 30 min, upload the paper. | "One screen sets up the whole exam." |
| 0:30 | Teacher | Click preset **AI assistants** and **Messaging & chat**. Show the ticked lists. | "One click blocks every address of ChatGPT, Gemini, Claude, WhatsApp, Discord - not just one name." |
| 0:50 | Teacher | Paste roster `21F-1001, Ali` / `21F-1002, Sara`, tick **Only registered students may join**. Press **Review & Start**. | "Only listed students can enter." Show the **6-digit join code** in the pop-up and history table. |
| 1:20 | Student | Login as student. Enter teacher IP, the code, roll `21F-1001`. | Exam screen appears with the timer. |
| 1:40 | Student | Try a stranger roll (`99X-0000`) on a 2nd window or say it. | "Refused - not on the roster." (already tested; optional live) |
| 2:00 | Student | Open `chatgpt.com` in the browser. | "Site will not load." Open a notepad `hosts` file to show the SLEMS block (IPv4 + IPv6). |
| 2:20 | Student | Start **Discord/WhatsApp/Telegram** (or a renamed copy). | "Closed in under a second." |
| 2:40 | Teacher | **Live Monitor -> Table view**. Show ONLINE, Blocks count, Violations. **Violation Log -> Block Events**: show the kill and its latency in ms. | "Every kill is logged with a timestamp - this is our proof of the 2-second rule." |
| 3:10 | Teacher | Right-click the student -> **Pause blocking (emergency)**, reason "PC problem". Student can open the site. Then **Resume**. Show **Audit Log** tab. | "A teacher can fix a wrong block, and it is recorded." |
| 3:50 | Student | Close SLEMS from Task Manager. | Teacher tile turns red OFFLINE + high-severity violation. Restart SLEMS: hosts file auto-cleaned ("crash recovery"). |
| 4:20 | Student | (re-join) Select the exam file, press **Submit**. | Upload progress -> SUBMITTED. Teacher **Reports** shows the file. |
| 4:40 | Teacher | Press **End** on the session. | Student screen returns to start; open `chatgpt.com` again - works. Hosts file clean. |
| 5:00 | Teacher | Show `docs/TEST_MATRIX.md`. | "35 automated tests, all passing." |

**If something goes wrong:** `python restore_hosts.py` (Administrator) cleans the hosts file in 2 seconds.
**Do not demo:** allow-list mode on a PC you need (it closes every window not on the list); AI model and live video (not part of 40%).
