"""
ai/rule_engine.py
Converts per-frame DetectionResults into time-windowed violation events.

v2.0 — Fast:
    - Looking away: 2.0 s (was 3.0)
    - Head turned: 2.0 s (was 3.0)
    - No face: 2.0 s (was 3.0)
    - Multiple faces: 1.5 s (was 2.0)
    - Phone near face: 1.5 s (was 2.5)
    - Live "active_signals" dict exposed via get_active_signals()
"""
import logging
import time
from dataclasses import dataclass
from typing import Dict, List

from ai.detection_engine import DetectionResult

logger = logging.getLogger(__name__)


# --- Thresholds (seconds) ---
LOOKING_AWAY_SEC = 2.0
HEAD_TURNED_SEC = 2.0
NO_FACE_SEC = 2.0
MULTIPLE_FACES_SEC = 1.5
PHONE_NEAR_FACE_SEC = 1.5
PHONE_DETECTED_SEC = 1.0

# --- Cooldowns (seconds) — don't spam same violation ---
COOLDOWN_SEC = 8.0


@dataclass
class ViolationEvent:
    violation_type: str
    description: str
    severity: str = "medium"
    timestamp: float = 0.0


class _RuleState:
    def __init__(self):
        self.start: float = 0.0
        self.last_fired: float = 0.0
        self.active: bool = False

    def update(self, condition: bool, now: float):
        if condition:
            if self.start == 0.0:
                self.start = now
            self.active = True
        else:
            self.start = 0.0
            self.active = False

    def duration(self, now: float) -> float:
        if self.start == 0.0:
            return 0.0
        return now - self.start


class RuleEngine:
    def __init__(self):
        self._looking_away = _RuleState()
        self._head_turned = _RuleState()
        self._no_face = _RuleState()
        self._multiple_faces = _RuleState()
        self._phone_near = _RuleState()
        self._phone_detected = _RuleState()

    # ------------------------------------------------------------------
    def evaluate(self, result: DetectionResult) -> List[ViolationEvent]:
        now = time.time()
        events: List[ViolationEvent] = []

        # Look away
        cond = result.looking_away and result.face_count > 0
        self._looking_away.update(cond, now)
        if self._looking_away.duration(now) >= LOOKING_AWAY_SEC:
            if self._can_fire(self._looking_away, now):
                events.append(ViolationEvent(
                    violation_type="behavioral",
                    description=f"Looking away from screen for {self._looking_away.duration(now):.1f}s ({result.gaze_direction.replace('away_','')})",
                    severity="medium",
                    timestamp=now,
                ))
                self._looking_away.last_fired = now

        # Head turned
        cond = result.head_turned and result.face_count > 0
        self._head_turned.update(cond, now)
        if self._head_turned.duration(now) >= HEAD_TURNED_SEC:
            if self._can_fire(self._head_turned, now):
                events.append(ViolationEvent(
                    violation_type="behavioral",
                    description=f"Head turned {result.head_direction} for {self._head_turned.duration(now):.1f}s",
                    severity="medium",
                    timestamp=now,
                ))
                self._head_turned.last_fired = now

        # No face
        cond = result.face_count == 0
        self._no_face.update(cond, now)
        if self._no_face.duration(now) >= NO_FACE_SEC:
            if self._can_fire(self._no_face, now):
                events.append(ViolationEvent(
                    violation_type="behavioral",
                    description=f"No face detected for {self._no_face.duration(now):.1f}s",
                    severity="high",
                    timestamp=now,
                ))
                self._no_face.last_fired = now

        # Multiple faces
        cond = result.multiple_faces
        self._multiple_faces.update(cond, now)
        if self._multiple_faces.duration(now) >= MULTIPLE_FACES_SEC:
            if self._can_fire(self._multiple_faces, now):
                events.append(ViolationEvent(
                    violation_type="behavioral",
                    description=f"Multiple faces detected ({result.face_count}) for {self._multiple_faces.duration(now):.1f}s",
                    severity="high",
                    timestamp=now,
                ))
                self._multiple_faces.last_fired = now

        # Phone near face (MediaPipe Hands heuristic)
        cond = result.phone_suspected
        self._phone_near.update(cond, now)
        if self._phone_near.duration(now) >= PHONE_NEAR_FACE_SEC:
            if self._can_fire(self._phone_near, now):
                events.append(ViolationEvent(
                    violation_type="behavioral",
                    description="Phone suspected near face",
                    severity="medium",
                    timestamp=now,
                ))
                self._phone_near.last_fired = now

        # Phone detected (YOLO)
        cond = result.yolo_phone_present
        self._phone_detected.update(cond, now)
        if self._phone_detected.duration(now) >= PHONE_DETECTED_SEC:
            if self._can_fire(self._phone_detected, now):
                events.append(ViolationEvent(
                    violation_type="service",
                    description=f"Phone detected (conf {result.yolo_phone_conf*100:.0f}%)",
                    severity="high",
                    timestamp=now,
                ))
                self._phone_detected.last_fired = now

        return events

    # ------------------------------------------------------------------
    @staticmethod
    def _can_fire(state: _RuleState, now: float) -> bool:
        return (now - state.last_fired) >= COOLDOWN_SEC

    # ------------------------------------------------------------------
    def get_active_signals(self) -> Dict[str, float]:
        """Return current durations for live GUI display."""
        now = time.time()
        out = {}
        for name, state in [
            ("LOOKING_AWAY", self._looking_away),
            ("HEAD_TURNED", self._head_turned),
            ("NO_FACE", self._no_face),
            ("MULTIPLE_FACES", self._multiple_faces),
            ("PHONE_NEAR", self._phone_near),
            ("PHONE_DETECTED", self._phone_detected),
        ]:
            if state.active:
                d = state.duration(now)
                if d > 0:
                    out[name] = round(d, 1)
        return out