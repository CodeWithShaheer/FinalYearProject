"""
ai/detection_engine.py
Single-pass detection engine with shared MediaPipe FaceMesh.

v2.0 — Performance:
    - Infers on a 320x240 downscaled copy (4x faster MediaPipe)
    - Landmarks are normalized, so frame size is transparent to logic
    - Camera BGR frames unchanged for WebRTC
"""
import logging
import time
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import cv2
import numpy as np

try:
    import mediapipe as mp
except ImportError:
    mp = None

logger = logging.getLogger(__name__)


LEFT_IRIS = [474, 475, 476, 477]
RIGHT_IRIS = [469, 470, 471, 472]
LEFT_EYE_CORNERS = (33, 133)
RIGHT_EYE_CORNERS = (362, 263)
LEFT_CHEEK = 234
RIGHT_CHEEK = 454
NOSE_TIP = 1
CHIN = 152
FOREHEAD = 10

HORIZONTAL_OFFSET_THRESHOLD = 0.30
VERTICAL_OFFSET_THRESHOLD = 0.40
YAW_THRESHOLD = 0.20
PITCH_THRESHOLD = 0.22

# Infer at this resolution (landmarks are normalized)
INFER_WIDTH = 320
INFER_HEIGHT = 240


@dataclass
class DetectionResult:
    face_count: int = 0
    face_box: Optional[Tuple[int, int, int, int]] = None

    gaze_direction: str = "unknown"
    gaze_h: float = 0.0
    gaze_v: float = 0.0

    head_direction: str = "unknown"
    head_yaw: float = 0.0
    head_pitch: float = 0.0

    hand_count: int = 0
    phone_suspected: bool = False
    hand_boxes: List[Tuple[int, int, int, int]] = field(default_factory=list)

    yolo_phone_present: bool = False
    yolo_phone_conf: float = 0.0

    inference_ms: float = 0.0

    @property
    def face_present(self) -> bool:
        return self.face_count > 0

    @property
    def multiple_faces(self) -> bool:
        return self.face_count > 1

    @property
    def looking_away(self) -> bool:
        return self.gaze_direction in ("away_left", "away_right", "away_up", "away_down")

    @property
    def head_turned(self) -> bool:
        return self.head_direction in ("left", "right", "up", "down")


class DetectionEngine:
    def __init__(self,
                 max_num_faces: int = 2,
                 min_face_detection_conf: float = 0.4,
                 max_num_hands: int = 2,
                 enable_yolo: bool = False,
                 yolo_frame_interval: int = 5):
        if mp is None:
            raise ImportError("mediapipe not installed. Run: pip install mediapipe")

        self._mp_face_detection = mp.solutions.face_detection
        self._mp_face_mesh = mp.solutions.face_mesh
        self._mp_hands = mp.solutions.hands

        self._face_detector = self._mp_face_detection.FaceDetection(
            model_selection=0,
            min_detection_confidence=min_face_detection_conf,
        )
        self._face_mesh = self._mp_face_mesh.FaceMesh(
            max_num_faces=max_num_faces,
            refine_landmarks=True,
            min_detection_confidence=min_face_detection_conf,
            min_tracking_confidence=0.5,
        )
        self._hands = self._mp_hands.Hands(
            max_num_hands=max_num_hands,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5,
        )

        # Optional YOLO
        self._enable_yolo = enable_yolo
        self._yolo = None
        self._yolo_frame_interval = max(1, yolo_frame_interval)
        self._yolo_frame_counter = 0
        self._last_yolo_result = None

    # ------------------------------------------------------------------
    def load(self) -> bool:
        """Load optional heavy models (YOLO). Safe."""
        if not self._enable_yolo:
            return True
        try:
            from ai.yolo_detector import YoloDetector
            self._yolo = YoloDetector()
            return self._yolo.load()
        except Exception:
            logger.exception("YOLO init failed")
            self._yolo = None
            return False

    # ------------------------------------------------------------------
    def detect(self, bgr_frame: np.ndarray) -> DetectionResult:
        t0 = time.time()
        result = DetectionResult()

        if bgr_frame is None:
            result.inference_ms = (time.time() - t0) * 1000
            return result

        orig_h, orig_w = bgr_frame.shape[:2]

        # Downscale for inference
        small = cv2.resize(bgr_frame, (INFER_WIDTH, INFER_HEIGHT),
                           interpolation=cv2.INTER_LINEAR)
        rgb = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)
        rgb.flags.writeable = False

        w, h = INFER_WIDTH, INFER_HEIGHT

        # --- Face detection ---
        try:
            fd = self._face_detector.process(rgb)
            if fd.detections:
                result.face_count = len(fd.detections)
                largest = None
                largest_area = 0
                for det in fd.detections:
                    bbox = det.location_data.relative_bounding_box
                    x = int(bbox.xmin * w)
                    y = int(bbox.ymin * h)
                    bw = int(bbox.width * w)
                    bh = int(bbox.height * h)
                    area = bw * bh
                    if area > largest_area:
                        largest_area = area
                        largest = (x, y, bw, bh)
                # Scale back to original coords
                if largest:
                    sx = orig_w / float(w)
                    sy = orig_h / float(h)
                    result.face_box = (
                        int(largest[0] * sx),
                        int(largest[1] * sy),
                        int(largest[2] * sx),
                        int(largest[3] * sy),
                    )
        except Exception:
            logger.exception("face detection failed")

        # --- Face mesh (gaze + head) ---
        try:
            mesh = self._face_mesh.process(rgb)
            if mesh.multi_face_landmarks:
                lm = mesh.multi_face_landmarks[0].landmark
                self._compute_gaze(lm, w, h, result)
                self._compute_head(lm, result)
        except Exception:
            logger.exception("face mesh failed")

        # --- Hands ---
        try:
            hands = self._hands.process(rgb)
            if hands.multi_hand_landmarks:
                result.hand_count = len(hands.multi_hand_landmarks)
                for hl in hands.multi_hand_landmarks:
                    xs = [p.x * w for p in hl.landmark]
                    ys = [p.y * h for p in hl.landmark]
                    x_min, x_max = int(min(xs)), int(max(xs))
                    y_min, y_max = int(min(ys)), int(max(ys))
                    result.hand_boxes.append(
                        (x_min, y_min, x_max - x_min, y_max - y_min)
                    )
                if result.face_box and result.hand_boxes:
                    # face_box is in original coords, but hand_boxes in small coords
                    sx = w / float(orig_w)
                    sy = h / float(orig_h)
                    fx, fy, fw, fh = result.face_box
                    fx = int(fx * sx); fy = int(fy * sy)
                    fw = int(fw * sx); fh = int(fh * sy)
                    lower_face = (fx, fy + fh // 2, fw, fh // 2)
                    for hb in result.hand_boxes:
                        if self._overlap_ratio(hb, lower_face) > 0.25:
                            result.phone_suspected = True
                            break
        except Exception:
            logger.exception("hands detection failed")

        # --- YOLO (throttled) ---
        if self._yolo is not None:
            self._yolo_frame_counter += 1
            if self._yolo_frame_counter % self._yolo_frame_interval == 0:
                try:
                    yolo_res = self._yolo.detect(bgr_frame)
                    self._last_yolo_result = yolo_res
                except Exception:
                    logger.exception("YOLO detect failed")
                    self._last_yolo_result = None
            if self._last_yolo_result is not None:
                result.yolo_phone_present = self._last_yolo_result.has_phone
                phones = self._last_yolo_result.phone_objects()
                result.yolo_phone_conf = max((o.confidence for o in phones), default=0.0)

        result.inference_ms = (time.time() - t0) * 1000
        return result

    # ------------------------------------------------------------------
    def _compute_gaze(self, lm, w, h, result: DetectionResult):
        left_cheek_x = lm[LEFT_CHEEK].x * w
        right_cheek_x = lm[RIGHT_CHEEK].x * w
        face_width = max(1.0, abs(right_cheek_x - left_cheek_x))

        lx_out = lm[LEFT_EYE_CORNERS[0]].x * w
        lx_in = lm[LEFT_EYE_CORNERS[1]].x * w
        ly_out = lm[LEFT_EYE_CORNERS[0]].y * h
        ly_in = lm[LEFT_EYE_CORNERS[1]].y * h
        l_iris_x = np.mean([lm[i].x * w for i in LEFT_IRIS])
        l_iris_y = np.mean([lm[i].y * h for i in LEFT_IRIS])

        rx_in = lm[RIGHT_EYE_CORNERS[0]].x * w
        rx_out = lm[RIGHT_EYE_CORNERS[1]].x * w
        ry_in = lm[RIGHT_EYE_CORNERS[0]].y * h
        ry_out = lm[RIGHT_EYE_CORNERS[1]].y * h
        r_iris_x = np.mean([lm[i].x * w for i in RIGHT_IRIS])
        r_iris_y = np.mean([lm[i].y * h for i in RIGHT_IRIS])

        l_mid_x = (lx_out + lx_in) / 2.0
        r_mid_x = (rx_out + rx_in) / 2.0
        l_width = max(1.0, abs(lx_out - lx_in))
        r_width = max(1.0, abs(rx_out - rx_in))
        h_offset = ((l_iris_x - l_mid_x) / l_width + (r_iris_x - r_mid_x) / r_width) / 2.0

        l_mid_y = (ly_out + ly_in) / 2.0
        r_mid_y = (ry_out + ry_in) / 2.0
        v_offset = ((l_iris_y - l_mid_y) / face_width +
                    (r_iris_y - r_mid_y) / face_width) / 2.0

        result.gaze_h = float(h_offset)
        result.gaze_v = float(v_offset)

        if abs(h_offset) > HORIZONTAL_OFFSET_THRESHOLD:
            result.gaze_direction = "away_right" if h_offset > 0 else "away_left"
        elif abs(v_offset) > VERTICAL_OFFSET_THRESHOLD:
            result.gaze_direction = "away_down" if v_offset > 0 else "away_up"
        else:
            result.gaze_direction = "center"

    # ------------------------------------------------------------------
    def _compute_head(self, lm, result: DetectionResult):
        nose_x = lm[NOSE_TIP].x
        nose_y = lm[NOSE_TIP].y
        left_cheek_x = lm[LEFT_CHEEK].x
        right_cheek_x = lm[RIGHT_CHEEK].x
        forehead_y = lm[FOREHEAD].y
        chin_y = lm[CHIN].y

        face_width = max(1e-6, abs(right_cheek_x - left_cheek_x))
        face_height = max(1e-6, abs(chin_y - forehead_y))

        face_center_x = (left_cheek_x + right_cheek_x) / 2.0
        yaw = (nose_x - face_center_x) / face_width

        face_center_y = (forehead_y + chin_y) / 2.0
        pitch = (nose_y - face_center_y) / face_height

        result.head_yaw = float(yaw)
        result.head_pitch = float(pitch)

        if abs(yaw) > YAW_THRESHOLD:
            result.head_direction = "right" if yaw > 0 else "left"
        elif abs(pitch) > PITCH_THRESHOLD:
            result.head_direction = "down" if pitch > 0 else "up"
        else:
            result.head_direction = "center"

    # ------------------------------------------------------------------
    @staticmethod
    def _overlap_ratio(a, b) -> float:
        ax, ay, aw, ah = a
        bx, by, bw, bh = b
        x1 = max(ax, bx); y1 = max(ay, by)
        x2 = min(ax + aw, bx + bw); y2 = min(ay + ah, by + bh)
        if x2 <= x1 or y2 <= y1:
            return 0.0
        inter = (x2 - x1) * (y2 - y1)
        smaller = min(aw * ah, bw * bh)
        if smaller <= 0:
            return 0.0
        return inter / float(smaller)

    # ------------------------------------------------------------------
    def close(self):
        for obj in (self._face_detector, self._face_mesh, self._hands):
            try:
                obj.close()
            except Exception:
                pass