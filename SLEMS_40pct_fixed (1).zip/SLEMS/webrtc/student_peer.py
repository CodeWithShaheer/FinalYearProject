"""
webrtc/student_peer.py
Student-side WebRTC peer.

Responsibilities:
    - Capture frames from the student's camera (OpenCV)
    - Expose an aiortc VideoStreamTrack
    - Handle SDP offer/answer + ICE exchange
    - Send local SDP/ICE to teacher via a callback
"""
import asyncio
import fractions
import logging
import time
from typing import Callable, Optional

import cv2
import numpy as np
from av import VideoFrame

from aiortc import (
    RTCPeerConnection,
    RTCSessionDescription,
    RTCIceCandidate,
    RTCConfiguration,
)
from aiortc.mediastreams import VideoStreamTrack

logger = logging.getLogger(__name__)


CAMERA_WIDTH = 640
CAMERA_HEIGHT = 480
CAMERA_FPS = 15
VIDEO_CLOCK_RATE = 90000


# ---------------------------------------------------------------------------
class CameraVideoTrack(VideoStreamTrack):
    """aiortc VideoStreamTrack fed by OpenCV webcam."""

    kind = "video"

    def __init__(self, camera_index=0, width=CAMERA_WIDTH,
                 height=CAMERA_HEIGHT, fps=CAMERA_FPS):
        super().__init__()
        self._camera_index = camera_index
        self._width = width
        self._height = height
        self._fps = max(1, fps)
        self._frame_interval = 1.0 / self._fps
        self._last_emit_time = 0.0
        self._cap = None
        self._camera_ok = False
        self._open_camera()

    def _open_camera(self):
        try:
            cap = cv2.VideoCapture(self._camera_index, cv2.CAP_DSHOW)
            if not cap.isOpened():
                cap.release()
                cap = cv2.VideoCapture(self._camera_index)
            if cap.isOpened():
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, self._width)
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self._height)
                cap.set(cv2.CAP_PROP_FPS, self._fps)
                self._cap = cap
                self._camera_ok = True
                logger.info("Camera %d opened (%dx%d @ %d fps)",
                            self._camera_index, self._width, self._height, self._fps)
                return
        except Exception:
            logger.exception("Camera open failed")
        self._cap = None
        self._camera_ok = False
        logger.warning("No camera available — sending placeholder frames.")

    async def recv(self) -> VideoFrame:
        now = time.time()
        delta = now - self._last_emit_time
        if delta < self._frame_interval:
            await asyncio.sleep(self._frame_interval - delta)
        self._last_emit_time = time.time()

        img = None
        if self._camera_ok and self._cap is not None:
            try:
                ok, frame = self._cap.read()
                if ok and frame is not None:
                    if frame.shape[1] != self._width or frame.shape[0] != self._height:
                        frame = cv2.resize(frame, (self._width, self._height))
                    img = frame
            except Exception:
                logger.exception("Camera read failed; using placeholder")
                img = None

        if img is None:
            img = self._make_placeholder()

        rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        vf = VideoFrame.from_ndarray(rgb, format="rgb24")
        vf.pts = int(self._last_emit_time * VIDEO_CLOCK_RATE)
        vf.time_base = fractions.Fraction(1, VIDEO_CLOCK_RATE)
        return vf

    def _make_placeholder(self) -> np.ndarray:
        img = np.zeros((self._height, self._width, 3), dtype=np.uint8)
        cv2.putText(img, "NO CAMERA", (30, self._height // 2),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.0, (200, 200, 200), 2, cv2.LINE_AA)
        return img

    def stop(self):
        if self._cap is not None:
            try:
                self._cap.release()
            except Exception:
                pass
            self._cap = None
        self._camera_ok = False
        logger.info("Camera released.")


# ---------------------------------------------------------------------------
class StudentPeer:
    def __init__(self, on_local_sdp: Callable[[dict], None],
                 on_local_ice: Callable[[dict], None],
                 camera_index: int = 0):
        self.on_local_sdp = on_local_sdp
        self.on_local_ice = on_local_ice

        config = RTCConfiguration(iceServers=[])
        self.pc = RTCPeerConnection(configuration=config)
        self.track = CameraVideoTrack(camera_index=camera_index)

        self._closed = False

        @self.pc.on("icecandidate")
        def _on_ice(candidate):
            if candidate is not None:
                try:
                    self.on_local_ice({
                        "candidate": candidate.candidate,
                        "sdpMid": candidate.sdpMid,
                        "sdpMLineIndex": candidate.sdpMLineIndex,
                    })
                except Exception:
                    logger.exception("on_local_ice callback failed")

        @self.pc.on("connectionstatechange")
        async def _on_state():
            logger.info("[StudentPeer] connection state: %s", self.pc.connectionState)

        @self.pc.on("iceconnectionstatechange")
        async def _on_ice_state():
            logger.info("[StudentPeer] ICE state: %s", self.pc.iceConnectionState)

    async def start(self):
        if self._closed:
            return
        self.pc.addTrack(self.track)
        logger.info("[StudentPeer] camera track added.")

    async def create_offer(self) -> dict:
        offer = await self.pc.createOffer()
        await self.pc.setLocalDescription(offer)
        logger.info("[StudentPeer] offer created.")
        return {
            "type": self.pc.localDescription.type,
            "sdp": self.pc.localDescription.sdp,
        }

    async def set_remote_answer(self, answer: dict):
        if self._closed:
            return
        desc = RTCSessionDescription(sdp=answer["sdp"], type=answer["type"])
        await self.pc.setRemoteDescription(desc)
        logger.info("[StudentPeer] remote answer set.")

    async def add_remote_ice(self, candidate: dict):
        if self._closed:
            return
        try:
            cand = RTCIceCandidate(
                candidate=candidate.get("candidate", ""),
                sdpMid=candidate.get("sdpMid"),
                sdpMLineIndex=candidate.get("sdpMLineIndex"),
            )
            await self.pc.addIceCandidate(cand)
        except Exception:
            logger.exception("[StudentPeer] add_remote_ice failed")

    # ------------------------------------------------------------------
    # FIXED close() — swallows CancelledError and any aioice cleanup noise
    # ------------------------------------------------------------------
    async def close(self):
        if self._closed:
            return
        self._closed = True

        # 1. Stop camera track
        try:
            self.track.stop()
        except Exception:
            pass

        # 2. Close peer connection — shield against CancelledError
        try:
            await asyncio.shield(self.pc.close())
        except asyncio.CancelledError:
            logger.debug("[StudentPeer] pc.close() raised CancelledError — ignored")
        except Exception:
            logger.exception("[StudentPeer] pc.close() failed")

        logger.info("[StudentPeer] closed.")