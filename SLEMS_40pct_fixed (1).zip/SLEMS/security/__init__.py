"""
security package
Password hashing, session tokens, message validation.
"""