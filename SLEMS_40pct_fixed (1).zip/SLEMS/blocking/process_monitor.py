"""
blocking/process_monitor.py
Watches running processes with psutil.

v3.0:
    - Uses new APP_PROFILES (parent + children explicit)
    - Tags each detected process as parent or child
    - Faster scan by filtering on name first
"""
import logging
import os
from dataclasses import dataclass
from typing import Dict, List, Set

try:
    import psutil
except ImportError:
    psutil = None

from blocking.whitelist import (
    is_whitelisted,
    get_app_profile,
)

logger = logging.getLogger(__name__)


@dataclass
class DetectedProcess:
    pid: int
    name: str
    exe: str = ""
    matched_app: str = ""
    is_parent: bool = False
    cmdline: str = ""
    started_at: float = 0.0          # process creation time (epoch seconds) - for kill latency


class ProcessMonitor:
    def __init__(self):
        if psutil is None:
            raise ImportError("psutil not installed. Run: pip install psutil")
        self._blocklist: Dict[str, Dict[str, Set[str]]] = {}
        self._own_pid = os.getpid()

    # ------------------------------------------------------------------
    def set_blocklist(self, friendly_names: List[str]):
        self._blocklist.clear()
        for name in friendly_names or []:
            name = (name or "").strip()
            if not name:
                continue
            profile = get_app_profile(name)
            self._blocklist[name] = {
                "parent": {e.lower() for e in profile["parent"]},
                "children": {e.lower() for e in profile["children"]},
            }
        logger.info("ProcessMonitor blocklist set: %s", list(self._blocklist.keys()))

    # ------------------------------------------------------------------
    def scan(self) -> List[DetectedProcess]:
        results: List[DetectedProcess] = []
        if not self._blocklist:
            return results

        try:
            # Only ask for pid+name for every process (cheap).  exe / cmdline are
            # expensive on Windows, so they are fetched ONLY for matches.
            for proc in psutil.process_iter(["pid", "name"]):
                try:
                    name = (proc.info.get("name") or "").lower().strip()
                    if not name:
                        continue
                    if proc.info.get("pid") == self._own_pid:
                        continue                      # never target SLEMS itself
                    if is_whitelisted(name):
                        continue

                    matched_app, is_parent = self._match(name)
                    if matched_app is None:
                        continue

                    exe, cmdline, started = "", "", 0.0
                    try:
                        started = proc.create_time()
                        exe = proc.exe() or ""
                        cmdline = " ".join(proc.cmdline() or [])[:200]
                    except (psutil.AccessDenied, psutil.NoSuchProcess, psutil.ZombieProcess):
                        pass

                    results.append(DetectedProcess(
                        pid=proc.info.get("pid", 0),
                        name=name,
                        exe=exe,
                        matched_app=matched_app,
                        is_parent=is_parent,
                        cmdline=cmdline,
                        started_at=started,
                    ))
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    continue
                except Exception:
                    continue
        except Exception:
            logger.exception("process scan failed")

        return results

    # ------------------------------------------------------------------
    def _match(self, proc_name: str):
        """Return (friendly_name, is_parent) or (None, False)."""
        name = proc_name.lower().strip()
        name_no_ext = name[:-4] if name.endswith(".exe") else name

        for friendly, profile in self._blocklist.items():
            for exe in profile["parent"]:
                exe_l = exe.lower().strip()
                exe_no_ext = exe_l[:-4] if exe_l.endswith(".exe") else exe_l
                if name == exe_l or name_no_ext == exe_no_ext:
                    return friendly, True

            for exe in profile["children"]:
                exe_l = exe.lower().strip()
                exe_no_ext = exe_l[:-4] if exe_l.endswith(".exe") else exe_l
                if name == exe_l or name_no_ext == exe_no_ext:
                    return friendly, False
        return None, False