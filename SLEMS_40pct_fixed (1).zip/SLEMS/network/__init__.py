"""
network package
TCP-based communication layer between teacher (server) and students (clients).

Design:
  - JSON messages, newline-delimited (\\n)
  - Teacher runs asyncio TCP server on port 5555
  - Each student connects independently
  - Every message validated by security/message_validation.py
"""