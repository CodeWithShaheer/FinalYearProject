"""
gui.student package
Student dashboard pages.
"""