"""
gui/teacher/network_bridge.py
Runs TeacherServer + TeacherPeerManager in a background asyncio loop
inside a QThread; re-emits events as Qt signals.

v3.1 — Performance:
    - Throttles frame_ready emissions (max 30 fps per token)
"""
import asyncio
import logging
import time
from typing import Optional

from PyQt5.QtCore import QThread, pyqtSignal
from PyQt5.QtGui import QImage

from network.teacher_server import (
    TeacherServer,
    EVT_STUDENT_CONNECTED,
    EVT_STUDENT_DISCONNECTED,
    EVT_VIOLATION,
    EVT_SUBMISSION_META,
    EVT_SUBMISSION_COMPLETE,
    EVT_BLOCK_EVENT,
    EVT_BLOCKING_PAUSED,
    EVT_STUDENT_HEARTBEAT,
    EVT_WEBRTC_OFFER,
    EVT_WEBRTC_ICE,
    EVT_ERROR,
)
from network import protocol as P
from network.discovery import TeacherAnnouncer
from config.settings import ENABLE_P2P_STREAMING

logger = logging.getLogger(__name__)


# Max frames per second forwarded to GUI per student
MAX_FPS_TO_GUI = 30.0


class NetworkBridge(QThread):
    server_started = pyqtSignal()
    server_error = pyqtSignal(str)

    student_connected = pyqtSignal(dict)
    student_disconnected = pyqtSignal(dict)
    violation_received = pyqtSignal(dict)
    submission_meta_received = pyqtSignal(dict)
    submission_received = pyqtSignal(dict)
    block_event_received = pyqtSignal(dict)       # a kill / block on a student PC
    blocking_paused_changed = pyqtSignal(dict)    # teacher override on / off
    heartbeat_received = pyqtSignal(str)          # token (for 'last seen')

    peer_connected = pyqtSignal(str)
    peer_disconnected = pyqtSignal(str)
    frame_ready = pyqtSignal(str, QImage)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._server: Optional[TeacherServer] = None
        self._announcer: Optional[TeacherAnnouncer] = None
        self._peer_manager: Optional[object] = None
        self._stop_flag = False

        # Frame throttle: token → last_emit_time
        self._last_frame_ts = {}
        self._min_frame_interval = 1.0 / MAX_FPS_TO_GUI

    # ==================================================================
    def run(self):
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._start_all())
            if not self._stop_flag:
                self._loop.run_forever()
        except Exception as e:
            logger.exception("NetworkBridge crashed")
            self.server_error.emit(f"Network error: {e}")
        finally:
            try:
                self._loop.run_until_complete(self._shutdown_all())
            except Exception:
                pass
            self._loop.close()

    async def _start_all(self):
        self._server = TeacherServer()
        self._server.on_event(self._on_event)
        await self._server.start()

        if ENABLE_P2P_STREAMING:
            # imported lazily so the app runs without aiortc/av installed
            from webrtc.peer_manager import TeacherPeerManager
            self._peer_manager = TeacherPeerManager(
                on_local_sdp=self._on_local_sdp,
                on_local_ice=self._on_local_ice,
                on_track_frame=self._on_track_frame,
            )
        else:
            self._peer_manager = None
            logger.info("P2P streaming disabled (ENABLE_P2P_STREAMING=0).")

        try:
            self._announcer = TeacherAnnouncer()
            await self._announcer.start()
        except Exception as e:
            logger.warning("Announcer failed: %s", e)

        self.server_started.emit()
        logger.info("NetworkBridge: server + announcer running (streaming=%s).", bool(self._peer_manager))

    async def _shutdown_all(self):
        if self._peer_manager:
            try: await self._peer_manager.close_all()
            except Exception: pass
        if self._announcer:
            try: await self._announcer.stop()
            except Exception: pass
        if self._server:
            try: await self._server.stop()
            except Exception: pass

    # ==================================================================
    def _on_event(self, event_type: str, payload: dict):
        try:
            if event_type == EVT_STUDENT_CONNECTED:
                self.student_connected.emit(payload)
            elif event_type == EVT_STUDENT_DISCONNECTED:
                token = payload.get("token")
                self.student_disconnected.emit(payload)
                if token and self._loop and self._peer_manager:
                    asyncio.run_coroutine_threadsafe(
                        self._peer_manager.remove(token), self._loop
                    )
                    self.peer_disconnected.emit(token)
                    self._last_frame_ts.pop(token, None)
            elif event_type == EVT_VIOLATION:
                self.violation_received.emit(payload)
            elif event_type == EVT_SUBMISSION_META:
                self.submission_meta_received.emit(payload)
            elif event_type == EVT_SUBMISSION_COMPLETE:
                self.submission_received.emit(payload)
            elif event_type == EVT_BLOCK_EVENT:
                self.block_event_received.emit(payload)
            elif event_type == EVT_BLOCKING_PAUSED:
                self.blocking_paused_changed.emit(payload)
            elif event_type == EVT_STUDENT_HEARTBEAT:
                self.heartbeat_received.emit(payload.get("token", ""))
            elif event_type == EVT_WEBRTC_OFFER:
                self._handle_webrtc_offer_async(payload)
            elif event_type == EVT_WEBRTC_ICE:
                self._handle_webrtc_ice_async(payload)
            elif event_type == EVT_ERROR:
                self.server_error.emit(payload.get("reason", "unknown"))
        except Exception:
            logger.exception("Failed to handle event %s", event_type)

    def _handle_webrtc_offer_async(self, payload: dict):
        token = payload.get("token")
        sdp = payload.get("sdp")
        if not token or not sdp or not self._loop or not self._peer_manager:
            return

        async def _run():
            answer = await self._peer_manager.handle_offer(token, sdp)
            if answer is None:
                return
            frame = P.encode(P.MSG_WEBRTC_ANSWER, sdp=answer)
            ok = await self._server.send_to_token(token, frame)
            if ok:
                self.peer_connected.emit(token)

        asyncio.run_coroutine_threadsafe(_run(), self._loop)

    def _handle_webrtc_ice_async(self, payload: dict):
        token = payload.get("token")
        candidate = payload.get("candidate")
        if not token or not candidate or not self._loop or not self._peer_manager:
            return
        asyncio.run_coroutine_threadsafe(
            self._peer_manager.handle_ice(token, candidate), self._loop
        )

    # ==================================================================
    def _on_local_sdp(self, token, sdp):
        pass

    def _on_local_ice(self, token, candidate):
        if not self._loop or not self._server:
            return
        frame = P.encode(P.MSG_WEBRTC_ICE, candidate=candidate)

        async def _run():
            await self._server.send_to_token(token, frame)

        asyncio.run_coroutine_threadsafe(_run(), self._loop)

    def _on_track_frame(self, token: str, av_frame):
        """
        Convert and emit, but throttle to MAX_FPS_TO_GUI per student.
        """
        now = time.time()
        last = self._last_frame_ts.get(token, 0.0)
        if (now - last) < self._min_frame_interval:
            return
        self._last_frame_ts[token] = now
        try:
            from webrtc.frame_converter import av_frame_to_qimage
            qimg = av_frame_to_qimage(av_frame)
            if qimg is not None:
                self.frame_ready.emit(token, qimg)
        except Exception:
            logger.exception("frame conversion failed for %s", token[:8])

    # ==================================================================
    def broadcast_session_end(self, session_id=None):
        """Tell every student (or one session's students) that the exam is over."""
        if not self._loop or not self._server:
            return
        asyncio.run_coroutine_threadsafe(
            self._server.announce_session_end(session_id), self._loop)

    def set_blocking_paused(self, token: str, paused: bool, reason: str = "",
                            actor_user_id=None):
        """Emergency override for ONE student (S4)."""
        if not self._loop or not self._server:
            return
        asyncio.run_coroutine_threadsafe(
            self._server.set_blocking_paused(token, paused, reason, actor_user_id), self._loop)

    def send_to_token(self, token, frame):
        if not self._loop or not self._server:
            return
        asyncio.run_coroutine_threadsafe(
            self._server.send_to_token(token, frame), self._loop
        )

    def get_manager(self):
        return self._server.manager if self._server else None

    def get_peer_manager(self):
        return self._peer_manager

    def stop(self):
        if not self._loop:
            return
        self._stop_flag = True
        self._loop.call_soon_threadsafe(self._loop.stop)
        self.wait(3000)