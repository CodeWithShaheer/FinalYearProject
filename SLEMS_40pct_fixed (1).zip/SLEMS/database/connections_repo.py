"""
database/connections_repo.py
CRUD for the `connections` table.

Tracks active student network connections.
Used by network/teacher_server.py to record who is connected.
"""
import logging
from typing import List, Optional

from database.connection import db_cursor
from database.models import Connection

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# CREATE / UPDATE
# ---------------------------------------------------------------------------
def register_connection(
    student_id: int,
    session_id: int,
    ip_address: str,
    session_token: str,
) -> tuple:
    """
    Insert a new connection row.
    Returns (ok: bool, connection: Optional[Connection], message: str).
    """
    try:
        with db_cursor(dict_cursor=True) as cur:
            cur.execute(
                """
                INSERT INTO connections
                    (student_id, session_id, ip_address, session_token,
                     status, connected_at, last_heartbeat)
                VALUES (%s, %s, %s, %s, 'connected', NOW(), NOW())
                RETURNING *;
                """,
                (student_id, session_id, ip_address, session_token),
            )
            row = cur.fetchone()
        return True, Connection.from_row(row), "Connection registered."
    except Exception as e:
        logger.exception("Failed to register connection")
        return False, None, f"Database error: {e}"


def update_heartbeat(session_token: str) -> bool:
    """Update last_heartbeat for a token."""
    try:
        with db_cursor() as cur:
            cur.execute(
                "UPDATE connections SET last_heartbeat = NOW() WHERE session_token = %s;",
                (session_token,),
            )
            return cur.rowcount > 0
    except Exception:
        logger.exception("Failed to update heartbeat")
        return False


def update_status(session_token: str, status: str) -> bool:
    """Update connection status: connected / reconnecting / offline."""
    try:
        with db_cursor() as cur:
            cur.execute(
                "UPDATE connections SET status = %s, last_heartbeat = NOW() "
                "WHERE session_token = %s;",
                (status, session_token),
            )
            return cur.rowcount > 0
    except Exception:
        logger.exception("Failed to update connection status")
        return False


def mark_disconnected(session_token: str) -> bool:
    """Mark connection as offline on graceful disconnect."""
    try:
        with db_cursor() as cur:
            cur.execute(
                "UPDATE connections SET status = 'offline' WHERE session_token = %s;",
                (session_token,),
            )
            return cur.rowcount > 0
    except Exception:
        logger.exception("Failed to mark disconnected")
        return False


# ---------------------------------------------------------------------------
# READ
# ---------------------------------------------------------------------------
def get_connection_by_token(session_token: str) -> Optional[Connection]:
    with db_cursor(dict_cursor=True) as cur:
        cur.execute(
            "SELECT * FROM connections WHERE session_token = %s LIMIT 1;",
            (session_token,),
        )
        row = cur.fetchone()
    return Connection.from_row(row) if row else None


def get_connections_by_session(session_id: int) -> List[Connection]:
    with db_cursor(dict_cursor=True) as cur:
        cur.execute(
            "SELECT * FROM connections WHERE session_id = %s "
            "ORDER BY connected_at DESC;",
            (session_id,),
        )
        rows = cur.fetchall()
    return [Connection.from_row(r) for r in rows]


def get_connections_by_student(session_id: int, student_id: int) -> List[Connection]:
    with db_cursor(dict_cursor=True) as cur:
        cur.execute(
            "SELECT * FROM connections WHERE session_id = %s AND student_id = %s "
            "ORDER BY connected_at DESC;",
            (session_id, student_id),
        )
        rows = cur.fetchall()
    return [Connection.from_row(r) for r in rows]


def count_active_connections(session_id: Optional[int] = None) -> int:
    with db_cursor() as cur:
        if session_id:
            cur.execute(
                "SELECT COUNT(*) FROM connections "
                "WHERE session_id = %s AND status = 'connected';",
                (session_id,),
            )
        else:
            cur.execute(
                "SELECT COUNT(*) FROM connections WHERE status = 'connected';"
            )
        return cur.fetchone()[0]


# ---------------------------------------------------------------------------
# STALE CLEANUP
# ---------------------------------------------------------------------------
def mark_stale_connections_offline(timeout_seconds: int = 60) -> int:
    """
    Mark connections as 'offline' if last_heartbeat older than timeout.
    Returns count of affected rows.
    """
    try:
        with db_cursor() as cur:
            cur.execute(
                """
                UPDATE connections
                SET status = 'offline'
                WHERE status != 'offline'
                  AND last_heartbeat < NOW() - INTERVAL '%s seconds';
                """,
                (timeout_seconds,),
            )
            return cur.rowcount
    except Exception:
        logger.exception("Failed to clean stale connections")
        return 0


# ---------------------------------------------------------------------------
# DELETE
# ---------------------------------------------------------------------------
def delete_connection(session_token: str) -> bool:
    try:
        with db_cursor() as cur:
            cur.execute(
                "DELETE FROM connections WHERE session_token = %s;",
                (session_token,),
            )
            return cur.rowcount > 0
    except Exception:
        logger.exception("Failed to delete connection")
        return False