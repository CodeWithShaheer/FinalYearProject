import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))  # run from anywhere
# test_webrtc_local.py  (temporary — delete after verifying)
import asyncio
import logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")

from webrtc.student_peer import StudentPeer
from webrtc.peer_manager import TeacherPeerManager


async def main():
    print("\n=== TEST 1: Camera track sample frame ===")
    from webrtc.student_peer import CameraVideoTrack
    track = CameraVideoTrack()
    frame = await track.recv()
    print(f"Got frame: {frame.width}x{frame.height} format={frame.format.name}")
    track.stop()

    print("\n=== TEST 2: Full offer/answer handshake (in-process) ===")
    local_offers = []
    student_ice = []

    def on_student_sdp(sdp): local_offers.append(sdp)
    def on_student_ice(c): student_ice.append(c)

    student = StudentPeer(on_local_sdp=on_student_sdp, on_local_ice=on_student_ice)
    await student.start()

    offer = await student.create_offer()
    print(f"Offer SDP length: {len(offer['sdp'])} chars, type={offer['type']}")

    teacher_answers = []
    teacher_ice = []
    frames_received = []

    def on_teacher_sdp(token, sdp): teacher_answers.append((token, sdp))
    def on_teacher_ice(token, c): teacher_ice.append((token, c))
    def on_teacher_frame(token, frame): frames_received.append((token, frame))

    manager = TeacherPeerManager(
        on_local_sdp=on_teacher_sdp,
        on_local_ice=on_teacher_ice,
        on_track_frame=on_teacher_frame,
    )

    answer = await manager.handle_offer("test_token", offer)
    assert answer is not None, "No answer produced"
    print(f"Answer SDP length: {len(answer['sdp'])} chars")

    await student.set_remote_answer(answer)

    # Wait for connection + a few frames
    print("\nWaiting 3s for frames…")
    await asyncio.sleep(3.0)

    print(f"\nFrames received by teacher: {len(frames_received)}")
    if frames_received:
        _token, frame = frames_received[-1]
        print(f"Last frame: {frame.width}x{frame.height} pts={frame.pts}")

    print(f"\nTeacher ICE candidates: {len(teacher_ice)}")
    print(f"Student ICE candidates: {len(student_ice)}")

    # Cleanup
    await student.close()
    await manager.close_all()

    if frames_received:
        print("\n=== SUCCESS: Video flowed from student to teacher ===")
    else:
        print("\n=== WARNING: No frames received (camera may be unavailable) ===")


if __name__ == "__main__":
    asyncio.run(main())