"""
ai/camera.py
CameraCapture wrapper — delegates to SharedCamera.

Existing code that uses CameraCapture continues to work.
The actual camera is opened ONCE via SharedCamera and shared
with the WebRTC track.
"""
import logging
from typing import Optional

import numpy as np

from ai.shared_camera import SharedCamera

logger = logging.getLogger(__name__)


class CameraCapture:
    """
    Backward-compatible wrapper for SharedCamera.

    Usage (unchanged):
        cam = CameraCapture(index=0, width=640, height=480)
        cam.start()
        frame = cam.read()
        cam.stop()   # no-op now
    """

    def __init__(self, index: int = 0, width: int = 640,
                 height: int = 480, fps: int = 15):
        self.index = index
        self.width = width
        self.height = height
        self.fps = fps
        self._camera = SharedCamera.get()

    def start(self) -> bool:
        return self._camera.start()

    def read(self) -> Optional[np.ndarray]:
        return self._camera.read()

    @property
    def frames_read(self) -> int:
        return 0

    def stop(self):
        # SharedCamera is not stopped here — it stays open for WebRTC.
        pass