import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))  # run from anywhere
# test_fake_student.py  (temporary)
import asyncio, json, sys

async def main():
    session_code = sys.argv[1] if len(sys.argv) > 1 else "1"
    roll_no = sys.argv[2] if len(sys.argv) > 2 else "21F-1234"

    reader, writer = await asyncio.open_connection("127.0.0.1", 5555)
    print(f"Connected as {roll_no} to session {session_code}")

    def send(obj):
        writer.write((json.dumps(obj) + "\n").encode())

    async def recv():
        line = await reader.readuntil(b"\n")
        return json.loads(line.decode())

    # 1. HELLO
    send({"type": "HELLO", "roll_no": roll_no, "session_code": session_code})
    await writer.drain()

    # 2. Receive WELCOME
    msg = await recv()
    print("<<", msg)
    if msg["type"] != "WELCOME":
        print("FAILED: expected WELCOME")
        return
    token = msg["token"]

    # 3. JOIN
    send({"type": "JOIN", "token": token})
    await writer.drain()

    # 4. Receive SESSION_CONFIG
    msg = await recv()
    print("<<", msg)

    # 5. Send a few heartbeats
    for i in range(3):
        await asyncio.sleep(2)
        send({"type": "HEARTBEAT", "token": token})
        await writer.drain()
        print(">> HEARTBEAT sent")

    # 6. Send a test violation
    send({"type": "VIOLATION", "token": token, "vtype": "behavioral",
          "desc": "Looking away", "severity": "high"})
    await writer.drain()
    msg = await recv()
    print("<<", msg)

    # 7. Disconnect
    send({"type": "DISCONNECT", "token": token})
    await writer.drain()
    print(">> DISCONNECT sent")
    writer.close()
    try:
        await writer.wait_closed()
    except Exception:
        pass

asyncio.run(main())