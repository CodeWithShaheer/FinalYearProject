# Central logging.
"""
utils/logger.py
Central logging configuration.

Usage (call once at app startup):
    from utils.logger import setup_logging
    setup_logging()
"""
import logging
import sys
from pathlib import Path

from config.settings import LOGS_DIR, LOG_LEVEL, APP_ENV


_LOG_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
_DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

_configured = False


def setup_logging(log_filename: str = "slems.log"):
    """
    Configure root logger with console + file handlers.
    Safe to call multiple times — only configures once.
    """
    global _configured
    if _configured:
        return

    level = getattr(logging, LOG_LEVEL.upper(), logging.INFO)
    root = logging.getLogger()
    root.setLevel(level)

    # Clear any pre-existing handlers
    for h in list(root.handlers):
        root.removeHandler(h)

    formatter = logging.Formatter(_LOG_FORMAT, datefmt=_DATE_FORMAT)

    # Console handler
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(formatter)
    console.setLevel(level)
    root.addHandler(console)

    # File handler
    try:
        LOGS_DIR.mkdir(parents=True, exist_ok=True)
        log_path = Path(LOGS_DIR) / log_filename
        file_h = logging.FileHandler(log_path, encoding="utf-8")
        file_h.setFormatter(formatter)
        file_h.setLevel(level)
        root.addHandler(file_h)
    except Exception as e:
        # Don't crash if log file can't be created
        print(f"[logger] Could not create file handler: {e}", file=sys.stderr)

    # Quiet noisy third-party loggers
    logging.getLogger("PIL").setLevel(logging.WARNING)
    logging.getLogger("matplotlib").setLevel(logging.WARNING)

    _configured = True


def get_logger(name: str) -> logging.Logger:
    """Convenience wrapper."""
    return logging.getLogger(name)