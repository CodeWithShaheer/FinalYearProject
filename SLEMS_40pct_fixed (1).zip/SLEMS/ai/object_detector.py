# Phone/object detection.
"""
ai/object_detector.py
Lightweight object detector for "phone in hand / near face" detection.

We do NOT use YOLO here — that would add ~200 MB of model weights and
push CPU usage too high on a student laptop that's also streaming video.

Instead, we use MediaPipe Hands. Heuristic:
    - If a hand is detected and its bounding box overlaps the
      lower half of the face box (as detected by FaceDetector),
      we flag "possible phone / object near face".

This is not perfect, but combined with the rule engine (sustained
over N seconds), it's a reasonable signal for a lab exam context.
The detector is deliberately conservative — no false positives from
just touching your face (must overlap for several seconds).

If you later want stronger phone detection, replace this module
with a YOLOv8n-based implementation.
"""
import logging
from dataclasses import dataclass
from typing import List, Optional, Tuple

import cv2
import numpy as np

try:
    import mediapipe as mp
except ImportError:
    mp = None

logger = logging.getLogger(__name__)


@dataclass
class ObjectInfo:
    hand_count: int = 0
    phone_suspected: bool = False
    hand_boxes: List[Tuple[int, int, int, int]] = None

    def __post_init__(self):
        if self.hand_boxes is None:
            self.hand_boxes = []


class ObjectDetector:
    """MediaPipe Hands + heuristic for phone-near-face detection."""

    def __init__(self, max_num_hands: int = 2,
                 min_detection_confidence: float = 0.5,
                 min_tracking_confidence: float = 0.5):
        if mp is None:
            raise ImportError(
                "mediapipe not installed. Run: pip install mediapipe"
            )
        self._mp_hands = mp.solutions.hands
        self._hands = self._mp_hands.Hands(
            max_num_hands=max_num_hands,
            min_detection_confidence=min_detection_confidence,
            min_tracking_confidence=min_tracking_confidence,
        )

    # ------------------------------------------------------------------
    def detect(self, bgr_frame: np.ndarray,
               face_box: Optional[Tuple[int, int, int, int]] = None) -> ObjectInfo:
        if bgr_frame is None:
            return ObjectInfo()

        h, w = bgr_frame.shape[:2]
        rgb = cv2.cvtColor(bgr_frame, cv2.COLOR_BGR2RGB)
        try:
            result = self._hands.process(rgb)
        except Exception:
            logger.exception("ObjectDetector.process failed")
            return ObjectInfo()

        if not result.multi_hand_landmarks:
            return ObjectInfo(hand_count=0)

        hand_boxes: List[Tuple[int, int, int, int]] = []
        for hl in result.multi_hand_landmarks:
            xs = [p.x * w for p in hl.landmark]
            ys = [p.y * h for p in hl.landmark]
            x_min, x_max = int(min(xs)), int(max(xs))
            y_min, y_max = int(min(ys)), int(max(ys))
            hand_boxes.append((x_min, y_min, x_max - x_min, y_max - y_min))

        phone_suspected = False
        if face_box is not None and hand_boxes:
            fx, fy, fw, fh = face_box
            # Lower half of face (chin area)
            lower_face = (fx, fy + fh // 2, fw, fh // 2)
            for hb in hand_boxes:
                if self._overlap_ratio(hb, lower_face) > 0.25:
                    phone_suspected = True
                    break

        return ObjectInfo(
            hand_count=len(hand_boxes),
            phone_suspected=phone_suspected,
            hand_boxes=hand_boxes,
        )

    # ------------------------------------------------------------------
    @staticmethod
    def _overlap_ratio(a: Tuple[int, int, int, int],
                       b: Tuple[int, int, int, int]) -> float:
        ax, ay, aw, ah = a
        bx, by, bw, bh = b
        x1 = max(ax, bx)
        y1 = max(ay, by)
        x2 = min(ax + aw, bx + bw)
        y2 = min(ay + ah, by + bh)
        if x2 <= x1 or y2 <= y1:
            return 0.0
        inter = (x2 - x1) * (y2 - y1)
        smaller = min(aw * ah, bw * bh)
        if smaller <= 0:
            return 0.0
        return inter / float(smaller)

    # ------------------------------------------------------------------
    def close(self):
        try:
            self._hands.close()
        except Exception:
            pass