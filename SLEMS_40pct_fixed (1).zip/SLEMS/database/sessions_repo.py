"""
database/sessions_repo.py
CRUD operations for the `sessions` table.

Handles exam session creation, retrieval, ending, and deletion.
Supports new columns: exam_title, exam_paper_size, security_options.
"""
import json
import secrets
import logging
from typing import List, Optional

from database.connection import db_cursor
from database.models import Session
from config.settings import DEFAULT_SECURITY_OPTIONS

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# CREATE
# ---------------------------------------------------------------------------
def _new_join_code(cur) -> str:
    """Random 6-digit code that no *active* session is using."""
    for _ in range(30):
        code = f"{secrets.randbelow(900000) + 100000}"
        cur.execute("SELECT 1 FROM sessions WHERE join_code = %s AND status = 'active';", (code,))
        if cur.fetchone() is None:
            return code
    raise RuntimeError("could not generate a unique join code")


def create_session(
    course_name: str,
    exam_title: str,
    duration_minutes: int,
    exam_paper_path: str = "",
    exam_paper_size: int = 0,
    blocked_apps: Optional[List[str]] = None,
    blocked_domains: Optional[List[str]] = None,
    security_options: Optional[dict] = None,
) -> tuple:
    """
    Create a new active session.
    Returns (ok: bool, session: Optional[Session], message: str).
    """
    course_name = (course_name or "").strip()
    exam_title = (exam_title or "").strip()
    blocked_apps = blocked_apps or []
    blocked_domains = blocked_domains or []
    security_options = security_options or dict(DEFAULT_SECURITY_OPTIONS)

    if not course_name:
        return False, None, "Course name is required."
    if duration_minutes <= 0:
        return False, None, "Duration must be greater than 0."

    apps_csv = ", ".join(blocked_apps)
    domains_csv = ", ".join(blocked_domains)
    sec_json = json.dumps(security_options)

    try:
        with db_cursor(dict_cursor=True) as cur:
            cur.execute(
                """
                INSERT INTO sessions (
                    course_name, exam_title, duration,
                    exam_paper, exam_paper_size,
                    blocked_apps, blocked_domains, security_options,
                    status, join_code
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'active', %s)
                RETURNING *;
                """,
                (
                    course_name, exam_title, duration_minutes,
                    exam_paper_path, exam_paper_size,
                    apps_csv, domains_csv, sec_json,
                    _new_join_code(cur),
                ),
            )
            row = cur.fetchone()
        session = Session.from_row(row)
        logger.info("Session created: id=%s course=%s", session.id, session.course_name)
        return True, session, f"Session '{session.course_name}' started."
    except Exception as e:
        logger.exception("Failed to create session")
        return False, None, f"Database error: {e}"


# ---------------------------------------------------------------------------
# READ
# ---------------------------------------------------------------------------
def get_active_session() -> Optional[Session]:
    """Return the currently active session, or None."""
    with db_cursor(dict_cursor=True) as cur:
        cur.execute(
            "SELECT * FROM sessions WHERE status = 'active' "
            "ORDER BY created_at DESC LIMIT 1;"
        )
        row = cur.fetchone()
    return Session.from_row(row) if row else None


def get_session_by_id(session_id: int) -> Optional[Session]:
    with db_cursor(dict_cursor=True) as cur:
        cur.execute("SELECT * FROM sessions WHERE id = %s;", (session_id,))
        row = cur.fetchone()
    return Session.from_row(row) if row else None


def get_all_sessions(limit: int = 100) -> List[Session]:
    """Return all sessions, newest first."""
    with db_cursor(dict_cursor=True) as cur:
        cur.execute(
            "SELECT * FROM sessions ORDER BY created_at DESC LIMIT %s;",
            (limit,),
        )
        rows = cur.fetchall()
    return [Session.from_row(r) for r in rows]


def get_sessions_with_student_count(limit: int = 100) -> List[Session]:
    """
    Return all sessions with live student count (JOIN).
    Used by Session History table.
    """
    with db_cursor(dict_cursor=True) as cur:
        cur.execute(
            """
            SELECT s.*,
                   COALESCE(COUNT(st.id), 0) AS student_count
            FROM sessions s
            LEFT JOIN students st ON st.session_id = s.id
            GROUP BY s.id
            ORDER BY s.created_at DESC
            LIMIT %s;
            """,
            (limit,),
        )
        rows = cur.fetchall()

    sessions = []
    for r in rows:
        s = Session.from_row(r)
        s.student_count = r.get("student_count", 0)
        sessions.append(s)
    return sessions


# ---------------------------------------------------------------------------
# UPDATE
# ---------------------------------------------------------------------------
def get_session_by_join_code(code: str) -> Optional[Session]:
    """Active session with this 6-digit join code (None if wrong / ended)."""
    code = (code or "").strip()
    if not (code.isdigit() and len(code) == 6):
        return None
    with db_cursor(dict_cursor=True) as cur:
        cur.execute("SELECT * FROM sessions WHERE join_code = %s AND status = 'active';", (code,))
        row = cur.fetchone()
    return Session.from_row(row) if row else None


def end_session(session_id: int) -> tuple:
    """Mark session as ended and set ended_at."""
    try:
        with db_cursor() as cur:
            cur.execute(
                "UPDATE sessions SET status = 'ended', ended_at = NOW() "
                "WHERE id = %s AND status = 'active';",
                (session_id,),
            )
            updated = cur.rowcount
        if updated:
            logger.info("Session ended: id=%s", session_id)
            return True, "Session ended."
        return False, "Session not found or already ended."
    except Exception as e:
        logger.exception("Failed to end session")
        return False, f"Database error: {e}"


# ---------------------------------------------------------------------------
# DELETE
# ---------------------------------------------------------------------------
def delete_session(session_id: int) -> tuple:
    """Delete a session (and cascade students/submissions/violations)."""
    try:
        with db_cursor() as cur:
            cur.execute("DELETE FROM sessions WHERE id = %s;", (session_id,))
            deleted = cur.rowcount
        if deleted:
            return True, "Session deleted."
        return False, "Session not found."
    except Exception as e:
        logger.exception("Failed to delete session")
        return False, f"Database error: {e}"


# ---------------------------------------------------------------------------
# STATS
# ---------------------------------------------------------------------------
def count_sessions() -> int:
    with db_cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM sessions;")
        return cur.fetchone()[0]


def count_active_sessions() -> int:
    with db_cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM sessions WHERE status = 'active';")
        return cur.fetchone()[0]