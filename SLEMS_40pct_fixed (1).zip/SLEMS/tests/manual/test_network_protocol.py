import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))  # run from anywhere
# test_network_protocol.py
import logging
logging.basicConfig(level=logging.INFO)

from network import protocol as P
from security import session_security as SS
from security import message_validation as MV

print("\n=== 1. Encode / Decode ===")
raw = P.encode(P.MSG_HEARTBEAT, token="abc123")
print(f"Encoded: {raw}")
decoded = P.decode_line(raw)
print(f"Decoded: {decoded}")
assert decoded["type"] == P.MSG_HEARTBEAT
assert decoded["token"] == "abc123"

print("\n=== 2. Welcome builder ===")
raw = P.welcome(token="tok_xyz", session_id=5, duration=90,
                student_db_id=42, course_name="OS", exam_title="Final")
print(P.decode_line(raw))

print("\n=== 3. Session config builder ===")
raw = P.session_config(
    blocked_apps=["ChatGPT", "WhatsApp"],
    blocked_domains=["chatgpt.com"],
    security_options={"monitor_student_screens": True},
)
print(P.decode_line(raw))

print("\n=== 4. Session token issue + validate ===")
token = SS.issue_token(session_id=5, student_id="FSD-FL-201",
                       student_db_id=42, ip="192.168.1.10", roll_no="21F-1234")
print(f"Issued token: {token[:16]}...")
meta = SS.validate_token(token)
print(f"Meta: {meta}")
assert meta and meta["session_id"] == 5

print(f"Active token count: {SS.active_token_count()}")

print("\n=== 5. Validation — HELLO ===")
msg = P.decode_line(P.encode(P.MSG_HELLO, roll_no="21F-1234", session_code="5"))
meta, err = MV.validate_message(msg)
print(f"HELLO -> meta={meta}, err={err}")
assert err is None

print("\n=== 6. Validation — HEARTBEAT with valid token ===")
msg = P.decode_line(P.encode(P.MSG_HEARTBEAT, token=token))
meta, err = MV.validate_message(msg)
print(f"HEARTBEAT -> meta={meta is not None}, err={err}")
assert err is None and meta is not None

print("\n=== 7. Validation — HEARTBEAT with bad token ===")
msg = P.decode_line(P.encode(P.MSG_HEARTBEAT, token="wrong"))
meta, err = MV.validate_message(msg)
print(f"Bad token -> meta={meta}, err={err}")
assert err is not None

print("\n=== 8. Validation — unknown message type ===")
msg = {"type": "NONSENSE"}
meta, err = MV.validate_message(msg)
print(f"Unknown -> err={err}")
assert err is not None

print("\n=== 9. Validation — missing field ===")
msg = {"type": P.MSG_HELLO}     # missing roll_no + session_code
meta, err = MV.validate_message(msg)
print(f"Missing fields -> err={err}")
assert err is not None

print("\n=== 10. Validation — VIOLATION ===")
msg = P.decode_line(P.encode(P.MSG_VIOLATION, token=token,
                             vtype="behavioral", desc="Looking away"))
meta, err = MV.validate_message(msg)
print(f"VIOLATION -> meta set={meta is not None}, err={err}")
assert err is None

print("\n=== 11. Unregister token ===")
SS.unregister_token(token)
meta = SS.validate_token(token)
print(f"After unregister, validate returns: {meta}")
assert meta is None

print("\n=== 12. Large message rejection ===")
try:
    huge = "x" * (3 * 1024 * 1024)
    P.encode(P.MSG_HEARTBEAT, token=huge)
    print("ERROR: Should have raised")
except P.ProtocolError as e:
    print(f"Correctly rejected: {e}")

print("\n=== ALL TESTS PASSED ===")