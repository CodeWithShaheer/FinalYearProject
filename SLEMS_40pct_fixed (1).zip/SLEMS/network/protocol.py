"""
network/protocol.py
Message types + framing + JSON helpers.

v3.0 — Submission upload support:
    STUDENT → TEACHER:
        SUBMISSION_META     announce upload
        SUBMISSION_CHUNK    one base64 chunk
        SUBMISSION_COMPLETE finalize
    TEACHER → STUDENT:
        SUBMISSION_ACK_META     accept + assign upload_id
        SUBMISSION_ACK_CHUNK    chunk received
        SUBMISSION_ACK_COMPLETE save confirmed
"""
import json
import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Student → Teacher
# ---------------------------------------------------------------------------
MSG_HELLO              = "HELLO"
MSG_JOIN               = "JOIN"
MSG_HEARTBEAT          = "HEARTBEAT"
MSG_VIOLATION          = "VIOLATION"
MSG_SUBMISSION_META    = "SUBMISSION_META"
MSG_SUBMISSION_CHUNK   = "SUBMISSION_CHUNK"
MSG_SUBMISSION_COMPLETE = "SUBMISSION_COMPLETE"
MSG_WEBRTC_OFFER       = "WEBRTC_OFFER"
MSG_WEBRTC_ICE         = "WEBRTC_ICE"
MSG_DISCONNECT         = "DISCONNECT"
MSG_BLOCK_EVENT        = "BLOCK_EVENT"          # student -> teacher: a kill / block happened

# ---------------------------------------------------------------------------
# Teacher → Student
# ---------------------------------------------------------------------------
MSG_WELCOME              = "WELCOME"
MSG_SESSION_CONFIG       = "SESSION_CONFIG"
MSG_SESSION_END          = "SESSION_END"
MSG_VIOLATION_ACK        = "VIOLATION_ACK"
MSG_SUBMISSION_ACK       = "SUBMISSION_ACK"          # legacy (kept)
MSG_SUBMISSION_ACK_META  = "SUBMISSION_ACK_META"
MSG_SUBMISSION_ACK_CHUNK = "SUBMISSION_ACK_CHUNK"
MSG_SUBMISSION_ACK_COMPLETE = "SUBMISSION_ACK_COMPLETE"
MSG_WEBRTC_ANSWER        = "WEBRTC_ANSWER"
MSG_WEBRTC_ICE           = "WEBRTC_ICE"
MSG_ERROR                = "ERROR"
MSG_PING                 = "PING"
MSG_BLOCK_PAUSE          = "BLOCK_PAUSE"          # teacher -> student: emergency override ON
MSG_BLOCK_RESUME         = "BLOCK_RESUME"         # teacher -> student: override OFF


STUDENT_TO_TEACHER = {
    MSG_HELLO, MSG_JOIN, MSG_HEARTBEAT, MSG_VIOLATION,
    MSG_SUBMISSION_META, MSG_SUBMISSION_CHUNK, MSG_SUBMISSION_COMPLETE,
    MSG_WEBRTC_OFFER, MSG_WEBRTC_ICE, MSG_DISCONNECT, MSG_BLOCK_EVENT,
}

TEACHER_TO_STUDENT = {
    MSG_WELCOME, MSG_SESSION_CONFIG, MSG_SESSION_END,
    MSG_VIOLATION_ACK, MSG_SUBMISSION_ACK,
    MSG_SUBMISSION_ACK_META, MSG_SUBMISSION_ACK_CHUNK, MSG_SUBMISSION_ACK_COMPLETE,
    MSG_WEBRTC_ANSWER, MSG_WEBRTC_ICE, MSG_ERROR, MSG_PING,
    MSG_BLOCK_PAUSE, MSG_BLOCK_RESUME,
}


FRAME_TERMINATOR = b"\n"
MAX_MESSAGE_SIZE = 2 * 1024 * 1024   # 2 MB (base64 chunk 256 KB → ~340 KB serialized)


class ProtocolError(Exception):
    pass


def encode(msg_type: str, **payload) -> bytes:
    if not msg_type:
        raise ProtocolError("msg_type is required")
    obj: Dict[str, Any] = {"type": msg_type}
    obj.update(payload)
    try:
        data = json.dumps(obj, separators=(",", ":")).encode("utf-8")
    except (TypeError, ValueError) as e:
        raise ProtocolError(f"Failed to encode: {e}") from e
    if len(data) + 1 > MAX_MESSAGE_SIZE:
        raise ProtocolError(f"Message too large ({len(data)} bytes)")
    return data + FRAME_TERMINATOR


def decode(raw: bytes) -> Dict[str, Any]:
    if not raw:
        raise ProtocolError("Empty message")
    try:
        obj = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise ProtocolError(f"Invalid JSON: {e}") from e
    if not isinstance(obj, dict):
        raise ProtocolError("Message must be a JSON object")
    if "type" not in obj or not isinstance(obj["type"], str):
        raise ProtocolError("Missing or invalid 'type'")
    return obj


def decode_line(line: bytes) -> Dict[str, Any]:
    return decode(line.rstrip(b"\r\n"))


def error_message(message: str, code: Optional[str] = None) -> bytes:
    payload = {"message": message}
    if code:
        payload["code"] = code
    return encode(MSG_ERROR, **payload)


# ---------------------------------------------------------------------------
# Convenience builders (unchanged + new)
# ---------------------------------------------------------------------------
def welcome(token, session_id, duration, student_db_id,
            course_name="", exam_title="") -> bytes:
    return encode(MSG_WELCOME, token=token, session_id=session_id,
                  duration=duration, student_db_id=student_db_id,
                  course_name=course_name, exam_title=exam_title)


def session_config(blocked_apps, blocked_domains, security_options) -> bytes:
    return encode(MSG_SESSION_CONFIG,
                  blocked_apps=list(blocked_apps or []),
                  blocked_domains=list(blocked_domains or []),
                  security_options=dict(security_options or {}))


def session_end() -> bytes:
    return encode(MSG_SESSION_END)


def violation_ack(violation_id: int) -> bytes:
    return encode(MSG_VIOLATION_ACK, violation_id=violation_id)


def submission_ack(submission_id: int) -> bytes:
    return encode(MSG_SUBMISSION_ACK, submission_id=submission_id)


def ping() -> bytes:
    return encode(MSG_PING)


def block_pause(reason: str = "") -> bytes:
    return encode(MSG_BLOCK_PAUSE, reason=reason)


def block_resume() -> bytes:
    return encode(MSG_BLOCK_RESUME)


# ---- Submission upload builders ----
def submission_meta(file_name: str, file_size: int, total_chunks: int,
                    file_sha256: str = "") -> bytes:
    return encode(MSG_SUBMISSION_META,
                  file_name=file_name, file_size=file_size,
                  total_chunks=total_chunks, file_sha256=file_sha256)


def submission_chunk(upload_id: str, chunk_index: int, total_chunks: int,
                     data_b64: str) -> bytes:
    return encode(MSG_SUBMISSION_CHUNK,
                  upload_id=upload_id, chunk_index=chunk_index,
                  total_chunks=total_chunks, data=data_b64)


def submission_complete(upload_id: str, file_sha256: str = "") -> bytes:
    return encode(MSG_SUBMISSION_COMPLETE,
                  upload_id=upload_id, file_sha256=file_sha256)


def submission_ack_meta(upload_id: str, accepted: bool = True,
                        reason: str = "") -> bytes:
    return encode(MSG_SUBMISSION_ACK_META,
                  upload_id=upload_id, accepted=accepted, reason=reason)


def submission_ack_chunk(upload_id: str, chunk_index: int,
                         ok: bool = True) -> bytes:
    return encode(MSG_SUBMISSION_ACK_CHUNK,
                  upload_id=upload_id, chunk_index=chunk_index, ok=ok)


def submission_ack_complete(upload_id: str, submission_id: int,
                            saved_path: str = "") -> bytes:
    return encode(MSG_SUBMISSION_ACK_COMPLETE,
                  upload_id=upload_id, submission_id=submission_id,
                  saved_path=saved_path)