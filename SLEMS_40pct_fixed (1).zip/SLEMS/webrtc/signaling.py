# SDP/ICE signaling.
"""
webrtc/signaling.py
Helpers to move SDP / ICE messages over the existing TCP network protocol.

The network layer already has MSG_WEBRTC_OFFER / MSG_WEBRTC_ICE (student→teacher)
and MSG_WEBRTC_ANSWER / MSG_WEBRTC_ICE (teacher→student).

This module is a thin convenience layer so webrtc/ code does not
reach into network/protocol.py directly.
"""
from typing import Optional

from network import protocol as P


# ---------------------------------------------------------------------------
# Student → Teacher
# ---------------------------------------------------------------------------
def build_offer(token: str, sdp: dict) -> bytes:
    """SDP offer message from student."""
    return P.encode(P.MSG_WEBRTC_OFFER, token=token, sdp=sdp)


def build_ice_from_student(token: str, candidate: dict) -> bytes:
    """ICE candidate message from student."""
    return P.encode(P.MSG_WEBRTC_ICE, token=token, candidate=candidate)


# ---------------------------------------------------------------------------
# Teacher → Student
# ---------------------------------------------------------------------------
def build_answer(sdp: dict) -> bytes:
    """SDP answer message from teacher."""
    return P.encode(P.MSG_WEBRTC_ANSWER, sdp=sdp)


def build_ice_from_teacher(candidate: dict) -> bytes:
    """ICE candidate message from teacher."""
    return P.encode(P.MSG_WEBRTC_ICE, candidate=candidate)


# ---------------------------------------------------------------------------
# Extractors
# ---------------------------------------------------------------------------
def extract_offer(msg: dict) -> Optional[dict]:
    """Return SDP dict from a WEBRTC_OFFER message, or None."""
    if msg.get("type") != P.MSG_WEBRTC_OFFER:
        return None
    sdp = msg.get("sdp")
    if not isinstance(sdp, dict) or "type" not in sdp or "sdp" not in sdp:
        return None
    return sdp


def extract_answer(msg: dict) -> Optional[dict]:
    if msg.get("type") != P.MSG_WEBRTC_ANSWER:
        return None
    sdp = msg.get("sdp")
    if not isinstance(sdp, dict) or "type" not in sdp or "sdp" not in sdp:
        return None
    return sdp


def extract_ice(msg: dict) -> Optional[dict]:
    if msg.get("type") != P.MSG_WEBRTC_ICE:
        return None
    cand = msg.get("candidate")
    if not isinstance(cand, dict):
        return None
    return cand