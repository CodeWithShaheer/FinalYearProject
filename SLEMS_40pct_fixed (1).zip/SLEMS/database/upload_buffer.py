"""
database/upload_buffer.py
In-memory tracker for in-progress file uploads on the teacher PC.

Each upload gets a UUID; chunks are appended; on completion the
buffer is written to disk and a submissions row is created.
"""
import base64
import hashlib
import logging
import os
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from config.settings import SUBMISSIONS_DIR, MAX_EXAM_PAPER_SIZE_BYTES

logger = logging.getLogger(__name__)


# Abandoned uploads are dropped after this many seconds
UPLOAD_TIMEOUT_SEC = 300


@dataclass
class PendingUpload:
    upload_id: str
    session_id: int
    student_db_id: int
    student_token: str
    roll_no: str
    file_name: str
    file_size: int
    total_chunks: int
    expected_sha256: str = ""
    chunks: Dict[int, bytes] = field(default_factory=dict)
    started_at: float = field(default_factory=time.time)
    last_activity: float = field(default_factory=time.time)

    @property
    def chunks_received(self) -> int:
        return len(self.chunks)

    @property
    def is_complete(self) -> bool:
        return len(self.chunks) == self.total_chunks

    def age_seconds(self) -> float:
        return time.time() - self.started_at

    def idle_seconds(self) -> float:
        return time.time() - self.last_activity


class UploadBuffer:
    """
    Teacher-side upload registry.
    Thread-safe enough for our single-asyncio-loop usage.
    """

    def __init__(self, submissions_dir: Optional[Path] = None):
        self._uploads: Dict[str, PendingUpload] = {}
        self._submissions_dir = Path(submissions_dir or SUBMISSIONS_DIR)
        self._submissions_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    def begin(self, session_id: int, student_db_id: int, student_token: str,
              roll_no: str, file_name: str, file_size: int,
              total_chunks: int, expected_sha256: str = "") -> tuple:
        """
        Register a new upload.
        Returns (ok: bool, upload_id or None, message: str).
        """
        # Validation
        if file_size <= 0 or file_size > MAX_EXAM_PAPER_SIZE_BYTES:
            return False, None, f"Invalid file size ({file_size})"
        if total_chunks <= 0 or total_chunks > 10000:
            return False, None, f"Invalid total_chunks ({total_chunks})"

        upload_id = uuid.uuid4().hex
        up = PendingUpload(
            upload_id=upload_id,
            session_id=session_id,
            student_db_id=student_db_id,
            student_token=student_token,
            roll_no=roll_no,
            file_name=os.path.basename(file_name) or "submission.bin",
            file_size=file_size,
            total_chunks=total_chunks,
            expected_sha256=expected_sha256,
        )
        self._uploads[upload_id] = up
        self._gc_stale()
        logger.info(
            "Upload started: id=%s student=%s file=%s size=%d chunks=%d",
            upload_id[:8], roll_no, up.file_name, file_size, total_chunks,
        )
        return True, upload_id, "OK"

    # ------------------------------------------------------------------
    def add_chunk(self, upload_id: str, chunk_index: int, data_b64: str) -> tuple:
        """
        Add a chunk to an upload. Returns (ok: bool, message: str).
        """
        up = self._uploads.get(upload_id)
        if up is None:
            return False, "Unknown upload_id"
        if chunk_index < 0 or chunk_index >= up.total_chunks:
            return False, "chunk_index out of range"
        if chunk_index in up.chunks:
            return True, "duplicate (ignored)"

        try:
            data = base64.b64decode(data_b64)
        except Exception as e:
            return False, f"base64 decode failed: {e}"

        # Sanity check size
        if len(data) > 1024 * 1024:
            return False, "chunk too large (>1 MB)"

        up.chunks[chunk_index] = data
        up.last_activity = time.time()
        return True, "OK"

    # ------------------------------------------------------------------
    def finalize(self, upload_id: str) -> tuple:
        """
        Assemble all chunks and write the file to disk.
        Returns (ok: bool, saved_path: str, message: str).
        """
        up = self._uploads.get(upload_id)
        if up is None:
            return False, "", "Unknown upload_id"
        if not up.is_complete:
            return False, "", f"Incomplete: {up.chunks_received}/{up.total_chunks}"

        # Assemble in order
        try:
            data = b"".join(up.chunks[i] for i in range(up.total_chunks))
        except KeyError as e:
            return False, "", f"Missing chunk: {e}"

        # Verify size
        if len(data) != up.file_size:
            logger.warning(
                "Upload %s size mismatch: got %d expected %d",
                upload_id[:8], len(data), up.file_size,
            )
            # Not fatal — some encodings differ. Continue.

        # Verify hash if provided
        if up.expected_sha256:
            actual = hashlib.sha256(data).hexdigest()
            if actual.lower() != up.expected_sha256.lower():
                return False, "", "SHA-256 mismatch (file corrupted)"

        # Save to disk with roll prefix + timestamp
        ts = time.strftime("%Y%m%d_%H%M%S")
        safe_name = f"{up.roll_no}_{ts}_{up.file_name}"
        dest_path = self._submissions_dir / safe_name
        try:
            with open(dest_path, "wb") as f:
                f.write(data)
        except Exception as e:
            logger.exception("Failed to write submission file")
            return False, "", f"Write failed: {e}"

        # Remove from registry
        self._uploads.pop(upload_id, None)

        logger.info(
            "Upload finalized: id=%s student=%s → %s (%d bytes)",
            upload_id[:8], up.roll_no, dest_path, len(data),
        )
        return True, str(dest_path), "OK"

    # ------------------------------------------------------------------
    def abort(self, upload_id: str) -> bool:
        return self._uploads.pop(upload_id, None) is not None

    def get(self, upload_id: str) -> Optional[PendingUpload]:
        return self._uploads.get(upload_id)

    # ------------------------------------------------------------------
    def _gc_stale(self):
        """Drop uploads that have been idle too long."""
        stale = [uid for uid, up in self._uploads.items()
                 if up.idle_seconds() > UPLOAD_TIMEOUT_SEC]
        for uid in stale:
            self._uploads.pop(uid, None)
            logger.info("Dropped stale upload: %s", uid[:8])

    # ------------------------------------------------------------------
    def stats(self) -> dict:
        return {
            "pending": len(self._uploads),
            "total_chunks_buffered": sum(len(u.chunks) for u in self._uploads.values()),
        }