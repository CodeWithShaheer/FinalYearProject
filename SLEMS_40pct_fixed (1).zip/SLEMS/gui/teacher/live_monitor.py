"""
gui/teacher/live_monitor.py
Live Monitor page — real network data + real WebRTC video (fast path).

v2.0 — Performance:
    - Uses direct-paint VideoWidget (no QLabel overhead)
    - update_frame() forwards frames; VideoWidget handles drops internally
"""
import logging
import time
from datetime import datetime

from PyQt5.QtCore import Qt, QTimer, pyqtSignal
from PyQt5.QtGui import QImage, QColor
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QScrollArea,
    QGridLayout, QFrame, QPushButton, QButtonGroup, QGraphicsDropShadowEffect,
    QDialog, QStackedWidget, QTableWidget, QTableWidgetItem, QHeaderView, QMenu,
    QInputDialog, QMessageBox,
)

from gui.common import theme
from gui.common.video_widget import VideoWidget
from gui.common.widgets import NotificationItem


logger = logging.getLogger(__name__)


def _drop_shadow(blur=20, y_offset=4):
    eff = QGraphicsDropShadowEffect()
    eff.setBlurRadius(blur)
    eff.setOffset(0, y_offset)
    eff.setColor(QColor(16, 24, 40, 40))
    return eff


class LiveStudentTile(QFrame):
    clicked = pyqtSignal(str)
    context_requested = pyqtSignal(str, object)     # token, global position

    def __init__(self, token: str, roll_no: str, full_name: str,
                 status: str = "normal", parent=None):
        super().__init__(parent)
        self.token = token
        self.roll_no = roll_no
        self.full_name = full_name
        self.status = status

        self.setObjectName("studentTile")
        self.setFixedSize(280, 260)
        self.setProperty("status", status)
        self.setGraphicsEffect(_drop_shadow())
        self.setCursor(Qt.PointingHandCursor)
        self._apply_tile_style()

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # Video
        video_container = QFrame()
        video_container.setFixedHeight(170)
        video_container.setStyleSheet(f"""
            QFrame {{
                background: {theme.NAVY_DARK};
                border-top-left-radius: 12px;
                border-top-right-radius: 12px;
            }}
        """)
        vc_layout = QVBoxLayout(video_container)
        vc_layout.setContentsMargins(0, 0, 0, 0)
        vc_layout.setSpacing(0)

        self.video = VideoWidget(show_placeholder=True)
        self.video.clear_video("Connecting video…")
        vc_layout.addWidget(self.video)

        outer.addWidget(video_container)

        # Footer
        footer = QWidget()
        fl = QVBoxLayout(footer)
        fl.setContentsMargins(14, 12, 14, 12)
        fl.setSpacing(4)

        top_row = QHBoxLayout()
        name_lbl = QLabel(full_name or roll_no)
        name_lbl.setObjectName("tileName")
        name_lbl.setStyleSheet(f"font-size: 16px; font-weight: 700; color: {theme.TEXT_PRIMARY};")
        top_row.addWidget(name_lbl)
        top_row.addStretch()

        self.status_badge = QLabel(theme.STATUS_LABELS.get(status, status))
        self.status_badge.setStyleSheet(
            f"background: {theme.STATUS_COLORS.get(status, theme.STATUS_NORMAL)};"
            f" color: white; font-size: 12px; font-weight: 700;"
            f" border-radius: 10px; padding: 3px 10px;"
        )
        top_row.addWidget(self.status_badge)
        fl.addLayout(top_row)

        info_row = QHBoxLayout()
        roll_lbl = QLabel(f"Roll: {roll_no}")
        roll_lbl.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 13px;")
        info_row.addWidget(roll_lbl)
        info_row.addStretch()
        self.video_state_lbl = QLabel("no video")
        self.video_state_lbl.setStyleSheet(
            f"color: {theme.STATUS_DISCONNECTED}; font-size: 11px; font-weight: 600;"
        )
        info_row.addWidget(self.video_state_lbl)
        fl.addLayout(info_row)

        outer.addWidget(footer)

    # ------------------------------------------------------------------
    def _apply_tile_style(self):
        style = f"""
            #studentTile {{
                background: {theme.CARD_BG};
                border-radius: 14px;
            }}
        """
        status = self.status
        if status == "normal":
            style += f"#studentTile {{ border: 3px solid {theme.STATUS_NORMAL}; }}"
        elif status == "behavioral":
            style += f"#studentTile {{ border: 4px solid {theme.STATUS_BEHAVIORAL}; }}"
        elif status == "service":
            style += f"#studentTile {{ border: 4px solid {theme.STATUS_SERVICE}; }}"
        elif status == "disconnected":
            style += f"#studentTile {{ border: 3px dashed {theme.STATUS_DISCONNECTED}; }}"
        self.setStyleSheet(style)

    def set_status(self, status: str):
        self.status = status
        self.status_badge.setText(theme.STATUS_LABELS.get(status, status))
        self.status_badge.setStyleSheet(
            f"background: {theme.STATUS_COLORS.get(status, theme.STATUS_NORMAL)};"
            f" color: white; font-size: 12px; font-weight: 700;"
            f" border-radius: 10px; padding: 3px 10px;"
        )
        self._apply_tile_style()

    def set_video_state(self, state: str):
        if state == "live":
            self.video_state_lbl.setText("● live")
            self.video_state_lbl.setStyleSheet(
                f"color: {theme.STATUS_NORMAL}; font-size: 11px; font-weight: 700;"
            )
        elif state == "ended":
            self.video_state_lbl.setText("video ended")
            self.video_state_lbl.setStyleSheet(
                f"color: {theme.STATUS_DISCONNECTED}; font-size: 11px; font-weight: 600;"
            )
            self.video.clear_video("Video ended")
        else:
            self.video_state_lbl.setText("no video")
            self.video_state_lbl.setStyleSheet(
                f"color: {theme.STATUS_DISCONNECTED}; font-size: 11px; font-weight: 600;"
            )

    def update_frame(self, qimage: QImage):
        self.video.set_frame(qimage)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit(self.token)
        super().mousePressEvent(event)

    def contextMenuEvent(self, event):
        self.context_requested.emit(self.token, event.globalPos())


class LiveFullscreenDialog(QDialog):
    def __init__(self, token, roll_no, full_name, status, parent=None):
        super().__init__(parent)
        self.token = token
        self.setWindowTitle(f"Student: {full_name or roll_no}")
        self.setWindowFlags(Qt.Window | Qt.WindowMaximizeButtonHint | Qt.WindowCloseButtonHint)
        self.resize(1280, 800)
        self.setStyleSheet(f"background: {theme.NAVY_DARK};")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        header = QHBoxLayout()
        title = QLabel(full_name or roll_no)
        title.setStyleSheet("color: white; font-size: 32px; font-weight: 800;")
        header.addWidget(title)

        info_col = QVBoxLayout()
        roll_lbl = QLabel(f"Roll: {roll_no}")
        roll_lbl.setStyleSheet(f"color: {theme.GOLD_LIGHT}; font-size: 18px; font-weight: 600;")
        info_col.addWidget(roll_lbl)
        token_lbl = QLabel(f"Token: {token[:8]}…")
        token_lbl.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 14px;")
        info_col.addWidget(token_lbl)
        header.addLayout(info_col)
        header.addStretch()

        status_badge = QLabel(theme.STATUS_LABELS.get(status, status))
        status_badge.setStyleSheet(
            f"background: {theme.STATUS_COLORS.get(status, theme.STATUS_NORMAL)};"
            f" color: white; font-size: 16px; font-weight: 700;"
            f" border-radius: 14px; padding: 8px 20px;"
        )
        header.addWidget(status_badge)

        close_btn = QPushButton("Close")
        close_btn.setFixedHeight(44)
        close_btn.setStyleSheet(f"""
            QPushButton {{
                background: {theme.STATUS_BEHAVIORAL}; color: white;
                border: none; border-radius: 10px;
                padding: 8px 24px; font-size: 15px; font-weight: 700;
            }}
            QPushButton:hover {{ background: #C43030; }}
        """)
        close_btn.setCursor(Qt.PointingHandCursor)
        close_btn.clicked.connect(self.close)
        header.addWidget(close_btn)

        layout.addLayout(header)

        self.video = VideoWidget(show_placeholder=True)
        self.video.clear_video("Waiting for video…")
        layout.addWidget(self.video, stretch=1)

    def update_frame(self, qimage: QImage):
        self.video.set_frame(qimage)


class LiveMonitorPage(QWidget):
    # S4: teacher asks to pause / resume blocking for ONE student -> TeacherDashboard -> network
    pause_requested = pyqtSignal(str, bool, str)        # token, paused, reason

    TABLE_COLUMNS = ["Roll No", "Name", "Status", "Blocks", "Violations", "Last seen", "IP"]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.filter_key = "all"
        self._students = {}
        self._fullscreen_dialogs = {}
        self._build_ui()
        self._table_timer = QTimer(self)               # keeps "last seen" fresh
        self._table_timer.timeout.connect(self._refresh_table)
        self._table_timer.start(1000)

    def _build_ui(self):
        root = QHBoxLayout(self)
        root.setContentsMargins(28, 24, 28, 28)
        root.setSpacing(24)

        left = QVBoxLayout()
        left.setSpacing(14)

        chip_row = QHBoxLayout()
        chip_row.setSpacing(12)
        self.chip_group = QButtonGroup(self)
        self.chip_group.setExclusive(True)
        self.chip_buttons = {}
        for i, (lbl, key) in enumerate([
            ("All (0)", "all"),
            ("Alerts (0)", "alert"),
            ("Service (0)", "service"),
            ("Offline (0)", "offline"),
        ]):
            btn = QPushButton(lbl)
            btn.setObjectName("chip")
            btn.setCheckable(True)
            btn.setChecked(i == 0)
            btn.clicked.connect(lambda _, k=key: self._apply_filter(k))
            self.chip_group.addButton(btn)
            self.chip_buttons[key] = btn
            chip_row.addWidget(btn)
        chip_row.addStretch()
        self.view_btn = QPushButton("Table view")
        self.view_btn.setObjectName("chip")
        self.view_btn.setCheckable(True)
        self.view_btn.setToolTip("Switch between video tiles and a status table")
        self.view_btn.clicked.connect(self._on_view_toggled)
        chip_row.addWidget(self.view_btn)
        left.addLayout(chip_row)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("background: transparent; border: none;")
        grid_host = QWidget()
        grid_host.setStyleSheet("background: transparent;")
        self.grid = QGridLayout(grid_host)
        self.grid.setSpacing(18)
        self.grid.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        scroll.setWidget(grid_host)

        self.table = QTableWidget(0, len(self.TABLE_COLUMNS))
        self.table.setHorizontalHeaderLabels(self.TABLE_COLUMNS)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        for col in (0, 2, 3, 4, 5, 6):
            self.table.horizontalHeader().setSectionResizeMode(col, QHeaderView.ResizeToContents)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.verticalHeader().setVisible(False)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._on_table_context)
        self.table.setStyleSheet(f"""
            QTableWidget {{ font-size: 14px; background: {theme.CARD_BG};
                border: 1px solid {theme.BORDER}; border-radius: 10px; gridline-color: {theme.BORDER}; }}
            QHeaderView::section {{ background: {theme.NAVY_DARK}; color: {theme.TEXT_ON_NAVY};
                padding: 10px 12px; font-weight: 700; font-size: 13px; border: none; }}
            QTableWidget::item {{ padding: 8px 12px; border-bottom: 1px solid {theme.BORDER}; }}
        """)

        self.view_stack = QStackedWidget()
        self.view_stack.addWidget(scroll)       # 0 = video tiles
        self.view_stack.addWidget(self.table)   # 1 = status table
        left.addWidget(self.view_stack, stretch=1)

        self.empty_lbl = QLabel(
            "No students connected yet.\n\n"
            "Start a session from Session Control, then students can join."
        )
        self.empty_lbl.setAlignment(Qt.AlignCenter)
        self.empty_lbl.setStyleSheet(
            f"color: {theme.TEXT_SECONDARY}; font-size: 15px; padding: 60px 20px;"
        )
        left.addWidget(self.empty_lbl, alignment=Qt.AlignCenter)
        root.addLayout(left, stretch=3)

        right = QFrame()
        right.setObjectName("card")
        right.setFixedWidth(380)
        right.setStyleSheet(f"""
            #card {{
                background: {theme.CARD_BG}; border: 1px solid {theme.BORDER};
                border-radius: 14px;
            }}
        """)
        right.setGraphicsEffect(_drop_shadow(blur=24, y_offset=6))
        rl = QVBoxLayout(right)
        rl.setContentsMargins(22, 18, 22, 18)
        rl.setSpacing(12)

        header_row = QHBoxLayout()
        title = QLabel("Live Alerts")
        title.setObjectName("notifPanelTitle")
        header_row.addWidget(title)
        header_row.addStretch()
        self.alert_count_lbl = QLabel("0")
        self.alert_count_lbl.setStyleSheet(
            f"color: white; background: {theme.STATUS_BEHAVIORAL}; border-radius: 12px;"
            f" padding: 3px 12px; font-size: 14px; font-weight: 700;"
        )
        header_row.addWidget(self.alert_count_lbl)
        rl.addLayout(header_row)

        self.notif_list = QVBoxLayout()
        self.notif_list.setSpacing(12)
        notif_scroll = QScrollArea()
        notif_scroll.setWidgetResizable(True)
        notif_scroll.setStyleSheet("background: transparent; border: none;")
        notif_host = QWidget()
        notif_host.setStyleSheet("background: transparent;")
        notif_host.setLayout(self.notif_list)
        notif_scroll.setWidget(notif_host)
        rl.addWidget(notif_scroll, stretch=1)

        self.no_alerts_lbl = QLabel("No alerts yet.")
        self.no_alerts_lbl.setStyleSheet(
            f"color: {theme.TEXT_SECONDARY}; font-size: 13px; padding: 8px;"
        )
        self.no_alerts_lbl.setAlignment(Qt.AlignCenter)
        rl.addWidget(self.no_alerts_lbl)

        root.addWidget(right, stretch=0)
        self._update_empty_state()

    def add_student(self, payload):
        token = payload.get("token")
        if not token or token in self._students:
            return
        roll_no = payload.get("roll_no", "")
        full_name = payload.get("full_name") or f"Student {roll_no}"
        for old_token, old in list(self._students.items()):      # same student came back
            if old["roll_no"] == roll_no:
                self._students.pop(old_token)
        tile = LiveStudentTile(token=token, roll_no=roll_no,
                                full_name=full_name, status="normal")
        tile.clicked.connect(self._on_tile_clicked)
        tile.context_requested.connect(self._on_context_requested)
        self._students[token] = {
            "token": token, "roll_no": roll_no, "full_name": full_name,
            "student_db_id": payload.get("student_db_id"),
            "session_id": payload.get("session_id"),
            "ip": payload.get("ip", ""), "status": "normal", "tile": tile,
            "kills": 0, "violations": 0, "last_seen": time.time(),
            "paused": False, "offline": False,
        }
        self._refresh_grid()
        self._update_chip_labels()
        self._update_empty_state()

    def remove_student(self, payload):
        """Student's link dropped.  S3: keep them on screen, marked red OFFLINE."""
        token = payload.get("token")
        entry = self._students.get(token)
        if not entry:
            return
        dlg = self._fullscreen_dialogs.pop(token, None)
        if dlg:
            try: dlg.close()
            except Exception: pass
        entry["offline"] = True
        entry["paused"] = False
        entry["status"] = "disconnected"
        entry["tile"].set_status("disconnected")
        entry["tile"].set_video_state("ended")
        self._refresh_grid()
        self._update_chip_labels()
        self._update_empty_state()

    # ---- S10 / S4: live stats pushed from the network bridge ----------------------------
    def note_heartbeat(self, token):
        entry = self._students.get(token)
        if entry:
            entry["last_seen"] = time.time()

    def note_block_event(self, payload):
        entry = self._students.get(payload.get("token"))
        if not entry:
            return
        entry["last_seen"] = time.time()
        if payload.get("event_type") in ("process_killed", "allowlist_kill"):
            entry["kills"] += 1

    def set_paused(self, token, paused: bool):
        entry = self._students.get(token)
        if entry:
            entry["paused"] = bool(paused)
            self._refresh_table()

    def set_peer_connected(self, token):
        entry = self._students.get(token)
        if entry:
            entry["tile"].set_video_state("live")

    def set_peer_disconnected(self, token):
        entry = self._students.get(token)
        if entry:
            entry["tile"].set_video_state("ended")
            dlg = self._fullscreen_dialogs.get(token)
            if dlg:
                dlg.video.clear_video("Video ended")

    def update_frame(self, token, qimage):
        entry = self._students.get(token)
        if not entry:
            return
        entry["tile"].update_frame(qimage)
        dlg = self._fullscreen_dialogs.get(token)
        if dlg:
            dlg.update_frame(qimage)

    def set_student_status(self, token, status):
        entry = self._students.get(token)
        if entry:
            entry["status"] = status
            entry["tile"].set_status(status)
            self._update_chip_labels()

    def add_violation(self, payload):
        token = payload.get("token")
        vtype = payload.get("vtype", "behavioral")
        if token in self._students:
            self._students[token]["violations"] += 1
            self._students[token]["last_seen"] = time.time()
            if not self._students[token]["offline"]:
                self._students[token]["status"] = vtype
                self._students[token]["tile"].set_status(vtype)
            self._update_chip_labels()
        time_str = datetime.now().strftime("%I:%M:%S %p")
        name = payload.get("full_name") or payload.get("roll_no", "Student")
        roll = payload.get("roll_no", "")
        desc = payload.get("description", "Violation detected")
        item = NotificationItem(time_str, name, vtype, desc, roll)
        self.notif_list.insertWidget(0, item)
        self._increment_alert_count()
        self.no_alerts_lbl.hide()

    def clear_all(self):
        self._students.clear()
        for dlg in self._fullscreen_dialogs.values():
            try: dlg.close()
            except Exception: pass
        self._fullscreen_dialogs.clear()
        self._refresh_grid()
        self._update_chip_labels()
        self._update_empty_state()
        for i in reversed(range(self.notif_list.count())):
            item = self.notif_list.itemAt(i)
            w = item.widget() if item else None
            if w:
                w.deleteLater()
        self.alert_count_lbl.setText("0")
        self.no_alerts_lbl.show()

    def _refresh_grid(self):
        while self.grid.count():
            item = self.grid.takeAt(0)
            w = item.widget()
            if w:
                w.setParent(None)
        filtered = self._filtered_students()
        cols = 3
        for i, s in enumerate(filtered):
            self.grid.addWidget(s["tile"], i // cols, i % cols)
        self._refresh_table()

    def _filtered_students(self):
        students = list(self._students.values())
        if self.filter_key == "all": return students
        if self.filter_key == "alert":
            return [s for s in students if s["status"] == "behavioral"]
        if self.filter_key == "service":
            return [s for s in students if s["status"] == "service"]
        if self.filter_key == "offline":
            return [s for s in students if s["status"] == "disconnected"]
        return students

    def _apply_filter(self, key):
        self.filter_key = key
        self._refresh_grid()

    def _update_chip_labels(self):
        total = len(self._students)
        alerts = sum(1 for s in self._students.values() if s["status"] == "behavioral")
        service = sum(1 for s in self._students.values() if s["status"] == "service")
        offline = sum(1 for s in self._students.values() if s["status"] == "disconnected")
        self.chip_buttons["all"].setText(f"All ({total})")
        self.chip_buttons["alert"].setText(f"Alerts ({alerts})")
        self.chip_buttons["service"].setText(f"Service ({service})")
        self.chip_buttons["offline"].setText(f"Offline ({offline})")

    def _increment_alert_count(self):
        try:
            n = int(self.alert_count_lbl.text())
        except ValueError:
            n = 0
        self.alert_count_lbl.setText(str(n + 1))

    def _update_empty_state(self):
        if self._students:
            self.empty_lbl.hide()
        else:
            self.empty_lbl.show()

    def _on_tile_clicked(self, token):
        entry = self._students.get(token)
        if not entry:
            return
        dlg = LiveFullscreenDialog(
            token=token, roll_no=entry["roll_no"],
            full_name=entry["full_name"], status=entry["status"], parent=self,
        )
        self._fullscreen_dialogs[token] = dlg
        dlg.finished.connect(lambda _c, t=token: self._fullscreen_dialogs.pop(t, None))
        dlg.show()

    # ------------------------------------------------------------------
    # S10 status table
    # ------------------------------------------------------------------
    def _on_view_toggled(self, checked: bool):
        self.view_stack.setCurrentIndex(1 if checked else 0)
        self.view_btn.setText("Video tiles" if checked else "Table view")
        self._refresh_table()

    @staticmethod
    def _ago(seconds: float) -> str:
        seconds = int(max(0, seconds))
        if seconds < 5:
            return "just now"
        if seconds < 60:
            return f"{seconds}s ago"
        return f"{seconds // 60}m {seconds % 60:02d}s ago"

    def _refresh_table(self):
        rows = self._filtered_students()
        self.table.setRowCount(len(rows))
        now = time.time()
        for r, e in enumerate(rows):
            if e["offline"]:
                state, color = "OFFLINE", theme.STATUS_BEHAVIORAL
            elif e["paused"]:
                state, color = "PAUSED", theme.STATUS_WARNING
            else:
                state, color = "ONLINE", theme.STATUS_NORMAL
            cells = [e["roll_no"], e["full_name"], state, str(e["kills"]),
                     str(e["violations"]), self._ago(now - e["last_seen"]), e["ip"]]
            for c, text in enumerate(cells):
                item = QTableWidgetItem(text)
                if c in (2, 3, 4, 5):
                    item.setTextAlignment(Qt.AlignCenter)
                if c == 2:
                    item.setForeground(QColor(color))
                    f = item.font(); f.setBold(True); item.setFont(f)
                item.setData(Qt.UserRole, e["token"])
                self.table.setItem(r, c, item)

    # ------------------------------------------------------------------
    # S4 emergency override menu
    # ------------------------------------------------------------------
    def _on_table_context(self, pos):
        item = self.table.itemAt(pos)
        if item is not None:
            self._on_context_requested(item.data(Qt.UserRole), self.table.viewport().mapToGlobal(pos))

    def _on_context_requested(self, token, global_pos):
        entry = self._students.get(token)
        if not entry or entry["offline"]:
            return
        menu = QMenu(self)
        title = menu.addAction(f"{entry['roll_no']} - {entry['full_name']}")
        title.setEnabled(False)
        menu.addSeparator()
        if entry["paused"]:
            act = menu.addAction("Resume blocking for this student")
        else:
            act = menu.addAction("Pause blocking (emergency override)...")
        chosen = menu.exec_(global_pos)
        if chosen is act:
            if entry["paused"]:
                self.pause_requested.emit(token, False, "")
            else:
                reason, ok = QInputDialog.getText(
                    self, "Pause blocking",
                    f"Why is blocking paused for {entry['roll_no']}?\n"
                    "(for example: wrong block, PC problem). This is written to the audit log.")
                if ok:
                    self.pause_requested.emit(token, True, reason.strip() or "no reason given")

