"""
gui/student/ai_status_panel.py
Real-time AI status panel for the student dashboard.

v2.0 — Performance:
    - Caches last applied stylesheet per label
    - Only calls setStyleSheet when color actually changes
    - Handles high-frequency status_update (15 Hz)
"""
import logging

from PyQt5.QtCore import Qt, pyqtSlot
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QGraphicsDropShadowEffect, QProgressBar,
)
from PyQt5.QtGui import QColor

from gui.common import theme

logger = logging.getLogger(__name__)


def _drop_shadow(blur=16, y_offset=3):
    eff = QGraphicsDropShadowEffect()
    eff.setBlurRadius(blur)
    eff.setOffset(0, y_offset)
    eff.setColor(QColor(16, 24, 40, 40))
    return eff


_STATUS_GOOD = "#2FA84F"
_STATUS_WARN = "#F2994A"
_STATUS_BAD = "#E23D3D"


class AiStatusPanel(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("aiStatusPanel")
        self.setStyleSheet(f"""
            #aiStatusPanel {{
                background: {theme.CARD_BG};
                border: 1px solid {theme.BORDER};
                border-radius: 14px;
            }}
        """)
        self.setGraphicsEffect(_drop_shadow())

        # Per-label style cache (avoid setStyleSheet spam)
        self._style_cache = {}

        self._build_ui()

    # ==================================================================
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(12)

        header = QHBoxLayout()
        title = QLabel("AI Monitoring")
        title.setStyleSheet(f"font-size: 16px; font-weight: 700; color: {theme.NAVY_DARK};")
        header.addWidget(title)
        header.addStretch()

        self.pipeline_lbl = QLabel("● idle")
        self.pipeline_lbl.setStyleSheet(
            f"color: {theme.STATUS_DISCONNECTED}; font-size: 12px; font-weight: 700;"
        )
        header.addWidget(self.pipeline_lbl)
        layout.addLayout(header)

        row1 = QHBoxLayout()
        row1.setSpacing(10)
        self.face_card, self.face_value = self._make_metric("Face")
        self.gaze_card, self.gaze_value = self._make_metric("Gaze")
        self.head_card, self.head_value = self._make_metric("Head")
        row1.addWidget(self.face_card, stretch=1)
        row1.addWidget(self.gaze_card, stretch=1)
        row1.addWidget(self.head_card, stretch=1)
        layout.addLayout(row1)

        row2 = QHBoxLayout()
        row2.setSpacing(10)
        self.hands_card, self.hands_value = self._make_metric("Hands")
        self.phone_card, self.phone_value = self._make_metric("Phone")
        self.dt_card, self.dt_value = self._make_metric("Inference")
        row2.addWidget(self.hands_card, stretch=1)
        row2.addWidget(self.phone_card, stretch=1)
        row2.addWidget(self.dt_card, stretch=1)
        layout.addLayout(row2)

        signals_row = QHBoxLayout()
        signals_lbl = QLabel("Active signals:")
        signals_lbl.setStyleSheet(
            f"color: {theme.TEXT_SECONDARY}; font-size: 12px; font-weight: 600;"
        )
        signals_row.addWidget(signals_lbl)
        self.signals_value = QLabel("—")
        self.signals_value.setStyleSheet(
            f"color: {theme.STATUS_WARNING}; font-size: 12px; font-weight: 700;"
        )
        self.signals_value.setWordWrap(True)
        signals_row.addWidget(self.signals_value, stretch=1)
        layout.addLayout(signals_row)

    # ==================================================================
    def _make_metric(self, title: str):
        card = QFrame()
        card.setStyleSheet(f"""
            QFrame {{
                background: {theme.BG}; border-radius: 8px; padding: 6px;
            }}
        """)
        v = QVBoxLayout(card)
        v.setContentsMargins(8, 6, 8, 6)
        v.setSpacing(2)

        lbl = QLabel(title.upper())
        lbl.setStyleSheet(
            f"color: {theme.TEXT_SECONDARY}; font-size: 10px; font-weight: 700;"
        )
        v.addWidget(lbl)

        val = QLabel("—")
        val.setStyleSheet(
            f"color: {theme.TEXT_PRIMARY}; font-size: 14px; font-weight: 700;"
        )
        v.addWidget(val)

        return card, val

    # ==================================================================
    def set_pipeline_state(self, state: str):
        if state == "running":
            self._set_label_style(self.pipeline_lbl,
                f"color: {theme.STATUS_NORMAL}; font-size: 12px; font-weight: 700;",
                "pipeline")
            self.pipeline_lbl.setText("● live")
        elif state == "starting":
            self._set_label_style(self.pipeline_lbl,
                f"color: {theme.STATUS_WARNING}; font-size: 12px; font-weight: 700;",
                "pipeline")
            self.pipeline_lbl.setText("● starting…")
        elif state == "error":
            self._set_label_style(self.pipeline_lbl,
                f"color: {theme.STATUS_BEHAVIORAL}; font-size: 12px; font-weight: 700;",
                "pipeline")
            self.pipeline_lbl.setText("● error")
        else:
            self._set_label_style(self.pipeline_lbl,
                f"color: {theme.STATUS_DISCONNECTED}; font-size: 12px; font-weight: 700;",
                "pipeline")
            self.pipeline_lbl.setText("● idle")

    # ==================================================================
    def _set_label_style(self, label: QLabel, style: str, cache_key: str):
        """Only call setStyleSheet if the style actually changed."""
        if self._style_cache.get(cache_key) == style:
            return
        label.setStyleSheet(style)
        self._style_cache[cache_key] = style

    # ==================================================================
    @pyqtSlot(dict)
    def update_status(self, payload: dict):
        # Face
        fc = payload.get("face_count", 0)
        if fc == 0:
            self.face_value.setText("no face")
            self._set_label_style(self.face_value,
                f"color: {_STATUS_BAD}; font-size: 14px; font-weight: 700;", "face")
        elif fc == 1:
            self.face_value.setText("1")
            self._set_label_style(self.face_value,
                f"color: {_STATUS_GOOD}; font-size: 14px; font-weight: 700;", "face")
        else:
            self.face_value.setText(f"{fc} faces")
            self._set_label_style(self.face_value,
                f"color: {_STATUS_BAD}; font-size: 14px; font-weight: 700;", "face")

        # Gaze
        gaze = payload.get("gaze", "unknown")
        self.gaze_value.setText(gaze.replace("away_", "→ "))
        if gaze == "center":
            self._set_label_style(self.gaze_value,
                f"color: {_STATUS_GOOD}; font-size: 14px; font-weight: 700;", "gaze")
        elif gaze.startswith("away_"):
            self._set_label_style(self.gaze_value,
                f"color: {_STATUS_WARN}; font-size: 14px; font-weight: 700;", "gaze")
        else:
            self._set_label_style(self.gaze_value,
                f"color: {theme.STATUS_DISCONNECTED}; font-size: 14px; font-weight: 700;", "gaze")

        # Head
        head = payload.get("head", "unknown")
        self.head_value.setText(head)
        if head == "center":
            self._set_label_style(self.head_value,
                f"color: {_STATUS_GOOD}; font-size: 14px; font-weight: 700;", "head")
        elif head in ("left", "right", "up", "down"):
            self._set_label_style(self.head_value,
                f"color: {_STATUS_WARN}; font-size: 14px; font-weight: 700;", "head")
        else:
            self._set_label_style(self.head_value,
                f"color: {theme.STATUS_DISCONNECTED}; font-size: 14px; font-weight: 700;", "head")

        # Hands
        hands = payload.get("hand_count", 0)
        self.hands_value.setText(str(hands))
        self._set_label_style(self.hands_value,
            f"color: {_STATUS_GOOD if hands == 0 else _STATUS_WARN};"
            f" font-size: 14px; font-weight: 700;", "hands")

        # Phone
        phone_heur = payload.get("phone_suspected", False)
        yolo_phone = payload.get("yolo_phone", False)
        yolo_conf = payload.get("yolo_phone_conf", 0.0)

        if yolo_phone:
            self.phone_value.setText(f"YOLO {yolo_conf*100:.0f}%")
            self._set_label_style(self.phone_value,
                f"color: {_STATUS_BAD}; font-size: 14px; font-weight: 700;", "phone")
        elif phone_heur:
            self.phone_value.setText("near face")
            self._set_label_style(self.phone_value,
                f"color: {_STATUS_WARN}; font-size: 14px; font-weight: 700;", "phone")
        else:
            self.phone_value.setText("none")
            self._set_label_style(self.phone_value,
                f"color: {_STATUS_GOOD}; font-size: 14px; font-weight: 700;", "phone")

        # Inference
        dt = payload.get("inference_ms", 0.0)
        self.dt_value.setText(f"{dt:.0f} ms")
        self._set_label_style(self.dt_value,
            f"color: {_STATUS_GOOD if dt < 120 else _STATUS_WARN};"
            f" font-size: 14px; font-weight: 700;", "dt")

        # Signals
        signals = payload.get("active_signals", {})
        if signals:
            parts = [f"{k} ({v:.1f}s)" for k, v in signals.items() if v > 0]
            self.signals_value.setText(", ".join(parts) if parts else "—")
        else:
            self.signals_value.setText("—")