"""
config package
Centralized configuration for SLEMS.
"""