"""
tools/windows_failure_check.py
Helper for docs/WINDOWS_FAILURE_TESTS.md  (works on any OS; real hosts file on Windows).

    python tools/windows_failure_check.py status
    python tools/windows_failure_check.py check clean   F3  [notes...]
    python tools/windows_failure_check.py check blocked F1a [notes...]

`check` prints PASS/FAIL (is the hosts file in the state you expect?) and appends a row to
docs/WINDOWS_TEST_LOG.csv.
"""
import csv
import json
import os
import socket
import sys
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from blocking.hosts_manager import (default_hosts_path, BLOCK_START, DEFAULT_STATE_FILE,
                                    HostsManager)

LOG = ROOT / "docs" / "WINDOWS_TEST_LOG.csv"


def hosts_blocked() -> bool:
    try:
        with open(default_hosts_path(), "rb") as f:
            return BLOCK_START.encode() in f.read()
    except OSError:
        return False


def status() -> None:
    blocked = hosts_blocked()
    print(f"Hosts file : {default_hosts_path()}")
    print(f"SLEMS block: {'PRESENT (sites are blocked)' if blocked else 'none (clean)'}")
    print(f"Admin      : {HostsManager().is_admin()}")
    if DEFAULT_STATE_FILE.exists():
        try:
            st = json.loads(DEFAULT_STATE_FILE.read_text(encoding='utf-8'))
            print(f"State file : pid {st.get('pid')} since {st.get('since')} ({len(st.get('domains', []))} domains)")
        except Exception:
            print("State file : present but unreadable")
    else:
        print("State file : none")


def check(expect: str, scenario: str, notes: str) -> int:
    expect = expect.lower()
    if expect not in ("clean", "blocked"):
        print("expect must be 'clean' or 'blocked'")
        return 2
    blocked = hosts_blocked()
    ok = (blocked and expect == "blocked") or (not blocked and expect == "clean")
    result = "PASS" if ok else "FAIL"
    print(f"{scenario}: expected hosts {expect.upper()}, found {'BLOCKED' if blocked else 'CLEAN'} -> {result}")
    LOG.parent.mkdir(exist_ok=True)
    new = not LOG.exists()
    with open(LOG, "a", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        if new:
            w.writerow(["Time", "PC", "Scenario", "Expected hosts", "Found hosts", "Result", "Notes"])
        w.writerow([datetime.now().strftime("%Y-%m-%d %H:%M:%S"), socket.gethostname(), scenario,
                    expect, "blocked" if blocked else "clean", result, notes])
    if not ok and expect == "clean":
        print("Fix now with:  python restore_hosts.py   (as Administrator)")
    return 0 if ok else 1


if __name__ == "__main__":
    args = sys.argv[1:]
    if not args or args[0] == "status":
        status()
    elif args[0] == "check" and len(args) >= 3:
        sys.exit(check(args[1], args[2], " ".join(args[3:])))
    else:
        print(__doc__)
