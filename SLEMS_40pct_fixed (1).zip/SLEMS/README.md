# SLEMS - Smart Lab Exam Monitoring System  (40% milestone)

## Run
1. Install PostgreSQL. Copy `.env.example` to `.env` and set `DB_PASSWORD` and `TEACHER_SIGNUP_KEY`.
2. `pip install -r requirements.txt`
3. **Run as Administrator on Windows** (needed to edit the hosts file and close apps): `python main.py`
   - **Teacher PC**: sign up as Teacher (type the sign-up key) -> Session Control -> pick presets, paste the roster,
     press *Review & Start*. A **6-digit join code** appears - tell it to the students.
   - **Student PC**: sign up as Student -> enter teacher IP (or *Discover*), the 6-digit code and your roll number.

## What it does
| Area | Features |
|---|---|
| Blocking engine | kill blocked apps (< 2 s), block websites through the hosts file (IPv4 + IPv6), one-click presets with all sub-domains, allow-list mode (Windows), emergency pause per student, crash-safe restore |
| Teacher dashboard | Session Control, Live Monitor (tiles + status table), Violation Log (filters, review, CSV), Block Events with kill latency, Audit Log, Reports |
| Student dashboard | join with code, exam timer, file submit (auto-submit at time zero), blocking status |
| Security | bcrypt passwords + lockout, teacher sign-up key, random join code with brute-force limit, roster check, executables refused on upload |
| Evidence | `docs/TEST_MATRIX.md` (35 automated tests), `docs/DEMO_SCRIPT.md`, `docs/WINDOWS_FAILURE_TESTS.md` |

## If a website is still blocked after an exam
Start SLEMS again (it cleans leftovers automatically) or run `python restore_hosts.py` as Administrator.

## Tests
    python -m pytest tests -v                 # needs PostgreSQL running (35 tests)
    python tools/make_test_matrix.py          # re-creates docs/TEST_MATRIX.md and .csv
    python tools/windows_failure_check.py status    # used by the Windows failure tests
Scripts in `tests/manual/` need a webcam / Windows.

## Feature flags (.env)
`ENABLE_AI_MONITORING` and `ENABLE_P2P_STREAMING` are **off** for the 40% milestone; turning them on needs
`pip install -r requirements-optional.txt`.
