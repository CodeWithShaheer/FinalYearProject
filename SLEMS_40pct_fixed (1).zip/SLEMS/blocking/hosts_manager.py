"""
blocking/hosts_manager.py
Safe hosts-file blocking with a guaranteed restore path.

Why the old version left the hosts file blocked
-----------------------------------------------
Restore only ran when the BlockingEngine thread exited cleanly.  If the app
crashed, was killed, lost its connection, or the GUI gave up waiting on the
thread, the "0.0.0.0 domain" lines stayed in the hosts file forever and
nothing cleaned them up on the next launch.

How this version guarantees restore
-----------------------------------
1. Everything SLEMS writes lives between two marker lines, so restore removes
   exactly our lines and never touches the user's own entries.
2. A small state file records that a block is active.  On every app start
   `recover_stale_block()` removes a leftover block (crash recovery).
3. `install_safety_net()` (call once from the main thread) registers atexit
   and signal handlers (Ctrl+C, terminate, Ctrl+Break) that restore the file.
4. restore() is idempotent, retried, thread-safe and verified by read-back.
5. Backups are always taken from a *clean* copy (never from an already
   blocked file) and only the newest few are kept.

The hosts file is read/written as raw bytes (latin-1 round trip), so the
user's original content, encoding and line endings are preserved exactly.
"""
import atexit
import json
import logging
import os
import platform
import re
import signal
import stat
import subprocess
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import List, Optional

logger = logging.getLogger(__name__)

HOSTS_PATH_WINDOWS = r"C:\Windows\System32\drivers\etc\hosts"
HOSTS_PATH_LINUX = "/etc/hosts"
BLOCK_START = "# === SLEMS-BLOCK-START ==="
BLOCK_END = "# === SLEMS-BLOCK-END ==="
BACKUP_DIR_NAME = "hosts_backup"
MAX_BACKUPS = 5

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_BACKUP_DIR = _PROJECT_ROOT / "data" / BACKUP_DIR_NAME
DEFAULT_STATE_FILE = _PROJECT_ROOT / "data" / "hosts_state.json"

_DOMAIN_RE = re.compile(
    r"^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$")

# Managers that currently hold a block; the safety net restores all of them.
_ACTIVE: List["HostsManager"] = []
_ACTIVE_LOCK = threading.Lock()


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def default_hosts_path() -> str:
    if platform.system().lower() == "windows":
        return HOSTS_PATH_WINDOWS
    return HOSTS_PATH_LINUX


def normalize_domain(raw: str) -> Optional[str]:
    """'https://WWW.YouTube.com/watch?v=1' -> 'youtube.com'. None if invalid."""
    d = (raw or "").strip().lower()
    if not d:
        return None
    d = re.sub(r"^[a-z][a-z0-9+.-]*://", "", d)      # scheme
    if "/" in d.split("?")[0].split("#")[0].rstrip("/"):
        # hosts files work per HOST, not per page: "github.com/copilot" blocks ALL of github.com
        logger.warning("Path entry %r blocks the whole host - use a host name instead.", raw)
    d = d.split("/")[0].split("?")[0].split("#")[0]   # path / query
    d = d.split("@")[-1].split(":")[0]                # user@ and :port
    if d.startswith("www."):
        d = d[4:]
    try:
        d = d.encode("idna").decode("ascii")          # unicode -> ascii
    except Exception:
        return None
    return d if _DOMAIN_RE.match(d) else None


def strip_slems_section(content: str) -> str:
    """
    Remove the SLEMS block from hosts text (works on str, any line ending).

    Safe against a damaged file: if START exists but END is missing (partial
    write / crash), only the START line and the SLEMS-generated lines that
    follow it are removed -- the rest of the user's file is kept.
    """
    nl = "\r\n" if "\r\n" in content else "\n"
    lines = content.splitlines()
    out: List[str] = []
    inside = False
    for line in lines:
        s = line.strip()
        if s == BLOCK_START:
            inside = True
            continue
        if s == BLOCK_END:
            inside = False
            continue
        if inside:
            # tolerate a missing END marker: leave the block as soon as a
            # line is clearly not something SLEMS wrote.
            if s.startswith(("0.0.0.0 ", ":: ", "# SLEMS")) or not s:
                continue
            inside = False
        out.append(line)
    while out and not out[-1].strip():
        out.pop()
    return nl.join(out) + nl


def has_slems_block(content: str) -> bool:
    return BLOCK_START in content


def _pid_alive(pid: int) -> bool:
    try:
        import psutil
        return psutil.pid_exists(pid)
    except Exception:
        try:
            os.kill(pid, 0)
            return True
        except Exception:
            return False


# ---------------------------------------------------------------------------
class HostsManager:
    def __init__(self,
                 backup_dir: Optional[Path] = None,
                 hosts_path: Optional[str] = None,
                 state_file: Optional[Path] = None):
        self.hosts_path = str(hosts_path) if hosts_path else default_hosts_path()
        self.backup_dir = Path(backup_dir) if backup_dir else DEFAULT_BACKUP_DIR
        self.state_file = Path(state_file) if state_file else DEFAULT_STATE_FILE
        try:
            self.backup_dir.mkdir(parents=True, exist_ok=True)
            self.state_file.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            logger.exception("Could not create hosts backup/state directory")
        self._has_backup = False
        self._currently_blocked: List[str] = []
        self._lock = threading.RLock()

    # ------------------------------------------------------------------
    def is_admin(self) -> bool:
        try:
            if platform.system().lower() == "windows":
                import ctypes
                return bool(ctypes.windll.shell32.IsUserAnAdmin())
            return os.geteuid() == 0
        except Exception:
            return False

    # ------------------------------------------------------------------
    # raw file access (bytes, lossless)
    # ------------------------------------------------------------------
    def _read_hosts(self) -> str:
        with open(self.hosts_path, "rb") as f:
            return f.read().decode("latin-1")

    def _write_hosts(self, content: str) -> bool:
        """Write + fsync + read-back verify.  Returns True only if verified."""
        data = content.encode("latin-1")
        try:
            # Windows hosts file is sometimes marked read-only
            try:
                os.chmod(self.hosts_path, os.stat(self.hosts_path).st_mode | stat.S_IWRITE)
            except Exception:
                pass
            with open(self.hosts_path, "wb") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            with open(self.hosts_path, "rb") as f:
                return f.read() == data
        except PermissionError:
            logger.error("Permission denied writing hosts file - run as Administrator.")
            return False
        except Exception:
            logger.exception("Failed to write hosts file")
            return False

    # ------------------------------------------------------------------
    # backup (always of a CLEAN copy)
    # ------------------------------------------------------------------
    def backup(self) -> Optional[Path]:
        try:
            if not os.path.exists(self.hosts_path):
                logger.warning("Hosts file not found: %s", self.hosts_path)
                return None
            clean = strip_slems_section(self._read_hosts())
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            path = self.backup_dir / f"hosts_backup_{ts}.txt"
            path.write_bytes(clean.encode("latin-1"))
            self._has_backup = True
            self._prune_backups()
            logger.info("Hosts backup: %s", path)
            return path
        except Exception:
            logger.exception("Hosts backup failed")
            return None

    def _prune_backups(self):
        try:
            files = sorted(self.backup_dir.glob("hosts_backup_*.txt"))
            for old in files[:-MAX_BACKUPS]:
                old.unlink(missing_ok=True)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # state file (crash recovery marker)
    # ------------------------------------------------------------------
    def _write_state(self, domains: List[str]):
        try:
            self.state_file.write_text(json.dumps({
                "pid": os.getpid(),
                "since": datetime.now().isoformat(timespec="seconds"),
                "domains": domains,
            }), encoding="utf-8")
        except Exception:
            logger.exception("Could not write hosts state file")

    def _clear_state(self):
        try:
            self.state_file.unlink(missing_ok=True)
        except Exception:
            pass

    # ------------------------------------------------------------------
    def _is_active_registered(self) -> bool:
        with _ACTIVE_LOCK:
            return self in _ACTIVE

    def _register(self):
        with _ACTIVE_LOCK:
            if self not in _ACTIVE:
                _ACTIVE.append(self)

    def _unregister(self):
        with _ACTIVE_LOCK:
            if self in _ACTIVE:
                _ACTIVE.remove(self)

    # ------------------------------------------------------------------
    def block_domains(self, domains: List[str]) -> bool:
        with self._lock:
            clean_domains: List[str] = []
            for raw in domains or []:
                d = normalize_domain(raw)
                if d and d not in clean_domains:
                    clean_domains.append(d)
                elif not d and (raw or "").strip():
                    logger.warning("Ignoring invalid domain: %r", raw)

            if not clean_domains:
                self._currently_blocked = []
                return True

            if not self.is_admin():
                logger.warning("Not admin - hosts file edit will probably fail.")
            try:
                content = self._read_hosts()
            except Exception:
                logger.exception("Cannot read hosts file")
                return False

            if not self._has_backup:
                self.backup()

            content = strip_slems_section(content)
            nl = "\r\n" if "\r\n" in content else "\n"
            block = [BLOCK_START,
                     f"# SLEMS blocked at {datetime.now().isoformat(timespec='seconds')}"]
            for d in clean_domains:
                for host in (d, f"www.{d}"):
                    block.append(f"0.0.0.0 {host}")      # IPv4
                    block.append(f":: {host}")           # IPv6 - browsers may prefer it
            block.append(BLOCK_END)
            final = content + nl + nl.join(block) + nl

            # register BEFORE writing so a crash mid-write is still recovered
            self._write_state(clean_domains)
            self._register()
            ok = self._write_hosts(final)
            if ok:
                self._currently_blocked = clean_domains
                self._flush_dns()
                logger.info("Blocked %d domains.", len(clean_domains))
            else:
                # try to leave the file clean if the write half-succeeded
                self.restore()
            return ok

    # ------------------------------------------------------------------
    def restore(self, retries: int = 3) -> bool:
        """Remove the SLEMS block.  Idempotent: True also when nothing to do."""
        with self._lock:
            ok = False
            for attempt in range(1, retries + 1):
                try:
                    content = self._read_hosts()
                except FileNotFoundError:
                    ok = True
                    break
                except Exception:
                    logger.exception("Cannot read hosts during restore")
                    time.sleep(0.2)
                    continue

                if not has_slems_block(content):
                    ok = True
                    break
                if self._write_hosts(strip_slems_section(content)):
                    ok = True
                    break
                logger.warning("Hosts restore attempt %d/%d failed", attempt, retries)
                time.sleep(0.3)

            if ok:
                self._currently_blocked = []
                self._clear_state()
                self._unregister()
                self._flush_dns()
                logger.info("Hosts restored.")
            else:
                logger.error("HOSTS RESTORE FAILED - run restore_hosts.py as Administrator.")
            return ok

    # ------------------------------------------------------------------
    @staticmethod
    def _flush_dns():
        try:
            if platform.system().lower() == "windows":
                subprocess.run(["ipconfig", "/flushdns"],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               creationflags=0x08000000, timeout=10)   # no console window
        except Exception:
            pass

    @property
    def currently_blocked(self) -> List[str]:
        return list(self._currently_blocked)

    @property
    def has_backup(self) -> bool:
        return self._has_backup

    @property
    def is_block_active(self) -> bool:
        try:
            return has_slems_block(self._read_hosts())
        except Exception:
            return False


# ---------------------------------------------------------------------------
# Module-level crash safety
# ---------------------------------------------------------------------------
def restore_all_active() -> None:
    """Restore every block this process created (used by atexit / signals)."""
    with _ACTIVE_LOCK:
        managers = list(_ACTIVE)
    for m in managers:
        try:
            m.restore()
        except Exception:
            logger.exception("restore_all_active failed")


def recover_stale_block(hosts_path: Optional[str] = None,
                        state_file: Optional[Path] = None) -> bool:
    """
    Call at application start.  If a previous run died while blocking, the
    SLEMS block is still in the hosts file - remove it.
    Returns True if a stale block was found and removed.
    """
    mgr = HostsManager(hosts_path=hosts_path, state_file=state_file)
    try:
        content = mgr._read_hosts()
    except Exception:
        return False
    if not has_slems_block(content):
        mgr._clear_state()
        return False

    # another live SLEMS process may legitimately own the block
    try:
        if mgr.state_file.exists():
            pid = int(json.loads(mgr.state_file.read_text(encoding="utf-8")).get("pid", 0))
            if pid and pid != os.getpid() and _pid_alive(pid):
                logger.info("Hosts block belongs to running SLEMS pid %s - leaving it.", pid)
                return False
    except Exception:
        pass

    logger.warning("Stale SLEMS hosts block found from a previous run - removing it.")
    return mgr.restore()


_SAFETY_INSTALLED = False


def install_safety_net() -> None:
    """
    Call ONCE from the main thread at startup.
      * removes a stale block left by a previous crash
      * restores the hosts file on normal exit (atexit)
      * restores on Ctrl+C / terminate / Ctrl+Break
    """
    global _SAFETY_INSTALLED
    if _SAFETY_INSTALLED:
        return
    _SAFETY_INSTALLED = True

    try:
        recover_stale_block()
    except Exception:
        logger.exception("Stale hosts recovery failed")

    atexit.register(restore_all_active)

    def _handler(signum, frame):
        restore_all_active()
        prev = _PREV_HANDLERS.get(signum)
        if callable(prev):
            prev(signum, frame)
        else:
            raise SystemExit(0)

    _PREV_HANDLERS = {}
    for name in ("SIGINT", "SIGTERM", "SIGBREAK"):
        sig = getattr(signal, name, None)
        if sig is None:
            continue
        try:
            _PREV_HANDLERS[sig] = signal.getsignal(sig)
            signal.signal(sig, _handler)
        except Exception:
            pass   # not main thread / unsupported on this platform
