"""
gui/common/theme.py
NUML brand palette + global QSS stylesheet for SLEMS.

v2.1 — All buttons use NAVY background (visible against white cards).
"""

# ---------------------------------------------------------------------------
# Color palette
# ---------------------------------------------------------------------------
NAVY_DARK = "#0A1F44"
NAVY = "#0F2C5C"
NAVY_LIGHT = "#1E4488"
GOLD = "#D4AF37"
GOLD_LIGHT = "#F1D97A"

BG = "#F4F6FA"
CARD_BG = "#FFFFFF"
BORDER = "#E0E4EC"

TEXT_PRIMARY = "#101828"
TEXT_SECONDARY = "#5B6474"
TEXT_ON_NAVY = "#F4F6FA"

STATUS_NORMAL = "#2FA84F"
STATUS_BEHAVIORAL = "#E23D3D"
STATUS_SERVICE = "#F2994A"
STATUS_DISCONNECTED = "#9AA1AC"
STATUS_INFO = "#3B82F6"
STATUS_SUCCESS = "#10B981"
STATUS_WARNING = "#F59E0B"

STATUS_COLORS = {
    "normal": STATUS_NORMAL,
    "behavioral": STATUS_BEHAVIORAL,
    "service": STATUS_SERVICE,
    "disconnected": STATUS_DISCONNECTED,
}

STATUS_LABELS = {
    "normal": "OK",
    "behavioral": "Behavioral Alert",
    "service": "Service Violation",
    "disconnected": "Disconnected",
}

FONT_FAMILY = "Segoe UI"


def build_stylesheet() -> str:
    return f"""
    QWidget {{
        font-family: '{FONT_FAMILY}';
        color: {TEXT_PRIMARY};
        font-size: 15px;
    }}

    QMainWindow, #centralArea {{
        background: {BG};
    }}

    /* ---------- Sidebar ---------- */
    #sidebar {{ background: {NAVY_DARK}; }}
    #sidebarLogo {{
        color: {TEXT_ON_NAVY};
        font-size: 26px;
        font-weight: 800;
        letter-spacing: 2px;
    }}
    #sidebarSubtitle {{
        color: {GOLD_LIGHT};
        font-size: 16px;
        font-weight: 600;
    }}
    QPushButton#navButton {{
        text-align: left;
        padding: 18px 24px;
        border: none;
        border-radius: 0px;
        color: {TEXT_ON_NAVY};
        background: transparent;
        font-size: 18px;
        font-weight: 600;
    }}
    QPushButton#navButton:hover {{ background: {NAVY_LIGHT}; }}
    QPushButton#navButton:checked {{
        background: {NAVY};
        border-left: 5px solid {GOLD};
        font-weight: 700;
    }}

    /* ---------- Top bar ---------- */
    #topBar {{
        background: {CARD_BG};
        border-bottom: 1px solid {BORDER};
    }}
    #topBarTitle {{
        font-size: 26px;
        font-weight: 700;
        color: {NAVY_DARK};
    }}
    #topBarSubtitle {{
        font-size: 15px;
        color: {TEXT_SECONDARY};
        font-weight: 500;
    }}
    #sessionTimer {{
        font-size: 26px;
        font-weight: 700;
        color: {NAVY};
        background: {BG};
        border: 1px solid {BORDER};
        border-radius: 10px;
        padding: 8px 18px;
    }}

    /* ==================================================================
       BUTTONS — All NAVY blue, clearly visible on white cards
       ================================================================== */

    QPushButton#primaryBtn {{
        background: {NAVY};
        color: white;
        border: none;
        border-radius: 10px;
        padding: 12px 28px;
        font-weight: 700;
        font-size: 16px;
        min-height: 40px;
    }}
    QPushButton#primaryBtn:hover {{ background: {NAVY_LIGHT}; }}
    QPushButton#primaryBtn:disabled {{
        background: #B7BEC9;
        color: #FFFFFF;
    }}

    QPushButton#goldBtn {{
        background: {GOLD};
        color: {NAVY_DARK};
        border: none;
        border-radius: 10px;
        padding: 12px 28px;
        font-weight: 700;
        font-size: 16px;
        min-height: 40px;
    }}
    QPushButton#goldBtn:hover {{ background: {GOLD_LIGHT}; }}
    QPushButton#goldBtn:disabled {{
        background: #B7BEC9;
        color: #FFFFFF;
    }}

    QPushButton#dangerBtn {{
        background: {NAVY};
        color: white;
        border: none;
        border-radius: 10px;
        padding: 12px 28px;
        font-weight: 700;
        font-size: 16px;
        min-height: 40px;
    }}
    QPushButton#dangerBtn:hover {{ background: {STATUS_BEHAVIORAL}; }}

    QPushButton#ghostBtn {{
        background: {NAVY};
        color: white;
        border: none;
        border-radius: 8px;
        padding: 10px 20px;
        font-size: 14px;
        font-weight: 700;
        min-height: 34px;
    }}
    QPushButton#ghostBtn:hover {{ background: {NAVY_LIGHT}; }}

    QPushButton#monitorBtn {{
        background: {NAVY};
        color: white;
        border: none;
        border-radius: 6px;
        padding: 6px 14px;
        font-size: 12px;
        font-weight: 700;
        min-height: 26px;
    }}
    QPushButton#monitorBtn:hover {{ background: {NAVY_LIGHT}; }}

    QPushButton#reportBtn {{
        background: {NAVY};
        color: white;
        border: none;
        border-radius: 6px;
        padding: 6px 14px;
        font-size: 12px;
        font-weight: 700;
        min-height: 26px;
    }}
    QPushButton#reportBtn:hover {{ background: {NAVY_LIGHT}; }}

    QPushButton#addCourseBtn {{
        background: {NAVY};
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 700;
        padding: 6px 16px;
        min-height: 32px;
    }}
    QPushButton#addCourseBtn:hover {{ background: {NAVY_LIGHT}; }}

    QPushButton#uploadBtn {{
        background: {NAVY};
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 13px;
        font-weight: 700;
        padding: 6px 18px;
        min-height: 32px;
    }}
    QPushButton#uploadBtn:hover {{ background: {NAVY_LIGHT}; }}

    QPushButton#selectAllBtn {{
        background: transparent;
        color: {NAVY};
        border: none;
        font-size: 12px;
        font-weight: 700;
        text-decoration: underline;
        padding: 2px 6px;
    }}
    QPushButton#selectAllBtn:hover {{ color: {GOLD}; }}

    /* ---------- Cards ---------- */
    #card {{
        background: {CARD_BG};
        border: 1px solid {BORDER};
        border-radius: 14px;
    }}
    #cardTitle {{
        font-size: 20px;
        font-weight: 700;
        color: {NAVY_DARK};
    }}

    /* ---------- Stat Cards ---------- */
    #statCard {{
        background: {CARD_BG};
        border-radius: 16px;
        border: 1px solid {BORDER};
    }}
    #statCardTotal {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 {NAVY}, stop:1 {NAVY_LIGHT});
        border-radius: 16px;
    }}
    #statCardSubmitted {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 {STATUS_NORMAL}, stop:1 #34D399);
        border-radius: 16px;
    }}
    #statCardRemaining {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 {STATUS_BEHAVIORAL}, stop:1 #FCA5A5);
        border-radius: 16px;
    }}
    #statCardPending {{
        background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 {STATUS_SERVICE}, stop:1 #FCD34D);
        border-radius: 16px;
    }}
    #statLabel {{
        color: {TEXT_SECONDARY};
        font-size: 14px;
        font-weight: 600;
    }}
    #statValue {{ color: white; font-size: 36px; font-weight: 800; }}
    #statValueDark {{ color: {NAVY_DARK}; font-size: 36px; font-weight: 800; }}

    /* ---------- Student tile ---------- */
    #studentTile {{
        background: {CARD_BG};
        border-radius: 14px;
        border: 2px solid {BORDER};
    }}
    #studentTile[status="normal"] {{ border: 3px solid {STATUS_NORMAL}; }}
    #studentTile[status="behavioral"] {{ border: 4px solid {STATUS_BEHAVIORAL}; }}
    #studentTile[status="service"] {{ border: 4px solid {STATUS_SERVICE}; }}
    #studentTile[status="disconnected"] {{ border: 3px dashed {STATUS_DISCONNECTED}; }}

    #tileVideoArea {{
        background: {NAVY_DARK};
        border-top-left-radius: 12px;
        border-top-right-radius: 12px;
    }}
    #tileName {{ font-size: 17px; font-weight: 700; color: {TEXT_PRIMARY}; }}
    #tileId {{ font-size: 14px; color: {TEXT_SECONDARY}; font-weight: 500; }}
    #tileStatusBadge {{
        font-size: 13px;
        font-weight: 700;
        border-radius: 10px;
        padding: 4px 10px;
        color: white;
    }}

    /* ---------- Notification panel ---------- */
    #notifPanelTitle {{
        font-size: 20px;
        font-weight: 700;
        color: {NAVY_DARK};
    }}
    #notifItem {{
        background: {CARD_BG};
        border: 1px solid {BORDER};
        border-left: 5px solid {STATUS_NORMAL};
        border-radius: 10px;
    }}
    #notifItem[level="behavioral"] {{ border-left: 5px solid {STATUS_BEHAVIORAL}; }}
    #notifItem[level="service"] {{ border-left: 5px solid {STATUS_SERVICE}; }}
    #notifTime {{ color: {TEXT_SECONDARY}; font-size: 14px; font-weight: 500; }}
    #notifText {{ font-size: 15px; font-weight: 600; }}

    /* ---------- Filter chips ---------- */
    QPushButton#chip {{
        background: {BG};
        border: 1px solid {BORDER};
        border-radius: 16px;
        padding: 10px 20px;
        font-size: 15px;
        font-weight: 600;
        color: {TEXT_SECONDARY};
    }}
    QPushButton#chip:checked {{
        background: {NAVY};
        color: white;
        border: 1px solid {NAVY};
    }}

    /* ---------- Table ---------- */
    QTableWidget {{
        background: {CARD_BG};
        border: 1px solid {BORDER};
        border-radius: 12px;
        gridline-color: {BORDER};
        font-size: 15px;
    }}
    QHeaderView::section {{
        background: {NAVY_DARK};
        color: {TEXT_ON_NAVY};
        padding: 12px;
        border: none;
        font-weight: 700;
        font-size: 15px;
    }}
    QTableWidget::item {{ padding: 10px; }}

    /* ---------- Progress Bar ---------- */
    QProgressBar {{
        border: none;
        border-radius: 8px;
        background: {BORDER};
        text-align: center;
        font-weight: 700;
        font-size: 13px;
        color: {TEXT_PRIMARY};
        height: 24px;
    }}
    QProgressBar::chunk {{
        border-radius: 8px;
        background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 {NAVY}, stop:1 {NAVY_LIGHT});
    }}

    /* ---------- Misc ---------- */
    QLineEdit, QComboBox {{
        border: 2px solid {BORDER};
        border-radius: 10px;
        padding: 12px 14px;
        background: {CARD_BG};
        font-size: 15px;
    }}
    QLineEdit:focus, QComboBox:focus {{ border: 2px solid {NAVY}; }}
    QListWidget {{
        border: 1px solid {BORDER};
        border-radius: 10px;
        background: {CARD_BG};
        font-size: 15px;
    }}
    QScrollArea {{ border: none; background: transparent; }}
    QScrollBar:vertical {{ background: transparent; width: 12px; }}
    QScrollBar::handle:vertical {{
        background: {BORDER};
        border-radius: 6px;
        min-height: 50px;
    }}
    QCheckBox {{ font-size: 15px; padding: 4px 0; }}
    QSpinBox {{
        font-size: 15px;
        padding: 8px;
        border: 2px solid {BORDER};
        border-radius: 8px;
    }}
    QLabel {{ font-size: 15px; }}

    /* ======================================================================
       Session Control selectors
       ====================================================================== */

    #sectionHeader {{
        font-size: 16px;
        font-weight: 700;
        color: {NAVY_DARK};
        padding: 4px 0;
    }}
    #sectionBadge {{
        background: {NAVY};
        color: white;
        font-size: 14px;
        font-weight: 700;
        border-radius: 12px;
        padding: 3px 10px;
        min-width: 22px;
        min-height: 22px;
    }}

    #readinessChip {{
        background: {BG};
        border: 1px solid {BORDER};
        border-radius: 16px;
        padding: 8px 16px;
        font-size: 14px;
        font-weight: 600;
        color: {TEXT_SECONDARY};
    }}

    #searchBox {{
        border: 1px solid {BORDER};
        border-radius: 8px;
        padding: 8px 12px;
        font-size: 13px;
        background: {CARD_BG};
    }}
    #searchBox:focus {{ border: 1px solid {NAVY}; }}

    #timerBox {{
        background: {CARD_BG};
        border: 1px solid {BORDER};
        border-radius: 12px;
    }}
    #timerBoxLabel {{
        color: {TEXT_SECONDARY};
        font-size: 11px;
        font-weight: 700;
        letter-spacing: 1px;
    }}
    #timerBoxValue {{
        color: {NAVY};
        font-size: 28px;
        font-weight: 800;
        font-family: 'Consolas', 'Courier New', monospace;
    }}

    #fileUploadRow {{
        background: {BG};
        border: 1px solid {BORDER};
        border-radius: 10px;
    }}
    #fileUploadName {{ color: {TEXT_PRIMARY}; font-size: 13px; font-weight: 600; }}
    #fileUploadSize {{ color: {TEXT_SECONDARY}; font-size: 12px; }}

    #securityOptionRow {{
        padding: 4px 0;
        font-size: 14px;
        color: {TEXT_PRIMARY};
    }}

    #infoFooter {{
        color: {TEXT_SECONDARY};
        font-size: 13px;
        font-style: italic;
        padding: 4px 0;
    }}
    """