"""
blocking/blocking_engine.py
QThread orchestrating process + domain blocking.

v4.0 — Aggressive exam lockdown
    - Scan every 0.3 seconds (turant detect)
    - Triple-tap kill: 3 scans in quick succession
    - Per-app violation cooldown: 15 s
"""
import logging
import threading
import time
from typing import Dict, List, Optional

from PyQt5.QtCore import QThread, pyqtSignal

from blocking.process_monitor import ProcessMonitor, DetectedProcess
from blocking.process_blocker import ProcessBlocker
from blocking.hosts_manager import HostsManager
from blocking.domain_blocker import DomainBlocker
from blocking.allowlist import AllowListEnforcer

logger = logging.getLogger(__name__)


PROCESS_SCAN_INTERVAL_SEC = 0.3     # Super fast — 3x per second
TRIPLE_TAP_DELAY_SEC = 0.20         # 200ms between re-scans
TRIPLE_TAP_COUNT = 3                # 3 re-scans after kill
CONNECTION_SCAN_INTERVAL_SEC = 10.0
VIOLATION_COOLDOWN_SEC = 15.0


class BlockingEngine(QThread):
    blocking_started = pyqtSignal(dict)
    blocking_stopped = pyqtSignal()
    violation_detected = pyqtSignal(dict)
    blocked_process_killed = pyqtSignal(dict)
    status_update = pyqtSignal(dict)
    error_occurred = pyqtSignal(str)
    paused_changed = pyqtSignal(bool)

    def __init__(self,
                 blocked_apps: List[str],
                 blocked_domains: List[str],
                 security_options: Optional[dict] = None,
                 parent=None):
        super().__init__(parent)
        self._blocked_apps = list(blocked_apps or [])
        self._blocked_domains = list(blocked_domains or [])
        self._security_options = dict(security_options or {})
        self._running = False

        self._monitor: Optional[ProcessMonitor] = None
        self._blocker: Optional[ProcessBlocker] = None
        self._hosts: Optional[HostsManager] = None
        self._domain_blocker: Optional[DomainBlocker] = None

        self._killed_total = 0
        self._suspicious_total = 0
        self._last_violation: Dict[str, float] = {}

        # S4 emergency override, S5 allow-list, S6 latency evidence
        self._paused = False
        self._state_lock = threading.RLock()
        self._allowlist: Optional[AllowListEnforcer] = None
        self._started_wall = 0.0

    # ------------------------------------------------------------------
    def run(self):
        try:
            self._monitor = ProcessMonitor()
            self._monitor.set_blocklist(self._blocked_apps)
            self._blocker = ProcessBlocker()

            self._hosts = HostsManager()
            self._domain_blocker = DomainBlocker(self._hosts)
            self._domain_blocker.set_blocked_domains(self._blocked_domains)

            hosts_ok = False
            if self._blocked_domains and self._security_options.get("block_restricted_websites", True):
                try:
                    hosts_ok = self._domain_blocker.apply()
                except Exception:
                    logger.exception("Hosts apply failed")

            self._started_wall = time.time()
            if self._security_options.get("allowlist_mode"):
                self._allowlist = AllowListEnforcer(self._security_options.get("allowed_apps") or [])
                if not self._allowlist.usable:
                    self.error_occurred.emit(
                        "Allow-list mode is off: the allowed-apps list is empty or this OS "
                        "cannot list windows.")
                    self._allowlist = None

            self._running = True
            self.blocking_started.emit({
                "blocked_apps": self._blocked_apps,
                "blocked_domains": self._blocked_domains,
                "hosts_applied": hosts_ok,
                "admin": self._hosts.is_admin() if self._hosts else False,
            })

            if (self._blocked_domains and self._security_options.get("block_restricted_websites", True)
                    and not hosts_ok):
                self.error_occurred.emit(
                    "Website blocking could not be applied (run SLEMS as Administrator).")

            last_proc_scan = 0.0
            last_conn_scan = 0.0
            last_status = 0.0

            while self._running:
                now = time.time()

                if self._paused:                      # teacher emergency override: hands off
                    time.sleep(0.1)
                    continue

                if now - last_proc_scan >= PROCESS_SCAN_INTERVAL_SEC:
                    last_proc_scan = now
                    if self._security_options.get("block_unauthorized_apps", True):
                        self._scan_and_kill_processes()
                    if self._allowlist is not None:
                        self._scan_allowlist()

                if now - last_conn_scan >= CONNECTION_SCAN_INTERVAL_SEC:
                    last_conn_scan = now
                    if self._security_options.get("block_restricted_websites", True):
                        self._scan_connections()

                if now - last_status >= 1.0:          # 1 Hz, not 20 Hz
                    last_status = now
                    self.status_update.emit({
                        "killed_total": self._killed_total,
                        "suspicious_total": self._suspicious_total,
                        "blocked_apps_count": len(self._blocked_apps),
                        "blocked_domains_count": len(self._blocked_domains),
                    })

                time.sleep(0.05)  # 50ms loop tick — super responsive

        except Exception as e:
            logger.exception("BlockingEngine crashed")
            self.error_occurred.emit(f"Blocking engine crashed: {e}")
        finally:
            self._cleanup()
            self.blocking_stopped.emit()

    # ------------------------------------------------------------------
    def _scan_and_kill_processes(self):
        try:
            detected = self._monitor.scan()
        except Exception:
            logger.exception("process scan failed")
            return

        if not detected:
            return

        by_app: Dict[str, List[DetectedProcess]] = {}
        for dp in detected:
            by_app.setdefault(dp.matched_app, []).append(dp)

        # First pass
        killed = self._blocker.terminate_all(detected)

        kill_time = time.time()
        for dp in killed:
            self._killed_total += 1
            self.blocked_process_killed.emit(self._kill_payload(dp, kill_time))

        # Emit one violation per app
        for app_name, procs in by_app.items():
            key = f"proc:{app_name}"
            if self._check_cooldown(key, seconds=VIOLATION_COOLDOWN_SEC):
                count = len(procs)
                self.violation_detected.emit({
                    "vtype": "service",
                    "description": f"Blocked {app_name} ({count} process{'es' if count>1 else ''})",
                    "severity": "medium",
                })

        # Triple-tap: re-scan 3 times in quick succession
        # Ye respawned processes ko bhi turant maarta hai
        for i in range(TRIPLE_TAP_COUNT):
            if not self._running:
                break
            time.sleep(TRIPLE_TAP_DELAY_SEC)
            try:
                respawned = self._monitor.scan()
                if not respawned:
                    break  # kuch nahi bacha, ruk jao
                killed2 = self._blocker.terminate_all(respawned)
                kill_time2 = time.time()
                for dp in killed2:
                    self._killed_total += 1
                    self.blocked_process_killed.emit(self._kill_payload(dp, kill_time2))
            except Exception:
                logger.exception("triple-tap scan %d failed", i)

    # ------------------------------------------------------------------
    def _kill_payload(self, dp: DetectedProcess, kill_time: float) -> dict:
        """
        latency_ms = launch -> kill.  Only meaningful for apps started AFTER the engine began;
        apps that were already open when the exam started get latency None (not a fair measure).
        """
        latency = None
        if dp.started_at and dp.started_at >= self._started_wall - 0.5:
            latency = max(0, int((kill_time - dp.started_at) * 1000))
        return {"pid": dp.pid, "name": dp.name, "app": dp.matched_app, "latency_ms": latency}

    def _scan_allowlist(self):
        try:
            offenders = self._allowlist.scan()
        except Exception:
            logger.exception("allow-list scan failed")
            return
        if not offenders:
            return
        killed = self._blocker.terminate_all(offenders)
        kill_time = time.time()
        for dp in killed:
            self._killed_total += 1
            payload = self._kill_payload(dp, kill_time)
            payload["allowlist"] = True
            self.blocked_process_killed.emit(payload)
            if self._check_cooldown(f"allow:{dp.name}", seconds=VIOLATION_COOLDOWN_SEC):
                self.violation_detected.emit({
                    "vtype": "service",
                    "description": f"Closed {dp.name} (not on the allow-list)",
                    "severity": "medium",
                })

    # ------------------------------------------------------------------
    # S4: emergency override (teacher pauses blocking for this student)
    # ------------------------------------------------------------------
    @property
    def is_paused(self) -> bool:
        return self._paused

    def pause(self):
        """Stop killing apps AND release the hosts file, so the student has a normal PC."""
        with self._state_lock:
            if self._paused:
                return
            self._paused = True
            self._restore_hosts()
        self.paused_changed.emit(True)
        logger.warning("Blocking PAUSED by teacher override.")

    def resume(self):
        with self._state_lock:
            if not self._paused:
                return
            if (self._domain_blocker and self._blocked_domains
                    and self._security_options.get("block_restricted_websites", True)):
                try:
                    self._domain_blocker.apply()
                except Exception:
                    logger.exception("re-applying hosts block failed")
            self._paused = False
        self.paused_changed.emit(False)
        logger.info("Blocking RESUMED.")

    # ------------------------------------------------------------------
    def _scan_connections(self):
        try:
            suspicious = self._domain_blocker.scan_active_connections()
        except Exception:
            logger.exception("connection scan failed")
            return

        for sc in suspicious:
            self._suspicious_total += 1
            key = f"conn:{sc.process_name}:{sc.domain_hint}"
            if self._check_cooldown(key, seconds=VIOLATION_COOLDOWN_SEC):
                self.violation_detected.emit({
                    "vtype": "service",
                    "description": f"Suspicious connection to {sc.domain_hint} by {sc.process_name or 'unknown'}",
                    "severity": "high",
                })

    # ------------------------------------------------------------------
    def _check_cooldown(self, key: str, seconds: float = VIOLATION_COOLDOWN_SEC) -> bool:
        now = time.time()
        last = self._last_violation.get(key, 0.0)
        if now - last < seconds:
            return False
        self._last_violation[key] = now
        return True

    # ------------------------------------------------------------------
    def stop(self):
        """Ask the loop to exit (non-blocking)."""
        self._running = False

    def stop_and_restore(self, timeout_ms: int = 5000) -> bool:
        """
        Stop the engine and GUARANTEE the hosts file is restored.
        Called from the GUI thread on session end / disconnect / logout / close.
        If the worker thread is slow to exit, restore directly so the hosts
        file is never left blocked.
        """
        self._running = False
        finished = self.wait(timeout_ms) if self.isRunning() else True
        if not finished:
            logger.warning("BlockingEngine did not stop in %d ms - restoring hosts directly",
                           timeout_ms)
        return self._restore_hosts()

    def _restore_hosts(self) -> bool:
        ok = True
        try:
            hosts = self._hosts
            if hosts is None:
                hosts = HostsManager()          # file-based restore still works
            ok = hosts.restore()
        except Exception:
            logger.exception("hosts restore failed")
            ok = False
        return ok

    def _cleanup(self):
        self._restore_hosts()
        self._monitor = None
        self._blocker = None
        self._domain_blocker = None
        logger.info("BlockingEngine stopped.")
