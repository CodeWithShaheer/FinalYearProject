"""
webrtc/teacher_peer.py
Teacher-side WebRTC peer — one per connected student.
"""
import asyncio
import logging
from typing import Callable

from aiortc import (
    RTCPeerConnection,
    RTCSessionDescription,
    RTCIceCandidate,
    RTCConfiguration,
)

logger = logging.getLogger(__name__)


class TeacherPeer:
    def __init__(self, student_token: str,
                 on_local_sdp: Callable[[str, dict], None],
                 on_local_ice: Callable[[str, dict], None],
                 on_track_frame: Callable[[str, "object"], None]):
        self.token = student_token
        self.on_local_sdp = on_local_sdp
        self.on_local_ice = on_local_ice
        self.on_track_frame = on_track_frame

        config = RTCConfiguration(iceServers=[])
        self.pc = RTCPeerConnection(configuration=config)
        self._closed = False

        @self.pc.on("icecandidate")
        def _on_ice(candidate):
            if candidate is not None:
                try:
                    self.on_local_ice(self.token, {
                        "candidate": candidate.candidate,
                        "sdpMid": candidate.sdpMid,
                        "sdpMLineIndex": candidate.sdpMLineIndex,
                    })
                except Exception:
                    logger.exception("[TeacherPeer %s] on_local_ice failed", self.token[:8])

        @self.pc.on("track")
        async def _on_track(track):
            logger.info("[TeacherPeer %s] got %s track", self.token[:8], track.kind)
            if track.kind == "video":
                asyncio.create_task(self._consume_track(track))

        @self.pc.on("connectionstatechange")
        async def _on_state():
            logger.info("[TeacherPeer %s] connection state: %s",
                        self.token[:8], self.pc.connectionState)

        @self.pc.on("iceconnectionstatechange")
        async def _on_ice_state():
            logger.info("[TeacherPeer %s] ICE state: %s",
                        self.token[:8], self.pc.iceConnectionState)

    async def set_remote_offer(self, offer: dict):
        desc = RTCSessionDescription(sdp=offer["sdp"], type=offer["type"])
        await self.pc.setRemoteDescription(desc)
        logger.info("[TeacherPeer %s] remote offer set.", self.token[:8])

    async def create_answer(self) -> dict:
        answer = await self.pc.createAnswer()
        await self.pc.setLocalDescription(answer)
        logger.info("[TeacherPeer %s] answer created.", self.token[:8])
        return {
            "type": self.pc.localDescription.type,
            "sdp": self.pc.localDescription.sdp,
        }

    async def add_remote_ice(self, candidate: dict):
        if self._closed:
            return
        try:
            cand = RTCIceCandidate(
                candidate=candidate.get("candidate", ""),
                sdpMid=candidate.get("sdpMid"),
                sdpMLineIndex=candidate.get("sdpMLineIndex"),
            )
            await self.pc.addIceCandidate(cand)
        except Exception:
            logger.exception("[TeacherPeer %s] add_remote_ice failed", self.token[:8])

    async def _consume_track(self, track):
        try:
            while not self._closed:
                try:
                    frame = await track.recv()
                except asyncio.CancelledError:
                    break
                except Exception:
                    logger.info("[TeacherPeer %s] track ended.", self.token[:8])
                    break
                try:
                    self.on_track_frame(self.token, frame)
                except Exception:
                    logger.exception("[TeacherPeer %s] on_track_frame failed", self.token[:8])
        except asyncio.CancelledError:
            pass
        except Exception:
            logger.exception("[TeacherPeer %s] consume track crashed", self.token[:8])

    # ------------------------------------------------------------------
    # FIXED close() — swallows CancelledError
    # ------------------------------------------------------------------
    async def close(self):
        if self._closed:
            return
        self._closed = True
        try:
            await asyncio.shield(self.pc.close())
        except asyncio.CancelledError:
            logger.debug("[TeacherPeer %s] pc.close() raised CancelledError — ignored",
                         self.token[:8])
        except Exception:
            logger.exception("[TeacherPeer %s] pc.close() failed", self.token[:8])
        logger.info("[TeacherPeer %s] closed.", self.token[:8])