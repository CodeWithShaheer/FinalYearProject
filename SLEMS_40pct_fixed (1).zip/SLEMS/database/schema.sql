-- ===========================================================================
-- SLEMS - Smart Lab Exam Monitoring System
-- PostgreSQL Schema v2.0
-- ===========================================================================
-- Run this once via migrations.py (init_db()).
-- Safe to run multiple times (uses IF NOT EXISTS).
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- users: teachers, admins, student login accounts
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id              SERIAL PRIMARY KEY,
    full_name       VARCHAR(120) NOT NULL,
    email           VARCHAR(150) UNIQUE NOT NULL,
    password_hash   VARCHAR(255) NOT NULL,
    role            VARCHAR(20)  NOT NULL DEFAULT 'teacher',
    campus          VARCHAR(80)  NOT NULL DEFAULT 'Faisalabad',
    created_at      TIMESTAMP    NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_role  ON users(role);


-- ---------------------------------------------------------------------------
-- courses: teacher-managed list shown in Course dropdown
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS courses (
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(150) UNIQUE NOT NULL,
    created_at  TIMESTAMP NOT NULL DEFAULT NOW()
);


-- ---------------------------------------------------------------------------
-- sessions: exam sessions created by teacher
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sessions (
    id                  SERIAL PRIMARY KEY,
    course_name         VARCHAR(150) NOT NULL,
    exam_title          VARCHAR(150),
    duration            INTEGER NOT NULL,              -- minutes
    exam_paper          VARCHAR(500),                  -- file path
    exam_paper_size     BIGINT,                        -- bytes
    blocked_apps        TEXT,                          -- comma-separated
    blocked_domains     TEXT,                          -- comma-separated
    security_options    TEXT,                          -- JSON string
    status              VARCHAR(20) NOT NULL DEFAULT 'active',
    created_at          TIMESTAMP NOT NULL DEFAULT NOW(),
    ended_at            TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_sessions_status  ON sessions(status);
CREATE INDEX IF NOT EXISTS idx_sessions_created ON sessions(created_at DESC);


-- ---------------------------------------------------------------------------
-- students: students enrolled in a session (populated when they join)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS students (
    id          SERIAL PRIMARY KEY,
    session_id  INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    student_id  VARCHAR(40) NOT NULL,        -- e.g. FSD-FL-201
    full_name   VARCHAR(120) NOT NULL,
    roll_no     VARCHAR(40) NOT NULL,
    status      VARCHAR(20) NOT NULL DEFAULT 'active',
    created_at  TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_students_session ON students(session_id);
CREATE INDEX IF NOT EXISTS idx_students_roll    ON students(roll_no);


-- ---------------------------------------------------------------------------
-- connections: active network connections from student PCs
-- (populated in Phase 5+)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS connections (
    id              SERIAL PRIMARY KEY,
    student_id      INTEGER REFERENCES students(id) ON DELETE CASCADE,
    session_id      INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    ip_address      VARCHAR(45),
    session_token   VARCHAR(64) UNIQUE,
    status          VARCHAR(20) NOT NULL DEFAULT 'connected',
    connected_at    TIMESTAMP NOT NULL DEFAULT NOW(),
    last_heartbeat  TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_conn_token   ON connections(session_token);
CREATE INDEX IF NOT EXISTS idx_conn_session ON connections(session_id);


-- ---------------------------------------------------------------------------
-- submissions: student exam file submissions
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS submissions (
    id            SERIAL PRIMARY KEY,
    session_id    INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    student_id    INTEGER REFERENCES students(id) ON DELETE CASCADE,
    file_path     VARCHAR(500),
    file_name     VARCHAR(255),
    file_size     BIGINT,
    submitted_at  TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sub_session ON submissions(session_id);
CREATE INDEX IF NOT EXISTS idx_sub_student ON submissions(student_id);


-- ---------------------------------------------------------------------------
-- violations: AI + blocker detected violations
-- (populated in Phase 9+)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS violations (
    id              SERIAL PRIMARY KEY,
    session_id      INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    student_id      INTEGER REFERENCES students(id) ON DELETE CASCADE,
    violation_type  VARCHAR(50) NOT NULL,     -- behavioral / service
    description     TEXT,
    severity        VARCHAR(20) DEFAULT 'medium',
    "timestamp"     TIMESTAMP NOT NULL DEFAULT NOW(),
    synced          BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE INDEX IF NOT EXISTS idx_viol_session ON violations(session_id);
CREATE INDEX IF NOT EXISTS idx_viol_student ON violations(student_id);
CREATE INDEX IF NOT EXISTS idx_viol_time    ON violations("timestamp" DESC);


-- ===========================================================================
-- v2.1 additions (idempotent - safe on existing databases)
-- ===========================================================================

-- login lockout (plan AUTH-001: 5 failed attempts -> locked for 5 minutes)
ALTER TABLE users ADD COLUMN IF NOT EXISTS failed_attempts INTEGER   NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS locked_until    TIMESTAMP;

-- teacher who owns the session (plan: exam_sessions.teacher_id)
ALTER TABLE sessions ADD COLUMN IF NOT EXISTS teacher_id INTEGER REFERENCES users(id) ON DELETE SET NULL;

-- violation review workflow + AI confidence (plan: violations.confidence/reviewed/dismissed)
ALTER TABLE violations ADD COLUMN IF NOT EXISTS confidence REAL;
ALTER TABLE violations ADD COLUMN IF NOT EXISTS reviewed   BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE violations ADD COLUMN IF NOT EXISTS dismissed  BOOLEAN NOT NULL DEFAULT FALSE;

-- one student row per roll number per session (prevents duplicate joins)
CREATE UNIQUE INDEX IF NOT EXISTS uq_students_session_roll ON students(session_id, roll_no);
CREATE INDEX IF NOT EXISTS idx_viol_session_student ON violations(session_id, student_id);


-- ===========================================================================
-- v2.2 additions (idempotent)
-- ===========================================================================

-- random 6-digit join code (S7): students type this instead of the guessable session id
ALTER TABLE sessions ADD COLUMN IF NOT EXISTS join_code VARCHAR(8);
CREATE UNIQUE INDEX IF NOT EXISTS uq_sessions_join_code_active
    ON sessions(join_code) WHERE status = 'active';

-- block_events (S6): every kill / block / pause with timestamp + latency (evidence for "killed within 2 s")
CREATE TABLE IF NOT EXISTS block_events (
    id          SERIAL PRIMARY KEY,
    session_id  INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    student_id  INTEGER REFERENCES students(id) ON DELETE CASCADE,
    event_type  VARCHAR(24) NOT NULL,        -- process_killed | domain_blocked | blocking_paused | blocking_resumed | client_offline | allowlist_kill
    target      VARCHAR(255),
    pid         INTEGER,
    latency_ms  INTEGER,                      -- launch -> kill time
    detail      TEXT,
    created_at  TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_block_events_session ON block_events(session_id, created_at);

-- audit_log (S4): who did what (teacher overrides, session start / end, ...)
CREATE TABLE IF NOT EXISTS audit_log (
    id            SERIAL PRIMARY KEY,
    session_id    INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    actor_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    student_id    INTEGER REFERENCES students(id) ON DELETE SET NULL,
    action        VARCHAR(40) NOT NULL,
    detail        TEXT,
    created_at    TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_audit_session ON audit_log(session_id, created_at);

