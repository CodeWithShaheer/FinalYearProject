# MediaPipe face detection.
"""
ai/face_detector.py
Face detection using MediaPipe.

Returns:
    - number of faces in frame
    - bounding box (largest face)
    - whether a face is present at all
"""
import logging
from dataclasses import dataclass
from typing import Optional, Tuple

import cv2
import numpy as np

try:
    import mediapipe as mp
except ImportError:
    mp = None

logger = logging.getLogger(__name__)


@dataclass
class FaceInfo:
    face_count: int = 0
    box: Optional[Tuple[int, int, int, int]] = None   # x, y, w, h (largest)
    confidence: float = 0.0

    @property
    def has_face(self) -> bool:
        return self.face_count > 0


class FaceDetector:
    """MediaPipe face detection wrapper (single-shot)."""

    def __init__(self, min_detection_confidence: float = 0.5):
        if mp is None:
            raise ImportError(
                "mediapipe not installed. Run: pip install mediapipe"
            )
        self._mp_face = mp.solutions.face_detection
        self._detector = self._mp_face.FaceDetection(
            model_selection=0,
            min_detection_confidence=min_detection_confidence,
        )

    # ------------------------------------------------------------------
    def detect(self, bgr_frame: np.ndarray) -> FaceInfo:
        """
        Detect faces in a BGR frame.
        Returns FaceInfo with face_count and largest face bbox.
        """
        if bgr_frame is None:
            return FaceInfo()

        h, w = bgr_frame.shape[:2]
        rgb = cv2.cvtColor(bgr_frame, cv2.COLOR_BGR2RGB)
        try:
            result = self._detector.process(rgb)
        except Exception:
            logger.exception("FaceDetector.process failed")
            return FaceInfo()

        if not result.detections:
            return FaceInfo(face_count=0)

        # Find largest face by area
        largest = None
        largest_area = 0
        for det in result.detections:
            bbox = det.location_data.relative_bounding_box
            x = int(bbox.xmin * w)
            y = int(bbox.ymin * h)
            bw = int(bbox.width * w)
            bh = int(bbox.height * h)
            area = bw * bh
            if area > largest_area:
                largest_area = area
                largest = (x, y, bw, bh)

        return FaceInfo(
            face_count=len(result.detections),
            box=largest,
            confidence=float(result.detections[0].score[0]) if result.detections else 0.0,
        )

    # ------------------------------------------------------------------
    def close(self):
        try:
            self._detector.close()
        except Exception:
            pass