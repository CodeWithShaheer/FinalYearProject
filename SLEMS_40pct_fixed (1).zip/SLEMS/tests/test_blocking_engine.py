"""
tests/test_blocking_engine.py
Service Blocking Engine tests (main module).  Uses real child processes - no admin needed
for process killing; the hosts part uses a temp file.

    python -m pytest tests/test_blocking_engine.py -v
"""
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import psutil
from PyQt5.QtCore import QCoreApplication, QEventLoop, QTimer

from blocking.process_monitor import ProcessMonitor
from blocking.process_blocker import ProcessBlocker
from blocking.whitelist import is_whitelisted, get_app_profile
from blocking.blocking_engine import BlockingEngine

IS_WIN = os.name == "nt"


def _spawn_fake_app(tmpdir: str, friendly: str) -> subprocess.Popen:
    """Start a harmless long-running process whose name is '<friendly>(.exe)'."""
    if IS_WIN:
        exe = Path(tmpdir) / f"{friendly}.exe"
        shutil.copy(sys.executable, exe)               # python.exe copy named like the app
        return subprocess.Popen([str(exe), "-c", "import time; time.sleep(120)"])
    exe = Path(tmpdir) / friendly
    shutil.copy(shutil.which("sleep"), exe)
    return subprocess.Popen([str(exe), "120"])


def test_monitor_detects_only_blocklisted():
    with tempfile.TemporaryDirectory() as tmp:
        p = _spawn_fake_app(tmp, "discord")
        try:
            time.sleep(0.5)
            mon = ProcessMonitor()
            mon.set_blocklist(["discord"])
            pids = {d.pid for d in mon.scan()}
            assert p.pid in pids
            mon.set_blocklist(["telegram"])
            assert p.pid not in {d.pid for d in mon.scan()}
        finally:
            p.kill()


def test_blocker_kills_process():
    with tempfile.TemporaryDirectory() as tmp:
        p = _spawn_fake_app(tmp, "telegram")
        time.sleep(0.5)
        mon = ProcessMonitor()
        mon.set_blocklist(["telegram"])
        found = [d for d in mon.scan() if d.pid == p.pid]
        assert found
        assert ProcessBlocker().terminate_all(found)
        assert p.wait(timeout=3) is not None


def test_never_kills_itself_or_parent():
    """Blocklisting SLEMS's own process name must not kill SLEMS."""
    me = psutil.Process()
    mon = ProcessMonitor()
    mon.set_blocklist([me.name().lower().replace(".exe", "")])
    assert me.pid not in {d.pid for d in mon.scan()}         # monitor skips own pid
    from blocking.process_monitor import DetectedProcess
    fake = DetectedProcess(pid=me.pid, name=me.name(), matched_app="x", is_parent=True)
    assert ProcessBlocker().terminate_all([fake]) == []       # blocker refuses too
    assert psutil.pid_exists(me.pid)


def test_system_processes_are_whitelisted():
    for n in ("explorer.exe", "svchost.exe", "lsass.exe", "winlogon.exe", "python.exe"):
        assert is_whitelisted(n)
    assert not is_whitelisted("discord.exe")


def test_unknown_app_name_gets_default_profile():
    prof = get_app_profile("someapp")
    assert "someapp.exe" in prof["parent"]


def test_engine_kills_new_app_within_2_seconds():
    """Plan acceptance: blocked app is terminated within 2 s of launch."""
    app = QCoreApplication.instance() or QCoreApplication(sys.argv)
    with tempfile.TemporaryDirectory() as tmp:
        hosts = Path(tmp) / "hosts"
        hosts.write_text("127.0.0.1 localhost\n")
        events = {"violations": [], "killed": []}
        engine = BlockingEngine(blocked_apps=["whatsapp"], blocked_domains=[],
                                security_options={"block_unauthorized_apps": True})
        engine.violation_detected.connect(events["violations"].append)
        engine.blocked_process_killed.connect(events["killed"].append)
        engine.start()
        loop = QEventLoop(); QTimer.singleShot(800, loop.quit); loop.exec_()   # engine warm-up

        p = _spawn_fake_app(tmp, "whatsapp")
        t0 = time.time()
        deadline = t0 + 4
        while time.time() < deadline and p.poll() is None:
            loop = QEventLoop(); QTimer.singleShot(50, loop.quit); loop.exec_()
        took = time.time() - t0
        engine.stop_and_restore(5000)
        if p.poll() is None:
            p.kill()
            raise AssertionError("blocked app was NOT killed")
        assert took < 2.0, f"killed too slowly: {took:.2f}s"
        assert events["violations"], "no violation reported to the dashboard"
        assert events["violations"][0]["vtype"] == "service"
        lat = events["killed"][0]["latency_ms"]
        assert lat is not None and lat <= 2000, f"launch->kill latency was {lat} ms"


def test_engine_restores_hosts_even_if_stopped_abruptly():
    from blocking import blocking_engine as be
    from blocking.hosts_manager import HostsManager
    app = QCoreApplication.instance() or QCoreApplication(sys.argv)
    with tempfile.TemporaryDirectory() as tmp:
        hosts = Path(tmp) / "hosts"
        original = b"127.0.0.1 localhost\r\n"
        hosts.write_bytes(original)
        orig_cls = be.HostsManager
        be.HostsManager = lambda: HostsManager(hosts_path=str(hosts),
                                               backup_dir=Path(tmp) / "bk",
                                               state_file=Path(tmp) / "st.json")
        try:
            engine = BlockingEngine([], ["chatgpt.com"], {"block_restricted_websites": True})
            engine.start()
            loop = QEventLoop(); QTimer.singleShot(1200, loop.quit); loop.exec_()
            assert b"chatgpt.com" in hosts.read_bytes()
            engine.stop_and_restore(5000)
            assert hosts.read_bytes() == original
        finally:
            be.HostsManager = orig_cls


# --------------------------------------------------------------------------- S5 allow-list
def _fake_provider(*procs):
    pids = {p.pid for p in procs}
    return lambda: set(pids) | {os.getpid()}


def test_allowlist_only_closes_apps_that_are_not_allowed():
    from blocking.allowlist import AllowListEnforcer
    with tempfile.TemporaryDirectory() as tmp:
        ok_app = _spawn_fake_app(tmp, "editor")
        bad_app = _spawn_fake_app(tmp, "browserx")
        shell = _spawn_fake_app(tmp, "explorer")             # protected system name
        try:
            time.sleep(0.5)
            enf = AllowListEnforcer(["Editor.exe"], _fake_provider(ok_app, bad_app, shell))
            found = {d.pid for d in enf.scan()}
            assert found == {bad_app.pid}                    # not editor, not explorer, not ourselves
            assert ProcessBlocker().terminate_all(enf.scan())
            assert bad_app.wait(timeout=3) is not None
            assert ok_app.poll() is None and shell.poll() is None
        finally:
            for p in (ok_app, bad_app, shell):
                p.kill()


def test_allowlist_refuses_empty_list():
    from blocking.allowlist import AllowListEnforcer
    enf = AllowListEnforcer([], lambda: {os.getpid()})
    assert not enf.usable and enf.scan() == []


def test_engine_allowlist_mode_end_to_end():
    from blocking import blocking_engine as be
    from blocking.allowlist import AllowListEnforcer
    app = QCoreApplication.instance() or QCoreApplication(sys.argv)
    with tempfile.TemporaryDirectory() as tmp:
        ok_app = _spawn_fake_app(tmp, "editor")
        bad_app = _spawn_fake_app(tmp, "chatclient")
        time.sleep(0.5)
        orig = be.AllowListEnforcer
        be.AllowListEnforcer = lambda allowed: orig(allowed, _fake_provider(ok_app, bad_app))
        try:
            engine = BlockingEngine([], [], {"block_unauthorized_apps": False,
                                             "allowlist_mode": True, "allowed_apps": ["editor"]})
            engine.start()
            deadline = time.time() + 4
            while time.time() < deadline and bad_app.poll() is None:
                loop = QEventLoop(); QTimer.singleShot(50, loop.quit); loop.exec_()
            engine.stop_and_restore(5000)
            assert bad_app.poll() is not None, "app not on the allow-list was not closed"
            assert ok_app.poll() is None, "allowed app was closed!"
        finally:
            be.AllowListEnforcer = orig
            for p in (ok_app, bad_app):
                p.kill()


# --------------------------------------------------------------------------- S4 pause / resume
def test_pause_releases_everything_and_resume_restores_it():
    from blocking import blocking_engine as be
    from blocking.hosts_manager import HostsManager
    app = QCoreApplication.instance() or QCoreApplication(sys.argv)

    def spin(seconds):
        loop = QEventLoop(); QTimer.singleShot(int(seconds * 1000), loop.quit); loop.exec_()

    with tempfile.TemporaryDirectory() as tmp:
        hosts = Path(tmp) / "hosts"
        original = b"127.0.0.1 localhost\n"
        hosts.write_bytes(original)
        orig_cls = be.HostsManager
        be.HostsManager = lambda: HostsManager(hosts_path=str(hosts), backup_dir=Path(tmp) / "bk",
                                               state_file=Path(tmp) / "st.json")
        try:
            engine = BlockingEngine(["signal"], ["chatgpt.com"],
                                    {"block_unauthorized_apps": True, "block_restricted_websites": True})
            engine.start()
            spin(1.2)
            assert b"chatgpt.com" in hosts.read_bytes()

            engine.pause()                                    # teacher emergency override
            assert hosts.read_bytes() == original             # websites released at once
            p = _spawn_fake_app(tmp, "signal")
            spin(1.5)
            assert p.poll() is None, "app was killed while blocking was paused"

            engine.resume()
            assert b"chatgpt.com" in hosts.read_bytes()       # websites blocked again
            spin(1.5)
            assert p.poll() is not None, "app was not killed after resume"
        finally:
            engine.stop_and_restore(5000)
            be.HostsManager = orig_cls
            try:
                p.kill()
            except Exception:
                pass
        assert hosts.read_bytes() == original


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("PASS", name)
