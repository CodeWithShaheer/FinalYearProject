# PostgreSQL connection configuration.
"""
config/db_config.py
PostgreSQL connection configuration.

Reads from environment variables (loaded via .env).
"""
import os
from dataclasses import dataclass


@dataclass(frozen=True)
class DBConfig:
    host: str
    port: int
    dbname: str
    user: str
    password: str

    def dsn(self) -> str:
        """Return psycopg2 DSN string."""
        return (
            f"host={self.host} port={self.port} "
            f"dbname={self.dbname} user={self.user} "
            f"password={self.password}"
        )

    def safe_repr(self) -> str:
        """Return DSN with password masked (for logs)."""
        return (
            f"host={self.host} port={self.port} "
            f"dbname={self.dbname} user={self.user} "
            f"password=***"
        )


def load_db_config() -> DBConfig:
    """Load DB config from environment variables."""
    return DBConfig(
        host=os.getenv("DB_HOST", "localhost"),
        port=int(os.getenv("DB_PORT", "5432")),
        dbname=os.getenv("DB_NAME", "slems_db"),
        user=os.getenv("DB_USER", "slems_admin"),
        password=os.getenv("DB_PASSWORD", ""),
    )


# Singleton-style lazy config
_db_config = None


def get_db_config() -> DBConfig:
    global _db_config
    if _db_config is None:
        _db_config = load_db_config()
    return _db_config