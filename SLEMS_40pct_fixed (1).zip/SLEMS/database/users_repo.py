# User CRUD operations.
"""
database/users_repo.py
CRUD operations for the `users` table.

Passwords use bcrypt (security/password.py).  Accounts created earlier with
unsalted SHA-256 still log in and are upgraded to bcrypt automatically.
Login lockout: MAX_FAILED_ATTEMPTS wrong passwords lock the account for
LOCKOUT_MINUTES (plan task AUTH-001).
"""
import hmac
import logging
import os
from typing import Optional

import psycopg2

from database.connection import db_cursor
from database.models import User
from security.password import hash_password, verify_password, needs_rehash

logger = logging.getLogger(__name__)

MAX_FAILED_ATTEMPTS = 5
LOCKOUT_MINUTES = 5
_hash_password = hash_password          # kept for any older callers


# ---------------------------------------------------------------------------
# CREATE
# ---------------------------------------------------------------------------
VALID_ROLES = ("teacher", "admin", "student")
PRIVILEGED_ROLES = ("teacher", "admin")


def _privileged_signup_allowed(signup_key: str) -> tuple:
    """
    S9: nobody may make THEMSELVES a teacher/admin.
      * If TEACHER_SIGNUP_KEY is set in .env -> the typed key must match it.
      * If it is not set -> only the very first teacher/admin (empty system) may sign up.
    """
    expected = os.getenv("TEACHER_SIGNUP_KEY", "").strip()
    if expected:
        if hmac.compare_digest((signup_key or "").strip(), expected):
            return True, ""
        return False, "Wrong teacher sign-up key. Ask the administrator for the key."
    with db_cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM users WHERE role IN ('teacher','admin');")
        existing = cur.fetchone()[0]
    if existing == 0:
        return True, ""
    return False, ("Teacher accounts need a sign-up key. Set TEACHER_SIGNUP_KEY in .env "
                   "and enter it here.")


def register_user(
    full_name: str,
    email: str,
    password: str,
    role: str = "student",
    campus: str = "Faisalabad",
    signup_key: str = "",
) -> tuple:
    """
    Register a new user.  Students sign up freely; teacher/admin need the sign-up key.
    Returns (ok: bool, message: str).
    """
    full_name = (full_name or "").strip()
    email = (email or "").strip().lower()
    password = password or ""

    if not full_name or not email or not password:
        return False, "All fields are required."
    if len(password) < 6:
        return False, "Password must be at least 6 characters."
    role = (role or "student").strip().lower()
    if role not in VALID_ROLES:
        return False, "Unknown role."
    if role in PRIVILEGED_ROLES:
        allowed, why = _privileged_signup_allowed(signup_key)
        if not allowed:
            logger.warning("Blocked privileged sign-up for %s", email)
            return False, why

    try:
        with db_cursor(dict_cursor=True) as cur:
            cur.execute(
                """
                INSERT INTO users (full_name, email, password_hash, role, campus)
                VALUES (%s, %s, %s, %s, %s)
                RETURNING id;
                """,
                (full_name, email, _hash_password(password), role, campus),
            )
            cur.fetchone()
        logger.info("User registered: %s (role=%s)", email, role)
        return True, "Account created successfully! Please log in."
    except psycopg2.errors.UniqueViolation:
        return False, "An account with this email already exists."
    except Exception as e:
        logger.exception("Failed to register user")
        return False, f"Database error: {e}"


# ---------------------------------------------------------------------------
# READ
# ---------------------------------------------------------------------------
def login_user(email: str, password: str) -> tuple:
    """
    Authenticate a user.
    Returns (ok: bool, user_dict: Optional[dict], message: str).
    Generic error text on purpose: never reveal whether the email exists.
    """
    email = (email or "").strip().lower()
    password = password or ""

    if not email or not password:
        return False, None, "Please enter both email and password."

    generic = "Invalid email or password."
    with db_cursor(dict_cursor=True) as cur:
        cur.execute(
            """SELECT *, GREATEST(0, CEIL(EXTRACT(EPOCH FROM (locked_until - NOW())) / 60))
                          AS lock_minutes_left
               FROM users WHERE email = %s;""",
            (email,),
        )
        row = cur.fetchone()

        if not row:
            return False, None, generic

        if row.get("lock_minutes_left") and row["lock_minutes_left"] > 0:
            mins = int(row["lock_minutes_left"])
            return False, None, (f"Account locked after too many failed attempts. "
                                 f"Try again in {mins} minute(s).")

        if not verify_password(password, row["password_hash"]):
            attempts = (row.get("failed_attempts") or 0) + 1
            if attempts >= MAX_FAILED_ATTEMPTS:
                cur.execute(
                    """UPDATE users SET failed_attempts = 0,
                              locked_until = NOW() + (%s || ' minutes')::interval
                       WHERE id = %s;""",
                    (str(LOCKOUT_MINUTES), row["id"]),
                )
                logger.warning("Account locked: %s", email)
                return False, None, (f"Too many failed attempts. Account locked for "
                                     f"{LOCKOUT_MINUTES} minutes.")
            cur.execute("UPDATE users SET failed_attempts = %s WHERE id = %s;",
                        (attempts, row["id"]))
            return False, None, generic

        # success: reset counters, upgrade legacy hash
        if needs_rehash(row["password_hash"]):
            cur.execute(
                "UPDATE users SET password_hash = %s, failed_attempts = 0, locked_until = NULL WHERE id = %s;",
                (hash_password(password), row["id"]),
            )
            logger.info("Upgraded password hash for %s", email)
        else:
            cur.execute("UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = %s;",
                        (row["id"],))

    user = User.from_row(row)
    return True, user.to_public_dict(), f"Welcome back, {user.full_name}!"


def get_user_by_email(email: str) -> Optional[User]:
    with db_cursor(dict_cursor=True) as cur:
        cur.execute(
            "SELECT * FROM users WHERE email = %s;",
            ((email or "").strip().lower(),),
        )
        row = cur.fetchone()
    return User.from_row(row) if row else None


def get_user_by_id(user_id: int) -> Optional[User]:
    with db_cursor(dict_cursor=True) as cur:
        cur.execute("SELECT * FROM users WHERE id = %s;", (user_id,))
        row = cur.fetchone()
    return User.from_row(row) if row else None


def get_all_users(role: Optional[str] = None) -> list:
    with db_cursor(dict_cursor=True) as cur:
        if role:
            cur.execute("SELECT * FROM users WHERE role = %s ORDER BY full_name;", (role,))
        else:
            cur.execute("SELECT * FROM users ORDER BY full_name;")
        rows = cur.fetchall()
    return [User.from_row(r).to_public_dict() for r in rows]


def count_users() -> int:
    with db_cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM users;")
        return cur.fetchone()[0]