"""
gui/common/video_widget.py
High-performance live video widget.

v2.0 — Performance:
    - Subclasses QWidget, uses QPainter directly (no QLabel.setPixmap)
    - Drops frames if GUI thread is behind (no queue buildup)
    - Throttles to 30 fps max (video source is 15 fps anyway)
    - Preserves aspect ratio
"""
import logging

from PyQt5.QtCore import Qt, QRect, QSize, pyqtSignal, pyqtSlot, QTimer
from PyQt5.QtGui import QImage, QPainter, QColor
from PyQt5.QtWidgets import QWidget, QSizePolicy

from gui.common import theme

logger = logging.getLogger(__name__)


class VideoWidget(QWidget):
    """
    Fast video display. Emits _frame_sig (queued) to repaint on GUI thread.
    Drops frames if a previous paint is still pending.
    """

    _frame_sig = pyqtSignal(QImage)

    def __init__(self, parent=None, show_placeholder: bool = True):
        super().__init__(parent)
        self._show_placeholder = show_placeholder
        self._current: QImage = None
        self._pending: QImage = None       # slot for one pending frame
        self._paint_pending = False

        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMinimumSize(160, 120)
        self.setAttribute(Qt.WA_OpaquePaintEvent, True)

        self._placeholder_text = "Waiting for video…"

        # Cross-thread signal → GUI thread slot
        self._frame_sig.connect(self._on_frame_queued, Qt.QueuedConnection)

    # ------------------------------------------------------------------
    def set_frame(self, qimage: QImage):
        """Publish a new frame. Safe to call from any thread."""
        if qimage is None:
            return
        # If a paint is already pending, drop the older pending frame
        self._pending = qimage
        if not self._paint_pending:
            self._paint_pending = True
            self._frame_sig.emit(qimage)

    # ------------------------------------------------------------------
    @pyqtSlot(QImage)
    def _on_frame_queued(self, qimage: QImage):
        # If a newer frame arrived while we were queued, use that instead
        if self._pending is not None:
            qimage = self._pending
            self._pending = None

        self._current = qimage
        self._paint_pending = False
        self.update()

    # ------------------------------------------------------------------
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.SmoothPixmapTransform, True)
        painter.fillRect(self.rect(), QColor(theme.NAVY_DARK))

        if self._current is not None:
            # Scale keeping aspect ratio, centered
            img_size = self._current.size()
            if img_size.width() > 0 and img_size.height() > 0:
                target = self.size()
                scaled = img_size.scaled(target, Qt.KeepAspectRatio)
                x = (target.width() - scaled.width()) // 2
                y = (target.height() - scaled.height()) // 2
                target_rect = QRect(x, y, scaled.width(), scaled.height())
                painter.drawImage(target_rect, self._current)
        else:
            # Placeholder text
            painter.setPen(QColor(theme.TEXT_SECONDARY))
            painter.drawText(self.rect(), Qt.AlignCenter, self._placeholder_text)

        painter.end()

    # ------------------------------------------------------------------
    def clear_video(self, text: str = "No video"):
        self._current = None
        self._pending = None
        self._placeholder_text = text
        self.update()

    def sizeHint(self) -> QSize:
        return QSize(320, 240)