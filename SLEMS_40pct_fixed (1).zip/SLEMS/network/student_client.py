"""
network/student_client.py
Asyncio TCP client run by the student PC.

v2.0: WEBRTC_ANSWER / WEBRTC_ICE events are dispatched to a registered
handler (StudentPeer) via `set_webrtc_handler()`.
"""
import asyncio
import logging
from typing import Callable, Optional

from network import protocol as P
from config.network_config import HEARTBEAT_INTERVAL

logger = logging.getLogger(__name__)


EVT_CONNECTED       = "connected"
EVT_CONFIG_RECEIVED = "config_received"
EVT_SESSION_ENDED   = "session_ended"
EVT_DISCONNECTED    = "disconnected"
EVT_ERROR           = "error"
EVT_BLOCK_PAUSE     = "block_pause"      # teacher paused blocking for this student
EVT_BLOCK_RESUME    = "block_resume"


class StudentClient:
    def __init__(self):
        self.reader: Optional[asyncio.StreamReader] = None
        self.writer: Optional[asyncio.StreamWriter] = None

        self.token: Optional[str] = None
        self.session_id: Optional[int] = None
        self.student_db_id: Optional[int] = None
        self.course_name: str = ""
        self.exam_title: str = ""
        self.duration: int = 0

        self.blocked_apps: list = []
        self.blocked_domains: list = []
        self.security_options: dict = {}

        self._reader_task: Optional[asyncio.Task] = None
        self._heartbeat_task: Optional[asyncio.Task] = None

        self._connected = False
        self._closing = False

        self._event_cb: Optional[Callable] = None

        # ---- WebRTC handler registration ----
        # asyncio-agnostic: (kind:str, payload:dict) -> coroutine or None
        # kind in {"answer", "ice"}
        self._webrtc_handler: Optional[Callable] = None

        # ---- submission upload: waiting for ACKs from the teacher ----
        self._ack_waiters: dict = {}          # "meta" / "complete" -> Future
        self._upload_failed: Optional[str] = None

    # ==================================================================
    def on_event(self, cb: Callable):
        self._event_cb = cb

    def set_webrtc_handler(self, handler: Callable):
        """
        handler(kind: str, payload: dict)
            kind="answer" → payload is SDP dict
            kind="ice"    → payload is ICE candidate dict
        """
        self._webrtc_handler = handler

    def _emit(self, event_type: str, payload: Optional[dict] = None):
        if self._event_cb:
            try:
                self._event_cb(event_type, payload or {})
            except Exception:
                logger.exception("Event callback failed for %s", event_type)

    @property
    def is_connected(self) -> bool:
        return self._connected and self.writer is not None and not self.writer.is_closing()

    # ==================================================================
    async def connect(self, teacher_ip, teacher_port, roll_no, session_code,
                      timeout: float = 10.0) -> tuple:
        if self.is_connected:
            return False, "Already connected."

        roll_no = (roll_no or "").strip().upper()
        session_code = (session_code or "").strip()
        if not roll_no or not session_code:
            return False, "Roll number and session code are required."

        try:
            self.reader, self.writer = await asyncio.wait_for(
                asyncio.open_connection(teacher_ip, teacher_port, limit=P.MAX_MESSAGE_SIZE),
                timeout=timeout,
            )
        except asyncio.TimeoutError:
            return False, f"Connection to {teacher_ip}:{teacher_port} timed out."
        except (ConnectionError, OSError) as e:
            return False, f"Cannot connect to teacher: {e}"

        logger.info("TCP connected to %s:%s", teacher_ip, teacher_port)

        try:
            await self._send(P.encode(P.MSG_HELLO, roll_no=roll_no,
                                      session_code=session_code))

            msg = await self._read_with_timeout(timeout)
            if msg is None or msg.get("type") == P.MSG_ERROR:
                err = (msg or {}).get("message", "No response from teacher")
                await self._close_writer()
                return False, f"Rejected: {err}"
            if msg.get("type") != P.MSG_WELCOME:
                await self._close_writer()
                return False, f"Unexpected reply: {msg.get('type')}"

            self.token = msg.get("token")
            self.session_id = msg.get("session_id")
            self.student_db_id = msg.get("student_db_id")
            self.course_name = msg.get("course_name", "")
            self.exam_title = msg.get("exam_title", "")
            self.duration = int(msg.get("duration") or 0)

            await self._send(P.encode(P.MSG_JOIN, token=self.token))

            msg = await self._read_with_timeout(timeout)
            if msg is None or msg.get("type") != P.MSG_SESSION_CONFIG:
                await self._close_writer()
                return False, "Did not receive session config."

            self.blocked_apps = msg.get("blocked_apps", []) or []
            self.blocked_domains = msg.get("blocked_domains", []) or []
            self.security_options = msg.get("security_options", {}) or {}

        except Exception as e:
            logger.exception("Handshake error")
            await self._close_writer()
            return False, f"Handshake error: {e}"

        self._connected = True
        self._closing = False
        self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())
        self._reader_task = asyncio.create_task(self._reader_loop())

        self._emit(EVT_CONFIG_RECEIVED, {
            "session_id": self.session_id,
            "course_name": self.course_name,
            "exam_title": self.exam_title,
            "duration": self.duration,
            "blocked_apps": self.blocked_apps,
            "blocked_domains": self.blocked_domains,
            "security_options": self.security_options,
        })
        self._emit(EVT_CONNECTED, {
            "session_id": self.session_id,
            "roll_no": roll_no,
        })

        return True, "Connected."

    async def disconnect(self, reason: str = "user"):
        if self._closing:
            return
        self._closing = True
        try:
            if self.is_connected and self.token:
                try:
                    await self._send(P.encode(P.MSG_DISCONNECT, token=self.token))
                except Exception:
                    pass
        finally:
            await self._cancel_tasks()
            await self._close_writer()
            self._connected = False
            self._emit(EVT_DISCONNECTED, {"reason": reason})

    # ==================================================================
    async def send_violation(self, vtype, desc, severity="medium") -> bool:
        if not self.is_connected:
            return False
        try:
            await self._send(P.encode(P.MSG_VIOLATION, token=self.token,
                                      vtype=vtype, desc=desc, severity=severity))
            return True
        except Exception:
            logger.exception("send_violation failed")
            return False

    async def send_block_event(self, event_type: str, target: str = "", pid=None,
                               latency_ms=None, detail: str = "") -> bool:
        """Report a kill / block to the teacher (stored with timestamp + latency)."""
        if not self.is_connected:
            return False
        try:
            await self._send(P.encode(P.MSG_BLOCK_EVENT, token=self.token, event_type=event_type,
                                      target=target, pid=pid, latency_ms=latency_ms, detail=detail))
            return True
        except Exception:
            logger.debug("send_block_event failed", exc_info=True)
            return False

    async def send_webrtc_offer(self, sdp: dict) -> bool:
        if not self.is_connected:
            return False
        try:
            await self._send(P.encode(P.MSG_WEBRTC_OFFER, token=self.token, sdp=sdp))
            return True
        except Exception:
            logger.exception("send_webrtc_offer failed")
            return False

    async def send_webrtc_ice(self, candidate: dict) -> bool:
        if not self.is_connected:
            return False
        try:
            await self._send(P.encode(P.MSG_WEBRTC_ICE, token=self.token,
                                      candidate=candidate))
            return True
        except Exception:
            logger.exception("send_webrtc_ice failed")
            return False

    # ==================================================================
    # File submission (chunked upload to the teacher PC)
    # ==================================================================
    SUBMISSION_CHUNK_BYTES = 256 * 1024

    def _resolve_ack(self, key: str, msg: dict):
        fut = self._ack_waiters.pop(key, None)
        if fut is not None and not fut.done():
            fut.set_result(msg)

    async def _wait_ack(self, key: str, timeout: float) -> Optional[dict]:
        fut = asyncio.get_running_loop().create_future()
        self._ack_waiters[key] = fut
        try:
            return await asyncio.wait_for(fut, timeout)
        except asyncio.TimeoutError:
            return None
        finally:
            self._ack_waiters.pop(key, None)

    async def send_submission(self, file_path: str, progress_cb=None):
        """
        Upload one file to the teacher.
        Returns (ok: bool, message: str, submission_id: Optional[int]).
        progress_cb(percent:int) is called from the client's event loop thread.
        """
        import base64
        import hashlib
        import os
        if not self.is_connected:
            return False, "Not connected to the teacher.", None
        try:
            size = os.path.getsize(file_path)
            sha = hashlib.sha256()
            with open(file_path, "rb") as f:
                for block in iter(lambda: f.read(1024 * 1024), b""):
                    sha.update(block)
        except OSError as e:
            return False, f"Cannot read file: {e}", None
        if size == 0:
            return False, "The selected file is empty.", None

        chunk = self.SUBMISSION_CHUNK_BYTES
        total = (size + chunk - 1) // chunk
        digest = sha.hexdigest()
        self._upload_failed = None

        try:
            await self._send(P.encode(
                P.MSG_SUBMISSION_META, token=self.token,
                file_name=os.path.basename(file_path), file_size=size,
                total_chunks=total, file_sha256=digest))
            ack = await self._wait_ack("meta", 15)
            if ack is None:
                return False, "Teacher did not respond (timeout).", None
            if not ack.get("accepted", False):
                return False, ack.get("reason") or "Teacher rejected the file.", None
            upload_id = ack.get("upload_id", "")

            sent = 0
            with open(file_path, "rb") as f:
                for index in range(total):
                    if self._upload_failed:
                        return False, self._upload_failed, None
                    if not self.is_connected:
                        return False, "Connection lost during upload.", None
                    data = f.read(chunk)
                    await self._send(P.encode(
                        P.MSG_SUBMISSION_CHUNK, token=self.token, upload_id=upload_id,
                        chunk_index=index, total_chunks=total,
                        data=base64.b64encode(data).decode("ascii")))
                    sent += len(data)
                    if progress_cb:
                        progress_cb(int(sent * 100 / size))

            await self._send(P.encode(P.MSG_SUBMISSION_COMPLETE, token=self.token,
                                      upload_id=upload_id, file_sha256=digest))
            done = await self._wait_ack("complete", 30)
            if self._upload_failed:
                return False, self._upload_failed, None
            if done is None:
                return False, "Teacher did not confirm the upload (timeout).", None
            if done.get("submission_id") is None:
                return False, done.get("reason") or "Teacher could not save the file.", None
            return True, "File submitted to the teacher.", done.get("submission_id")
        except (ConnectionError, OSError) as e:
            return False, f"Network error during upload: {e}", None

    # ==================================================================
    async def _send(self, frame: bytes):
        if self.writer is None or self.writer.is_closing():
            raise ConnectionError("Writer closed")
        self.writer.write(frame)
        await self.writer.drain()

    async def _read_with_timeout(self, timeout: float):
        try:
            line = await asyncio.wait_for(
                self.reader.readuntil(P.FRAME_TERMINATOR), timeout=timeout
            )
        except (asyncio.TimeoutError, asyncio.IncompleteReadError,
                ConnectionError, OSError):
            return None
        try:
            return P.decode_line(line)
        except P.ProtocolError as e:
            logger.warning("Bad message: %s", e)
            return None

    async def _reader_loop(self):
        try:
            while not self._closing:
                try:
                    line = await self.reader.readuntil(P.FRAME_TERMINATOR)
                except asyncio.IncompleteReadError:
                    logger.info("Teacher closed connection.")
                    break
                except (ConnectionError, OSError) as e:
                    logger.warning("Read error: %s", e)
                    break
                except asyncio.LimitOverrunError:
                    continue

                try:
                    msg = P.decode_line(line)
                except P.ProtocolError as e:
                    logger.warning("Bad message: %s", e)
                    continue

                self._dispatch_incoming(msg)
        except asyncio.CancelledError:
            pass
        except Exception:
            logger.exception("Reader loop crashed")
        finally:
            if not self._closing:
                self._connected = False
                self._emit(EVT_DISCONNECTED, {"reason": "remote_closed"})

    def _dispatch_incoming(self, msg: dict):
        mtype = msg.get("type")

        if mtype == P.MSG_SESSION_END:
            logger.info("Teacher ended session.")
            self._emit(EVT_SESSION_ENDED, {})

        elif mtype == P.MSG_BLOCK_PAUSE:
            self._emit(EVT_BLOCK_PAUSE, {"reason": msg.get("reason", "")})

        elif mtype == P.MSG_BLOCK_RESUME:
            self._emit(EVT_BLOCK_RESUME, {})

        elif mtype == P.MSG_VIOLATION_ACK:
            logger.debug("Violation ACK: %s", msg.get("violation_id"))

        elif mtype == P.MSG_SUBMISSION_ACK:
            logger.debug("Submission ACK: %s", msg.get("submission_id"))

        elif mtype == P.MSG_SUBMISSION_ACK_META:
            self._resolve_ack("meta", msg)

        elif mtype == P.MSG_SUBMISSION_ACK_CHUNK:
            if not msg.get("ok", True):
                self._upload_failed = msg.get("reason") or "Teacher rejected a chunk."

        elif mtype == P.MSG_SUBMISSION_ACK_COMPLETE:
            self._resolve_ack("complete", msg)

        elif mtype == P.MSG_WEBRTC_ANSWER:
            self._dispatch_webrtc("answer", msg.get("sdp"))

        elif mtype == P.MSG_WEBRTC_ICE:
            self._dispatch_webrtc("ice", msg.get("candidate"))

        elif mtype == P.MSG_PING:
            pass

        elif mtype == P.MSG_ERROR:
            logger.warning("Server error: %s", msg.get("message"))
            for key in list(self._ack_waiters):          # fail any upload that is waiting
                self._resolve_ack(key, {"accepted": False, "submission_id": None,
                                        "reason": msg.get("message", "Server error")})
            self._emit(EVT_ERROR, {"message": msg.get("message", "")})

        else:
            logger.debug("Unhandled message type: %s", mtype)

    def _dispatch_webrtc(self, kind: str, payload):
        if self._webrtc_handler is None:
            return
        try:
            result = self._webrtc_handler(kind, payload)
            if asyncio.iscoroutine(result):
                asyncio.create_task(result)
        except Exception:
            logger.exception("WebRTC handler failed (%s)", kind)

    async def _heartbeat_loop(self):
        try:
            while not self._closing and self.is_connected:
                await asyncio.sleep(HEARTBEAT_INTERVAL)
                if self._closing or not self.is_connected:
                    break
                try:
                    await self._send(P.encode(P.MSG_HEARTBEAT, token=self.token))
                except Exception as e:
                    logger.warning("Heartbeat send failed: %s", e)
                    break
        except asyncio.CancelledError:
            pass
        except Exception:
            logger.exception("Heartbeat loop crashed")

    async def _cancel_tasks(self):
        for task in (self._heartbeat_task, self._reader_task):
            if task and not task.done():
                task.cancel()
                try:
                    await task
                except (asyncio.CancelledError, Exception):
                    pass
        self._heartbeat_task = None
        self._reader_task = None

    async def _close_writer(self):
        try:
            if self.writer and not self.writer.is_closing():
                self.writer.close()
                try:
                    await self.writer.wait_closed()
                except Exception:
                    pass
        except Exception:
            pass
        self.writer = None