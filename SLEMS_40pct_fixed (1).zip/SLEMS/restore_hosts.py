"""
restore_hosts.py
Emergency tool: remove the SLEMS block from the hosts file.
Run as Administrator (right-click > Run as administrator, or an elevated cmd).

    python restore_hosts.py              # remove only SLEMS entries (safe, default)
    python restore_hosts.py --reset      # replace the whole file with the Windows default
"""
import ctypes
import os
import shutil
import subprocess
import sys
from pathlib import Path

HOSTS_PATH = Path(r"C:\Windows\System32\drivers\etc\hosts")

DEFAULT_HOSTS = """# Copyright (c) 1993-2009 Microsoft Corp.
#
# This is a sample HOSTS file used by Microsoft TCP/IP for Windows.
#
# localhost name resolution is handled within DNS itself.
#\t127.0.0.1       localhost
#\t::1             localhost
"""


def is_admin() -> bool:
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except Exception:
        return False


def main() -> int:
    reset = "--reset" in sys.argv
    hosts = Path(os.environ.get("SLEMS_HOSTS_PATH", HOSTS_PATH))   # override for testing

    if os.name == "nt" and not is_admin():
        print("ERROR: run this script as Administrator.")
        return 1

    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from blocking.hosts_manager import HostsManager, has_slems_block

    mgr = HostsManager(hosts_path=str(hosts))
    current = mgr._read_hosts()

    backup = hosts.with_name("hosts.before_slems_restore")
    try:
        shutil.copy2(hosts, backup)
        print(f"Saved a copy of the current file to {backup}")
    except Exception as e:
        print(f"(could not save a copy: {e})")

    if reset:
        ok = mgr._write_hosts(DEFAULT_HOSTS)
        print("Hosts file reset to the Windows default." if ok else "FAILED to write hosts file.")
    elif has_slems_block(current):
        ok = mgr.restore()
        print("SLEMS entries removed." if ok else "FAILED to remove SLEMS entries.")
    else:
        ok = True
        print("No SLEMS entries found - hosts file is already clean.")

    if ok and os.name == "nt":
        subprocess.run(["ipconfig", "/flushdns"], check=False)
        print("DNS cache flushed. Restart your browser if a site still looks blocked.")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
