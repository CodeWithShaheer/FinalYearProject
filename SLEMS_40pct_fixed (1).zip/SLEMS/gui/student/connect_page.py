"""
gui/student/connect_page.py
Student connection page - teacher IP + session code + roll no.

Robustness:
    - Discovery worker never crashes the app; errors are reported via signals.
    - If the UDP port is busy, the user sees a clear message.
"""
import asyncio
import logging

from PyQt5.QtCore import QRegExp
from PyQt5.QtGui import QRegExpValidator
from PyQt5.QtCore import Qt, pyqtSignal, QThread
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QFrame, QMessageBox, QGraphicsDropShadowEffect,
)
from PyQt5.QtGui import QColor

from gui.common import theme
from config.network_config import TEACHER_TCP_PORT
from network.discovery import discover_teacher


logger = logging.getLogger(__name__)


def _drop_shadow(blur=20, y_offset=4):
    eff = QGraphicsDropShadowEffect()
    eff.setBlurRadius(blur)
    eff.setOffset(0, y_offset)
    eff.setColor(QColor(16, 24, 40, 40))
    return eff


# ---------------------------------------------------------------------------
# Worker thread for UDP discovery
# ---------------------------------------------------------------------------
class DiscoveryWorker(QThread):
    found = pyqtSignal(str)
    not_found = pyqtSignal()
    failed = pyqtSignal(str)

    def __init__(self, timeout=5.0, parent=None):
        super().__init__(parent)
        self.timeout = timeout

    def run(self):
        loop = None
        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            ip = loop.run_until_complete(discover_teacher(timeout=self.timeout))
            if ip:
                self.found.emit(ip)
            else:
                self.not_found.emit()
        except Exception as e:
            logger.exception("Discovery worker failed")
            try:
                self.failed.emit(str(e))
            except Exception:
                pass
        finally:
            if loop is not None:
                try:
                    loop.close()
                except Exception:
                    pass


# ---------------------------------------------------------------------------
# Connect page
# ---------------------------------------------------------------------------
class StudentConnectPage(QWidget):
    connect_requested = pyqtSignal(str, int, str, str)

    def __init__(self, student_info: dict, parent=None):
        super().__init__(parent)
        self.student_info = student_info or {}
        self._discovery_worker: DiscoveryWorker = None
        self._build_ui()

    # ------------------------------------------------------------------
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setAlignment(Qt.AlignCenter)
        root.setContentsMargins(40, 40, 40, 40)

        card = QFrame()
        card.setFixedWidth(560)
        card.setStyleSheet(f"""
            QFrame {{
                background: {theme.CARD_BG};
                border: 1px solid {theme.BORDER};
                border-radius: 18px;
            }}
        """)
        card.setGraphicsEffect(_drop_shadow(blur=28, y_offset=6))

        layout = QVBoxLayout(card)
        layout.setContentsMargins(36, 32, 36, 32)
        layout.setSpacing(16)

        title = QLabel("Join Exam Session")
        title.setStyleSheet(f"color: {theme.NAVY_DARK}; font-size: 26px; font-weight: 800;")
        layout.addWidget(title)

        subtitle = QLabel(
            "Enter the session details provided by your invigilator, "
            "or use Auto-Discover to find the teacher on your LAN."
        )
        subtitle.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 14px;")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)
        layout.addSpacing(6)

        # Teacher IP
        lbl_ip = QLabel("Teacher IP Address")
        lbl_ip.setStyleSheet(f"color: {theme.TEXT_PRIMARY}; font-size: 13px; font-weight: 700;")
        layout.addWidget(lbl_ip)

        ip_row = QHBoxLayout()
        self.ip_input = QLineEdit()
        self.ip_input.setPlaceholderText("e.g. 192.168.1.5")
        self.ip_input.setMinimumHeight(46)
        self.ip_input.setStyleSheet(self._input_style())
        ip_row.addWidget(self.ip_input, stretch=1)

        self.discover_btn = QPushButton("Auto-Discover")
        self.discover_btn.setMinimumHeight(46)
        self.discover_btn.setStyleSheet(f"""
            QPushButton {{
                background: {theme.NAVY}; color: white;
                border: none; border-radius: 10px;
                padding: 10px 18px; font-size: 14px; font-weight: 700;
            }}
            QPushButton:hover {{ background: {theme.NAVY_LIGHT}; }}
            QPushButton:disabled {{ background: #B7BEC9; }}
        """)
        self.discover_btn.setCursor(Qt.PointingHandCursor)
        self.discover_btn.clicked.connect(self._on_discover)
        ip_row.addWidget(self.discover_btn)
        layout.addLayout(ip_row)

        # Session code
        lbl_code = QLabel("Session Code")
        lbl_code.setStyleSheet(f"color: {theme.TEXT_PRIMARY}; font-size: 13px; font-weight: 700;")
        layout.addWidget(lbl_code)

        self.session_input = QLineEdit()
        self.session_input.setPlaceholderText("6-digit code shown by your teacher")
        self.session_input.setMaxLength(6)
        self.session_input.setValidator(QRegExpValidator(QRegExp(r"\d{0,6}")))
        self.session_input.setMinimumHeight(46)
        self.session_input.setStyleSheet(self._input_style())
        layout.addWidget(self.session_input)

        # Roll no
        lbl_roll = QLabel("Roll Number")
        lbl_roll.setStyleSheet(f"color: {theme.TEXT_PRIMARY}; font-size: 13px; font-weight: 700;")
        layout.addWidget(lbl_roll)

        self.roll_input = QLineEdit()
        self.roll_input.setPlaceholderText("e.g. 21F-1234")
        self.roll_input.setText(self.student_info.get("roll_no", ""))
        self.roll_input.setMinimumHeight(46)
        self.roll_input.setStyleSheet(self._input_style())
        layout.addWidget(self.roll_input)

        layout.addSpacing(8)

        self.status_lbl = QLabel("")
        self.status_lbl.setStyleSheet(
            f"color: {theme.TEXT_SECONDARY}; font-size: 13px; padding: 4px;"
        )
        self.status_lbl.setAlignment(Qt.AlignCenter)
        self.status_lbl.setWordWrap(True)
        layout.addWidget(self.status_lbl)

        self.connect_btn = QPushButton("Connect to Exam")
        self.connect_btn.setMinimumHeight(56)
        self.connect_btn.setStyleSheet(f"""
            QPushButton {{
                background: {theme.GOLD}; color: {theme.NAVY_DARK};
                border: none; border-radius: 12px;
                font-size: 17px; font-weight: 700;
            }}
            QPushButton:hover {{ background: {theme.GOLD_LIGHT}; }}
            QPushButton:disabled {{ background: #B7BEC9; color: #666; }}
        """)
        self.connect_btn.setCursor(Qt.PointingHandCursor)
        self.connect_btn.clicked.connect(self._on_connect)
        layout.addWidget(self.connect_btn)

        root.addWidget(card, alignment=Qt.AlignCenter)

    @staticmethod
    def _input_style():
        return f"""
            QLineEdit {{
                border: 1px solid {theme.BORDER};
                border-radius: 10px;
                padding: 10px 14px;
                font-size: 15px;
                background: {theme.CARD_BG};
            }}
            QLineEdit:focus {{ border: 1px solid {theme.NAVY}; }}
        """

    # ------------------------------------------------------------------
    # Auto-discovery
    # ------------------------------------------------------------------
    def _on_discover(self):
        # Guard: don't start a second worker while one is running
        if self._discovery_worker is not None and self._discovery_worker.isRunning():
            self.status_lbl.setText("Discovery already running…")
            return

        self.discover_btn.setEnabled(False)
        self.status_lbl.setText("Searching for teacher on LAN…")

        self._discovery_worker = DiscoveryWorker(timeout=5.0, parent=self)
        self._discovery_worker.found.connect(self._on_discovery_found)
        self._discovery_worker.not_found.connect(self._on_discovery_not_found)
        self._discovery_worker.failed.connect(self._on_discovery_failed)
        self._discovery_worker.finished.connect(self._on_discovery_finished)
        self._discovery_worker.start()

    def _on_discovery_found(self, ip: str):
        self.ip_input.setText(ip)
        self.status_lbl.setText(f"Teacher found at {ip}. Click Connect.")

    def _on_discovery_not_found(self):
        self.status_lbl.setText(
            "No teacher found. Ensure the teacher app is running on the same LAN, "
            "or type the teacher IP manually."
        )

    def _on_discovery_failed(self, msg: str):
        self.status_lbl.setText(
            f"Discovery failed: {msg}. Please enter the teacher IP manually."
        )

    def _on_discovery_finished(self):
        self.discover_btn.setEnabled(True)
        self._discovery_worker = None

    # ------------------------------------------------------------------
    # Connect
    # ------------------------------------------------------------------
    def _on_connect(self):
        ip = self.ip_input.text().strip()
        code = self.session_input.text().strip()
        roll = self.roll_input.text().strip().upper()

        if not ip:
            QMessageBox.warning(self, "Missing IP", "Please enter the teacher's IP address.")
            return
        if not code:
            QMessageBox.warning(self, "Missing Code", "Please enter the session code.")
            return
        if not roll:
            QMessageBox.warning(self, "Missing Roll", "Please enter your roll number.")
            return

        self.connect_btn.setEnabled(False)
        self.status_lbl.setText("Connecting…")

        self.connect_requested.emit(ip, TEACHER_TCP_PORT, code, roll)

    # ------------------------------------------------------------------
    def on_connect_result(self, ok: bool, message: str):
        self.connect_btn.setEnabled(True)
        self.status_lbl.setText(message)
        if not ok:
            QMessageBox.warning(self, "Connection Failed", message)
