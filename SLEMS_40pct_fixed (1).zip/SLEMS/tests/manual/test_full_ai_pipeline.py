import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))  # run from anywhere
"""
test_full_ai_pipeline.py  (TEMPORARY)
Runs AIWorker standalone (no teacher app) and prints status + violations.
"""
import sys
import logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")

from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import QTimer

from ai.ai_worker import AIWorker


def main():
    app = QApplication(sys.argv)

    worker = AIWorker(camera_index=0, rate_hz=6.0)

    def on_status(payload):
        print(
            f"[STATUS] faces={payload['face_count']} "
            f"gaze={payload['gaze']:10s} head={payload['head']:6s} "
            f"hands={payload['hand_count']} "
            f"phone_heur={payload['phone_suspected']} "
            f"yolo_phone={payload['yolo_phone']} "
            f"dt={payload['inference_ms']:.0f}ms "
            f"signals={payload['active_signals']}"
        )

    def on_violation(event):
        vtype = getattr(event, "violation_type", "?")
        desc = getattr(event, "description", "")
        sev = getattr(event, "severity", "")
        print(f"\n>>> VIOLATION: [{sev}] {vtype} — {desc}\n")

    worker.status_update.connect(on_status)
    worker.violation_detected.connect(on_violation)
    worker.started_ok.connect(lambda: print("\n[AI] Worker started. Look away for 3 seconds to test LOOKING_AWAY.\n"))
    worker.error_occurred.connect(lambda m: print(f"[AI ERROR] {m}"))

    worker.start()

    # Auto-stop after 60s
    QTimer.singleShot(60000, lambda: (worker.stop(), app.quit()))

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()