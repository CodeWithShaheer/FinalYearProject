"""
webrtc package
Real peer-to-peer video between student (camera) and teacher (viewer).

Uses aiortc for WebRTC.
Signaling is carried over the existing TCP network layer (network/protocol.py).

No Firebase, no external STUN — LAN only.
"""