"""
tests/test_hosts_manager.py
Hosts-file blocking tests - run on any OS using a temp file (no admin needed).

    python -m pytest tests/test_hosts_manager.py -v
or  python tests/test_hosts_manager.py
"""
import os
import subprocess
import sys
import tempfile
import textwrap
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from blocking.hosts_manager import (
    HostsManager, normalize_domain, strip_slems_section,
    recover_stale_block, BLOCK_START, BLOCK_END,
)

ORIGINAL = ("# my own comment\r\n127.0.0.1 localhost\r\n"
            "192.168.1.50 myserver  # keep me\r\n")


def _make(tmp, content=ORIGINAL):
    hosts = Path(tmp) / "hosts"
    hosts.write_bytes(content.encode("latin-1"))
    mgr = HostsManager(hosts_path=str(hosts),
                       backup_dir=Path(tmp) / "bk",
                       state_file=Path(tmp) / "state.json")
    return hosts, mgr


def test_block_then_restore_is_byte_identical():
    with tempfile.TemporaryDirectory() as tmp:
        hosts, mgr = _make(tmp)
        before = hosts.read_bytes()
        assert mgr.block_domains(["youtube.com", "https://www.chatgpt.com/x"])
        text = hosts.read_text(errors="ignore")
        assert "0.0.0.0 youtube.com" in text and "0.0.0.0 chatgpt.com" in text
        assert ":: youtube.com" in text and ":: www.youtube.com" in text      # IPv6 too
        assert "192.168.1.50 myserver" in text            # user entry kept
        assert mgr.restore()
        assert hosts.read_bytes() == before               # exactly as before


def test_restore_is_idempotent():
    with tempfile.TemporaryDirectory() as tmp:
        hosts, mgr = _make(tmp)
        before = hosts.read_bytes()
        assert mgr.restore() and mgr.restore()
        assert hosts.read_bytes() == before


def test_block_twice_does_not_duplicate():
    with tempfile.TemporaryDirectory() as tmp:
        hosts, mgr = _make(tmp)
        mgr.block_domains(["a.com"])
        mgr.block_domains(["a.com", "b.com"])
        text = hosts.read_text()
        assert text.count(BLOCK_START) == 1 and text.count("0.0.0.0 a.com") == 1
        mgr.restore()
        assert BLOCK_START not in hosts.read_text()


def test_crash_then_startup_recovery():
    """Process is killed while blocking -> next start must clean the file."""
    with tempfile.TemporaryDirectory() as tmp:
        hosts, mgr = _make(tmp)
        before = hosts.read_bytes()
        code = textwrap.dedent(f"""
            import os, sys
            sys.path.insert(0, {str(Path(__file__).resolve().parent.parent)!r})
            from pathlib import Path
            from blocking.hosts_manager import HostsManager
            m = HostsManager(hosts_path={str(hosts)!r}, backup_dir=Path({tmp!r})/'bk',
                             state_file=Path({tmp!r})/'state.json')
            m.block_domains(['youtube.com'])
            os._exit(1)      # hard crash: no atexit, no finally
        """)
        subprocess.run([sys.executable, "-c", code], check=False)
        assert BLOCK_START in hosts.read_text()           # left blocked by the crash
        assert recover_stale_block(str(hosts), Path(tmp) / "state.json")
        assert hosts.read_bytes() == before


def test_missing_end_marker_does_not_eat_user_entries():
    damaged = ("127.0.0.1 localhost\n" + BLOCK_START + "\n"
               "# SLEMS blocked x\n0.0.0.0 a.com\n0.0.0.0 www.a.com\n"
               "10.0.0.5 important-server\n")
    out = strip_slems_section(damaged)
    assert "important-server" in out and "a.com" not in out and BLOCK_START not in out


def test_backup_is_clean_and_pruned():
    with tempfile.TemporaryDirectory() as tmp:
        hosts, mgr = _make(tmp)
        mgr.block_domains(["a.com"])
        for _ in range(8):
            mgr._has_backup = False
            mgr.backup()
        files = list((Path(tmp) / "bk").glob("*.txt"))
        assert 0 < len(files) <= 5
        assert all(BLOCK_START not in f.read_text() for f in files)


def test_normalize_domain():
    assert normalize_domain("HTTPS://WWW.YouTube.com/watch?v=1") == "youtube.com"
    assert normalize_domain("chat.openai.com:443") == "chat.openai.com"
    assert normalize_domain("bad domain!") is None
    assert normalize_domain("") is None


def test_missing_end_marker_also_removes_ipv6_lines():
    damaged = ("127.0.0.1 localhost\n" + BLOCK_START + "\n0.0.0.0 a.com\n:: a.com\n"
               "0.0.0.0 www.a.com\n:: www.a.com\n10.0.0.5 important-server\n")
    out = strip_slems_section(damaged)
    assert ":: " not in out and "a.com" not in out and "important-server" in out


def test_presets_cover_subdomains_and_expand_cleanly():
    from blocking.presets import DOMAIN_PRESETS, APP_PRESETS, expand_presets, preset_names
    from blocking.whitelist import APP_PROFILES
    ai = DOMAIN_PRESETS["AI assistants"]
    for host in ("chatgpt.com", "chat.openai.com", "gemini.google.com", "claude.ai"):
        assert host in ai                                   # sub-domains are listed explicitly
    for names in DOMAIN_PRESETS.values():
        for d in names:
            assert normalize_domain(d) == d, d              # every entry is a clean host name
    for names in APP_PRESETS.values():
        for a in names:
            assert a in APP_PROFILES, a                     # every app preset maps to a real profile
    apps, domains = expand_presets(["AI assistants", "AI assistants", "Messaging & chat"])
    assert len(domains) == len(set(domains)) and "discord.com" in domains
    assert set(preset_names()) >= set(DOMAIN_PRESETS)


def test_no_path_style_entries_are_offered_in_the_ui_lists():
    from config.settings import AVAILABLE_BLOCKED_DOMAINS, DEFAULT_BLOCKED_DOMAINS
    assert all("/" not in d for d in AVAILABLE_BLOCKED_DOMAINS + DEFAULT_BLOCKED_DOMAINS)


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("PASS", name)
