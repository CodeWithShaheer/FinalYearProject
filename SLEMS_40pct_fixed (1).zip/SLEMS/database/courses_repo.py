"""
database/courses_repo.py
CRUD operations for the `courses` table.

Teacher can add new courses from the Session Control page.
"""
import logging
from typing import List, Optional

import psycopg2

from database.connection import db_cursor
from database.models import Course

logger = logging.getLogger(__name__)


def add_course(name: str) -> tuple:
    """
    Add a new course.
    Returns (ok: bool, course: Optional[Course], message: str).
    """
    name = (name or "").strip()
    if not name:
        return False, None, "Course name cannot be empty."

    if len(name) > 150:
        return False, None, "Course name is too long (max 150 characters)."

    try:
        with db_cursor(dict_cursor=True) as cur:
            cur.execute(
                "INSERT INTO courses (name) VALUES (%s) RETURNING *;",
                (name,),
            )
            row = cur.fetchone()
        course = Course.from_row(row)
        logger.info("Course added: %s (id=%s)", course.name, course.id)
        return True, course, f"Course '{course.name}' added."
    except psycopg2.errors.UniqueViolation:
        return False, None, f"Course '{name}' already exists."
    except Exception as e:
        logger.exception("Failed to add course")
        return False, None, f"Database error: {e}"


def get_all_courses() -> List[Course]:
    """Return all courses ordered by name."""
    with db_cursor(dict_cursor=True) as cur:
        cur.execute("SELECT * FROM courses ORDER BY name ASC;")
        rows = cur.fetchall()
    return [Course.from_row(r) for r in rows]


def get_course_by_id(course_id: int) -> Optional[Course]:
    with db_cursor(dict_cursor=True) as cur:
        cur.execute("SELECT * FROM courses WHERE id = %s;", (course_id,))
        row = cur.fetchone()
    return Course.from_row(row) if row else None


def get_course_by_name(name: str) -> Optional[Course]:
    with db_cursor(dict_cursor=True) as cur:
        cur.execute("SELECT * FROM courses WHERE name = %s;", (name.strip(),))
        row = cur.fetchone()
    return Course.from_row(row) if row else None


def delete_course(course_id: int) -> tuple:
    """Delete a course by id. Returns (ok, message)."""
    try:
        with db_cursor() as cur:
            cur.execute("DELETE FROM courses WHERE id = %s;", (course_id,))
            deleted = cur.rowcount
        if deleted:
            return True, "Course deleted."
        return False, "Course not found."
    except Exception as e:
        logger.exception("Failed to delete course")
        return False, f"Database error: {e}"


def count_courses() -> int:
    with db_cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM courses;")
        return cur.fetchone()[0]