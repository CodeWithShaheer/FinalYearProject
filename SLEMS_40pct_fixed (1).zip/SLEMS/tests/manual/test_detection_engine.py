import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))  # run from anywhere
# test_detection_engine.py
import time
import logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")

from ai.camera import CameraCapture
from ai.detection_engine import DetectionEngine


def main():
    print("\n=== Starting camera ===")
    cam = CameraCapture(index=0, width=640, height=480, fps=15)
    if not cam.start():
        print("Camera failed to open.")
        return
    time.sleep(1.0)

    print("\n=== Initializing engine + loading YOLO (may take a few seconds) ===")
    engine = DetectionEngine(yolo_frame_interval=5, enable_yolo=True)
    loaded = engine.load()
    print(f"YOLO loaded: {loaded}")

    print("\n=== Running 25 detections (0.4s apart) ===")
    print("Instructions:")
    print("  1. Look at camera")
    print("  2. Hold a real phone near your face")
    print("  3. Put phone on table")
    print("  4. Look left, then right\n")

    for i in range(25):
        frame = cam.read()
        if frame is None:
            time.sleep(0.4)
            continue

        r = engine.detect(frame)
        phone_marker = ""
        if r.yolo_phone_present:
            phone_marker = f" 📱YOLO({r.yolo_phone_conf:.2f})"
        elif r.phone_suspected:
            phone_marker = " ⚠️HEUR"

        yolo_marker = "Y" if r.yolo_ran_this_frame else "·"

        print(
            f"[{i:02d}] dt={r.inference_ms:5.0f}ms {yolo_marker}  "
            f"faces={r.face_count}  "
            f"gaze={r.gaze_direction:10s}  "
            f"head={r.head_direction:6s}  "
            f"hands={r.hand_count}"
            f"{phone_marker}"
        )
        time.sleep(0.4)

    print("\n=== Cleanup ===")
    cam.stop()
    engine.close()
    print("Done.")


if __name__ == "__main__":
    main()