# TCP/UDP ports, timeouts and discovery settings.
"""
config/network_config.py
Network settings for teacher server + student client.

NOTE: Actual network implementation arrives in Phase 5.
This file only defines constants now.
"""
import os


# Teacher TCP server
TEACHER_TCP_PORT = int(os.getenv("TEACHER_TCP_PORT", "5555"))
TEACHER_HOST = "0.0.0.0"  # bind to all interfaces

# UDP discovery
DISCOVERY_UDP_PORT = int(os.getenv("DISCOVERY_UDP_PORT", "5556"))
DISCOVERY_BROADCAST_INTERVAL = 2  # seconds

# Timeouts
HEARTBEAT_INTERVAL = 5          # student sends every 5s
HEARTBEAT_TIMEOUT_RECONNECT = 15  # mark RECONNECTING after 15s
HEARTBEAT_TIMEOUT_OFFLINE = 60    # mark OFFLINE after 60s

# Message framing
MAX_MESSAGE_SIZE = 2 * 1024 * 1024  # 2 MB max per JSON message
# (large submission files will be chunked in Phase 12)