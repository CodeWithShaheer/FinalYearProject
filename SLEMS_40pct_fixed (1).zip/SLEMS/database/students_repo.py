# Student CRUD operations.
"""
database/students_repo.py
CRUD operations for the `students` table.

Students are added to a session when they join (Phase 5+).
For now, the Session Control "live count" uses count_by_session().
"""
import logging
from typing import List, Optional

from database.connection import db_cursor
from database.models import Student

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# CREATE
# ---------------------------------------------------------------------------
def add_student(
    session_id: int,
    student_id: str,
    full_name: str,
    roll_no: str,
    status: str = "active",
) -> tuple:
    """
    Add a student to a session.
    Returns (ok: bool, student: Optional[Student], message: str).
    """
    student_id = (student_id or "").strip()
    full_name = (full_name or "").strip()
    roll_no = (roll_no or "").strip().upper()

    if not student_id or not full_name or not roll_no:
        return False, None, "student_id, full_name, roll_no are required."

    try:
        with db_cursor(dict_cursor=True) as cur:
            cur.execute(
                """
                INSERT INTO students (session_id, student_id, full_name, roll_no, status)
                VALUES (%s, %s, %s, %s, %s)
                RETURNING *;
                """,
                (session_id, student_id, full_name, roll_no, status),
            )
            row = cur.fetchone()
        return True, Student.from_row(row), "Student added."
    except Exception as e:
        logger.exception("Failed to add student")
        return False, None, f"Database error: {e}"


# ---------------------------------------------------------------------------
# READ
# ---------------------------------------------------------------------------
def get_students_by_session(session_id: int) -> List[Student]:
    with db_cursor(dict_cursor=True) as cur:
        cur.execute(
            "SELECT * FROM students WHERE session_id = %s ORDER BY full_name ASC;",
            (session_id,),
        )
        rows = cur.fetchall()
    return [Student.from_row(r) for r in rows]


def get_student_by_roll_in_session(session_id: int, roll_no: str) -> Optional[Student]:
    with db_cursor(dict_cursor=True) as cur:
        cur.execute(
            "SELECT * FROM students WHERE session_id = %s AND roll_no = %s;",
            (session_id, roll_no.strip().upper()),
        )
        row = cur.fetchone()
    return Student.from_row(row) if row else None


def get_student_by_id(student_pk: int) -> Optional[Student]:
    with db_cursor(dict_cursor=True) as cur:
        cur.execute("SELECT * FROM students WHERE id = %s;", (student_pk,))
        row = cur.fetchone()
    return Student.from_row(row) if row else None


def get_all_students(limit: int = 500) -> List[Student]:
    with db_cursor(dict_cursor=True) as cur:
        cur.execute(
            "SELECT * FROM students ORDER BY created_at DESC LIMIT %s;",
            (limit,),
        )
        rows = cur.fetchall()
    return [Student.from_row(r) for r in rows]


# ---------------------------------------------------------------------------
# COUNT (used by Session History "Students" column)
# ---------------------------------------------------------------------------
def count_by_session(session_id: int) -> int:
    """Live student count for a session."""
    with db_cursor() as cur:
        cur.execute(
            "SELECT COUNT(*) FROM students WHERE session_id = %s;",
            (session_id,),
        )
        return cur.fetchone()[0]


# ---------------------------------------------------------------------------
# UPDATE
# ---------------------------------------------------------------------------
def update_student_status(student_pk: int, status: str) -> bool:
    try:
        with db_cursor() as cur:
            cur.execute(
                "UPDATE students SET status = %s WHERE id = %s;",
                (status, student_pk),
            )
            return cur.rowcount > 0
    except Exception:
        logger.exception("Failed to update student status")
        return False


# ---------------------------------------------------------------------------
# DELETE
# ---------------------------------------------------------------------------
def delete_student(student_pk: int) -> bool:
    try:
        with db_cursor() as cur:
            cur.execute("DELETE FROM students WHERE id = %s;", (student_pk,))
            return cur.rowcount > 0
    except Exception:
        logger.exception("Failed to delete student")
        return False


# ---------------------------------------------------------------------------
# ROSTER  (S8: only pre-registered students may join when "require roster" is on)
# ---------------------------------------------------------------------------
def parse_roster_text(text: str) -> List[tuple]:
    """
    Parse pasted / imported roster lines.  Accepts  'ROLL, Full Name'  or  'ROLL<TAB>Full Name'
    or just 'ROLL'.  Returns [(roll_no, full_name)] - duplicates and blank lines removed.
    """
    seen, out = set(), []
    for line in (text or "").splitlines():
        line = line.strip()
        if not line or line.lower().startswith(("roll", "#")):
            continue
        parts = [p.strip() for p in line.replace("\t", ",").split(",", 1)]
        roll = parts[0].upper()
        name = parts[1] if len(parts) > 1 and parts[1] else f"Student {roll}"
        if roll and roll not in seen:
            seen.add(roll)
            out.append((roll, name))
    return out


def add_roster(session_id: int, roster: List[tuple]) -> tuple:
    """Insert (roll_no, full_name) rows with status 'registered'.  Returns (ok, added_count, message)."""
    added = 0
    try:
        with db_cursor() as cur:
            for roll, name in roster:
                cur.execute(
                    """INSERT INTO students (session_id, student_id, full_name, roll_no, status)
                       VALUES (%s,%s,%s,%s,'registered')
                       ON CONFLICT (session_id, roll_no) DO NOTHING;""",
                    (session_id, roll, name, roll),
                )
                added += cur.rowcount
        return True, added, f"{added} student(s) added to the roster."
    except Exception as e:
        logger.exception("add_roster failed")
        return False, 0, f"Database error: {e}"


def mark_joined(student_pk: int) -> None:
    """Registered -> active once the student actually connects."""
    try:
        with db_cursor() as cur:
            cur.execute("UPDATE students SET status = 'active' WHERE id = %s AND status = 'registered';",
                        (student_pk,))
    except Exception:
        logger.exception("mark_joined failed")

