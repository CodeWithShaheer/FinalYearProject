"""
gui.teacher package
Teacher dashboard pages.
"""