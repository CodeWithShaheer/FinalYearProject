"""
blocking/presets.py
One-click blocklist presets (S1).

Why explicit sub-domains?  The hosts file has NO wildcards: blocking "openai.com" does not
block "chat.openai.com".  Each preset therefore lists every address students really use.
(HostsManager adds the "www." form of every entry automatically.)

Add or edit entries freely - the Session Control page builds its buttons from these dicts.
"""
from typing import Dict, Iterable, List, Tuple

# ---------------------------------------------------------------- websites
DOMAIN_PRESETS: Dict[str, List[str]] = {
    "AI assistants": [
        "chatgpt.com", "chat.openai.com", "openai.com", "api.openai.com",
        "claude.ai", "gemini.google.com", "bard.google.com", "aistudio.google.com",
        "copilot.microsoft.com", "copilot.github.com", "perplexity.ai",
        "poe.com", "character.ai", "you.com", "deepseek.com", "chat.deepseek.com",
        "grok.com", "meta.ai", "chat.mistral.ai", "phind.com", "blackbox.ai",
        "cursor.com", "cursor.sh", "codeium.com", "huggingface.co",
    ],
    "Messaging & chat": [
        "web.whatsapp.com", "whatsapp.com", "web.telegram.org", "telegram.org", "t.me",
        "discord.com", "discordapp.com", "messenger.com", "web.skype.com", "skype.com",
        "signal.org", "slack.com", "app.slack.com",
    ],
    "Remote desktop & tunnels": [
        "teamviewer.com", "anydesk.com", "remotedesktop.google.com", "parsec.app",
        "splashtop.com", "rustdesk.com", "ngrok.com", "ngrok.io", "zoom.us",
    ],
    "Homework & Q&A sites": [
        "stackoverflow.com", "stackexchange.com", "quora.com", "chegg.com",
        "coursehero.com", "brainly.com", "quizlet.com", "photomath.com",
        "mathway.com", "wolframalpha.com", "symbolab.com",
    ],
    "Tutorial & reference sites": [
        "geeksforgeeks.org", "w3schools.com", "tutorialspoint.com", "javatpoint.com",
        "programiz.com", "baeldung.com", "freecodecamp.org", "realpython.com",
    ],
    "Code hosting & online IDEs": [
        "github.com", "gist.github.com", "raw.githubusercontent.com", "gitlab.com",
        "bitbucket.org", "replit.com", "colab.research.google.com", "kaggle.com",
        "codepen.io", "jsfiddle.net", "codesandbox.io", "pastebin.com", "onlinegdb.com",
    ],
    "Cloud storage & file sharing": [
        "drive.google.com", "dropbox.com", "onedrive.live.com", "mega.nz",
        "wetransfer.com", "mediafire.com", "sendspace.com",
    ],
}

# ---------------------------------------------------------------- applications
# values are friendly names that exist in blocking.whitelist.APP_PROFILES
APP_PRESETS: Dict[str, List[str]] = {
    "AI assistants": ["chatgpt", "claude", "gemini", "copilot", "perplexity", "cursor",
                      "ollama", "lm studio", "jan", "gpt4all", "bard", "character ai", "poe"],
    "Messaging & chat": ["whatsapp", "telegram", "discord", "skype", "signal", "slack",
                         "teams", "messenger", "zoom"],
    "Remote desktop & tunnels": ["teamviewer", "anydesk", "chrome remote", "rdp", "vnc",
                                 "supremo", "ammyy", "logmein", "gotomypc", "dwservice"],
    "Homework & Q&A sites": ["chegg", "coursehero", "brainly", "quizlet", "photomath",
                             "mathway", "symbolab", "wolframalpha"],
    "Screen recorders & VMs": ["obs", "bandicam", "camtasia", "fraps", "sharex", "loom",
                               "virtualbox", "vmware", "hyper-v", "wsl", "docker"],
}


def preset_names() -> List[str]:
    """Names shown as buttons (union of domain and app presets, stable order)."""
    names = list(DOMAIN_PRESETS)
    names += [n for n in APP_PRESETS if n not in names]
    return names


def expand_presets(names: Iterable[str]) -> Tuple[List[str], List[str]]:
    """Return (apps, domains) for the chosen preset names, without duplicates."""
    apps: List[str] = []
    domains: List[str] = []
    for n in names:
        for a in APP_PRESETS.get(n, []):
            if a not in apps:
                apps.append(a)
        for d in DOMAIN_PRESETS.get(n, []):
            if d not in domains:
                domains.append(d)
    return apps, domains


def all_domains() -> List[str]:
    out: List[str] = []
    for lst in DOMAIN_PRESETS.values():
        for d in lst:
            if d not in out:
                out.append(d)
    return out
