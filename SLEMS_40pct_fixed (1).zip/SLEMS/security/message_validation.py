"""
security/message_validation.py
Validate incoming network messages.

Rules:
  - Message must have a known 'type'.
  - Required fields must be present and of expected type.
  - Messages other than HELLO must carry a valid session token.
  - Unknown / malformed messages are rejected (caller sends ERROR).

This module is used by teacher_server.py before routing.
"""
import logging
from typing import Any, Dict, Optional, Tuple

from network.protocol import (
    STUDENT_TO_TEACHER,
    MSG_HELLO, MSG_JOIN, MSG_HEARTBEAT, MSG_VIOLATION,
    MSG_SUBMISSION_META, MSG_SUBMISSION_CHUNK, MSG_SUBMISSION_COMPLETE, MSG_BLOCK_EVENT,
    MSG_WEBRTC_OFFER, MSG_WEBRTC_ICE, MSG_DISCONNECT,
)
from security.session_security import validate_token

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Required fields per message type
# ---------------------------------------------------------------------------
REQUIRED_FIELDS = {
    MSG_HELLO:            ["roll_no", "session_code"],
    MSG_JOIN:             ["token"],
    MSG_HEARTBEAT:        ["token"],
    MSG_VIOLATION:        ["token", "vtype"],
    MSG_SUBMISSION_META:  ["token", "file_name", "file_size"],
    MSG_SUBMISSION_CHUNK: ["token", "upload_id", "chunk_index", "data"],
    MSG_SUBMISSION_COMPLETE: ["token", "upload_id"],
    MSG_BLOCK_EVENT:      ["token", "event_type"],
    MSG_WEBRTC_OFFER:     ["token", "sdp"],
    MSG_WEBRTC_ICE:       ["token", "candidate"],
    MSG_DISCONNECT:       ["token"],
}

# Message types that do NOT require a token
TOKENLESS = {MSG_HELLO}


class ValidationError(Exception):
    """Raised when a message fails validation."""
    pass


def validate_message(msg: Dict[str, Any]) -> Tuple[Optional[dict], Optional[str]]:
    """
    Validate an incoming student message.

    Returns:
        (token_meta, None)         if valid — token_meta is None for HELLO
        (None, error_string)       if invalid
    """
    if not isinstance(msg, dict):
        return None, "Message must be a JSON object"

    msg_type = msg.get("type")
    if not isinstance(msg_type, str):
        return None, "Missing or invalid 'type' field"

    if msg_type not in STUDENT_TO_TEACHER:
        return None, f"Unknown message type: {msg_type}"

    # Check required fields
    required = REQUIRED_FIELDS.get(msg_type, [])
    for field in required:
        if field not in msg or msg[field] in (None, ""):
            return None, f"Missing required field '{field}' for {msg_type}"

    # Token check (all except HELLO)
    if msg_type not in TOKENLESS:
        token = msg.get("token", "")
        if not isinstance(token, str) or not token:
            return None, "Missing or invalid token"
        meta = validate_token(token)
        if meta is None:
            return None, "Invalid or expired session token"
        return meta, None

    # HELLO — no token required
    return None, None


# ---------------------------------------------------------------------------
# Field-level helpers
# ---------------------------------------------------------------------------
def is_valid_hello(msg: Dict[str, Any]) -> bool:
    return (
        isinstance(msg.get("roll_no"), str) and msg["roll_no"].strip()
        and (isinstance(msg.get("session_code"), (str, int)))
        and str(msg["session_code"]).strip()
    )


def is_valid_violation(msg: Dict[str, Any]) -> bool:
    vtype = msg.get("vtype", "")
    if vtype not in ("behavioral", "service"):
        return False
    return True


def is_valid_submission_chunk(msg: Dict[str, Any]) -> bool:
    try:
        idx = int(msg.get("chunk_index", -1))
        if idx < 0:
            return False
        data = msg.get("data")
        if not isinstance(data, str):
            return False
        return True
    except (ValueError, TypeError):
        return False


def is_valid_webrtc_offer(msg: Dict[str, Any]) -> bool:
    sdp = msg.get("sdp")
    return isinstance(sdp, dict) and "type" in sdp and "sdp" in sdp


def is_valid_webrtc_ice(msg: Dict[str, Any]) -> bool:
    cand = msg.get("candidate")
    return isinstance(cand, dict)