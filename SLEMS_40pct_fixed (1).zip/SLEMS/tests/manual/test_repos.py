import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))  # run from anywhere
# test_repos.py  (temporary — delete after testing)
import logging
logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

from dotenv import load_dotenv
load_dotenv()

from database.migrations import init_db
from database import courses_repo, sessions_repo, students_repo, submissions_repo, violations_repo, users_repo

print("\n=== 0. Init DB ===")
init_db()

print("\n=== 1. Courses ===")
courses = courses_repo.get_all_courses()
print(f"Total courses: {len(courses)}")
for c in courses[:3]:
    print(f"  - {c.id}: {c.name}")

# Add a new course
ok, new_course, msg = courses_repo.add_course("Compiler Construction")
print(f"Add course: ok={ok} msg={msg}")

# Duplicate test
ok, _, msg = courses_repo.add_course("Compiler Construction")
print(f"Duplicate: ok={ok} msg={msg}")

print("\n=== 2. Sessions ===")
ok, session, msg = sessions_repo.create_session(
    course_name="Operating Systems",
    exam_title="Lab Final Examination",
    duration_minutes=90,
    exam_paper_path="C:/fake/path/exam.pdf",
    exam_paper_size=2730000,
    blocked_apps=["ChatGPT", "WhatsApp", "Discord"],
    blocked_domains=["chatgpt.com", "gemini.google.com"],
    security_options={
        "block_unauthorized_apps": True,
        "block_restricted_websites": True,
        "monitor_student_screens": True,
        "detect_suspicious_behavior": True,
        "monitor_student_connection": True,
        "enable_kiosk_mode": False,
    },
)
print(f"Create session: ok={ok} msg={msg}")
if session:
    print(f"  Session ID: {session.id}")
    print(f"  Course: {session.course_name}")
    print(f"  Exam Title: {session.exam_title}")
    print(f"  Duration: {session.duration} min")
    print(f"  Blocked Apps: {session.blocked_apps}")
    print(f"  Blocked Domains: {session.blocked_domains}")
    print(f"  Security: {session.security_options}")

# Test active session
active = sessions_repo.get_active_session()
print(f"Active session: #{active.id if active else 'None'}")

# Test sessions with student count
with_count = sessions_repo.get_sessions_with_student_count()
print(f"Sessions with student count: {[(s.id, s.course_name, s.student_count) for s in with_count]}")

print("\n=== 3. Students ===")
if session:
    ok, stu, msg = students_repo.add_student(
        session_id=session.id,
        student_id="FSD-FL-201",
        full_name="Ali Raza",
        roll_no="21F-1234",
    )
    print(f"Add student: ok={ok} msg={msg}")

    count = students_repo.count_by_session(session.id)
    print(f"Student count for session {session.id}: {count}")

    students = students_repo.get_students_by_session(session.id)
    print(f"Students: {[(s.roll_no, s.full_name) for s in students]}")

print("\n=== 4. Users ===")
ok, msg = users_repo.register_user("Test Teacher", "test@numl.edu.pk", "password123", role="teacher")
print(f"Register: ok={ok} msg={msg}")

ok, user, msg = users_repo.login_user("test@numl.edu.pk", "password123")
print(f"Login: ok={ok} msg={msg} user={user}")

print("\n=== 5. Submissions ===")
if session and session.id:
    # Get the student we added
    students = students_repo.get_students_by_session(session.id)
    if students:
        stu = students[0]
        ok, sub, msg = submissions_repo.upsert_submission(
            session_id=session.id,
            student_id=stu.id,
            file_path="C:/fake/submission.docx",
            file_name="submission.docx",
        )
        print(f"Upsert submission: ok={ok} msg={msg}")

        stats = submissions_repo.get_submission_stats(session.id)
        print(f"Stats: {stats}")

print("\n=== 6. Violations ===")
if session and session.id:
    students = students_repo.get_students_by_session(session.id)
    if students:
        stu = students[0]
        ok, viol, msg = violations_repo.add_violation(
            session_id=session.id,
            student_id=stu.id,
            violation_type="behavioral",
            description="Looking away from screen repeatedly",
            severity="high",
        )
        print(f"Add violation: ok={ok} msg={msg}")

        count = violations_repo.count_violations_by_session(session.id)
        print(f"Violations for session: {count}")

print("\n=== 7. End Session ===")
if session:
    ok, msg = sessions_repo.end_session(session.id)
    print(f"End session: ok={ok} msg={msg}")

print("\n=== ALL TESTS COMPLETED ===")