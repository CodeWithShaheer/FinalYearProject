"""
gui package
All PyQt5 user interface code.
"""