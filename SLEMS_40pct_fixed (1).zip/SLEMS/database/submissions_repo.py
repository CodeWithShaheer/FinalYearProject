# Submission CRUD operations.
"""
database/submissions_repo.py
CRUD operations for the `submissions` table.
"""
import logging
import os
from typing import List, Optional

from database.connection import db_cursor
from database.models import Submission

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# CREATE
# ---------------------------------------------------------------------------
def add_submission(
    session_id: int,
    student_id: int,
    file_path: str,
    file_name: str,
) -> tuple:
    """
    Add a submission. Returns (ok: bool, submission: Optional[Submission], message: str).
    """
    file_size = 0
    try:
        if file_path and os.path.exists(file_path):
            file_size = os.path.getsize(file_path)
    except OSError:
        pass

    try:
        with db_cursor(dict_cursor=True) as cur:
            cur.execute(
                """
                INSERT INTO submissions (session_id, student_id, file_path, file_name, file_size)
                VALUES (%s, %s, %s, %s, %s)
                RETURNING *;
                """,
                (session_id, student_id, file_path, file_name, file_size),
            )
            row = cur.fetchone()
        return True, Submission.from_row(row), "Submission saved."
    except Exception as e:
        logger.exception("Failed to add submission")
        return False, None, f"Database error: {e}"


def upsert_submission(
    session_id: int,
    student_id: int,
    file_path: str,
    file_name: str,
) -> tuple:
    """
    If submission exists for (session, student), update it.
    Otherwise insert new. Returns (ok, submission, message).
    """
    existing = get_submission_by_student(session_id, student_id)
    if existing:
        try:
            with db_cursor(dict_cursor=True) as cur:
                cur.execute(
                    """
                    UPDATE submissions
                    SET file_path = %s, file_name = %s, file_size = %s,
                        submitted_at = NOW()
                    WHERE id = %s
                    RETURNING *;
                    """,
                    (file_path, file_name,
                     os.path.getsize(file_path) if os.path.exists(file_path) else 0,
                     existing.id),
                )
                row = cur.fetchone()
            return True, Submission.from_row(row), "Submission updated."
        except Exception as e:
            logger.exception("Failed to update submission")
            return False, None, f"Database error: {e}"
    return add_submission(session_id, student_id, file_path, file_name)


# ---------------------------------------------------------------------------
# READ
# ---------------------------------------------------------------------------
def get_submission_by_student(session_id: int, student_id: int) -> Optional[Submission]:
    with db_cursor(dict_cursor=True) as cur:
        cur.execute(
            "SELECT * FROM submissions WHERE session_id = %s AND student_id = %s LIMIT 1;",
            (session_id, student_id),
        )
        row = cur.fetchone()
    return Submission.from_row(row) if row else None


def get_submissions_by_session(session_id: int) -> List[Submission]:
    """Return submissions for a session with joined student info."""
    with db_cursor(dict_cursor=True) as cur:
        cur.execute(
            """
            SELECT sub.*,
                   st.full_name AS student_name,
                   st.roll_no   AS roll_no
            FROM submissions sub
            JOIN students st ON sub.student_id = st.id
            WHERE sub.session_id = %s
            ORDER BY sub.submitted_at DESC;
            """,
            (session_id,),
        )
        rows = cur.fetchall()
    return [Submission.from_row(r) for r in rows]


def get_all_submissions(limit: int = 500) -> List[Submission]:
    with db_cursor(dict_cursor=True) as cur:
        cur.execute(
            """
            SELECT sub.*,
                   st.full_name AS student_name,
                   st.roll_no   AS roll_no
            FROM submissions sub
            JOIN students st ON sub.student_id = st.id
            ORDER BY sub.submitted_at DESC
            LIMIT %s;
            """,
            (limit,),
        )
        rows = cur.fetchall()
    return [Submission.from_row(r) for r in rows]


# ---------------------------------------------------------------------------
# STATS
# ---------------------------------------------------------------------------
def get_submission_stats(session_id: Optional[int] = None) -> dict:
    """
    Returns {total, submitted, remaining} for a session (or globally).
    """
    with db_cursor() as cur:
        if session_id:
            cur.execute("SELECT COUNT(*) FROM students WHERE session_id = %s;", (session_id,))
            total = cur.fetchone()[0]
            cur.execute(
                "SELECT COUNT(DISTINCT student_id) FROM submissions WHERE session_id = %s;",
                (session_id,),
            )
            submitted = cur.fetchone()[0]
        else:
            cur.execute("SELECT COUNT(*) FROM students;")
            total = cur.fetchone()[0]
            cur.execute("SELECT COUNT(DISTINCT student_id) FROM submissions;")
            submitted = cur.fetchone()[0]

    return {
        "total": total,
        "submitted": submitted,
        "remaining": max(0, total - submitted),
    }