"""
database/audit_repo.py
Audit trail of teacher actions (S4): pausing / resuming blocking for a student,
starting / ending sessions.  Every override is recorded with who, when and why.
"""
import logging
from dataclasses import dataclass
from datetime import datetime
from typing import List, Optional

from database.connection import db_cursor

logger = logging.getLogger(__name__)


@dataclass
class AuditEntry:
    id: int
    session_id: Optional[int]
    actor_user_id: Optional[int]
    student_id: Optional[int]
    action: str
    detail: str
    created_at: Optional[datetime]
    actor_name: str = ""
    roll_no: str = ""


def log(action: str, session_id: Optional[int] = None, actor_user_id: Optional[int] = None,
        student_id: Optional[int] = None, detail: str = "") -> bool:
    try:
        with db_cursor() as cur:
            cur.execute(
                """INSERT INTO audit_log (session_id, actor_user_id, student_id, action, detail)
                   VALUES (%s,%s,%s,%s,%s);""",
                (session_id, actor_user_id, student_id, action[:40], detail or ""),
            )
        return True
    except Exception:
        logger.exception("audit log failed")
        return False


def get_entries(session_id: Optional[int] = None, limit: int = 500) -> List[AuditEntry]:
    where, params = "", []
    if session_id is not None:
        where, params = "WHERE a.session_id = %s", [session_id]
    params.append(limit)
    with db_cursor(dict_cursor=True) as cur:
        cur.execute(
            f"""SELECT a.*, u.full_name AS actor_name, st.roll_no AS roll_no
                FROM audit_log a
                LEFT JOIN users u ON a.actor_user_id = u.id
                LEFT JOIN students st ON a.student_id = st.id
                {where} ORDER BY a.created_at DESC, a.id DESC LIMIT %s;""", params)
        rows = cur.fetchall()
    return [AuditEntry(r["id"], r["session_id"], r["actor_user_id"], r["student_id"],
                       r["action"], r["detail"] or "", r["created_at"],
                       r["actor_name"] or "", r["roll_no"] or "") for r in rows]
