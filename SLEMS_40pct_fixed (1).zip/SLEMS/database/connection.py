"""
database/connection.py
PostgreSQL connection helper.

Uses psycopg2 with a simple context manager.
For FYP scale (30 students, 1 teacher), a full pool is overkill —
we open short-lived connections per query.
"""
import contextlib
import logging
from typing import Optional

import psycopg2
from psycopg2 import pool as pg_pool
from psycopg2.extras import RealDictCursor

from config.db_config import get_db_config

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Simple connection pool (thread-safe, max 10 connections)
# ---------------------------------------------------------------------------
_pool: Optional[pg_pool.SimpleConnectionPool] = None


def _get_pool() -> pg_pool.SimpleConnectionPool:
    global _pool
    if _pool is None:
        cfg = get_db_config()
        try:
            _pool = pg_pool.SimpleConnectionPool(
                minconn=1,
                maxconn=10,
                host=cfg.host,
                port=cfg.port,
                dbname=cfg.dbname,
                user=cfg.user,
                password=cfg.password,
            )
            logger.info("PostgreSQL pool created: %s", cfg.safe_repr())
        except psycopg2.OperationalError as e:
            logger.error("Failed to create PostgreSQL pool: %s", e)
            raise
    return _pool


def get_connection():
    """Get a raw connection from the pool. Caller must close it."""
    return _get_pool().getconn()


def release_connection(conn):
    """Return connection to pool."""
    try:
        _get_pool().putconn(conn)
    except Exception:
        logger.exception("Failed to release connection")


@contextlib.contextmanager
def db_cursor(dict_cursor: bool = False):
    """
    Context manager yielding a cursor.

    Usage:
        with db_cursor() as cur:
            cur.execute("SELECT ...")
            rows = cur.fetchall()
    """
    conn = get_connection()
    try:
        cursor_factory = RealDictCursor if dict_cursor else None
        cur = conn.cursor(cursor_factory=cursor_factory)
        try:
            yield cur
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            cur.close()
    finally:
        release_connection(conn)


def test_connection() -> tuple:
    """
    Test DB connectivity.
    Returns (ok: bool, message: str).
    """
    try:
        with db_cursor() as cur:
            cur.execute("SELECT version();")
            version = cur.fetchone()[0]
        return True, f"Connected: {version[:60]}..."
    except Exception as e:
        return False, f"Connection failed: {e}"


def close_pool():
    """Close the pool (call on app shutdown)."""
    global _pool
    if _pool is not None:
        _pool.closeall()
        _pool = None
        logger.info("PostgreSQL pool closed.")