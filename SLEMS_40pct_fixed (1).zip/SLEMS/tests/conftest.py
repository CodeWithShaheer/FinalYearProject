# pytest config: hardware / Windows-only scripts are run by hand, not by pytest.
collect_ignore = ["manual"]
