# Manages multiple student peers.
"""
webrtc/peer_manager.py
Teacher-side manager: one TeacherPeer per connected student.

Provides async methods called from the TeacherServer / NetworkBridge:
    - handle_offer(token, sdp)       → creates peer if needed, sets offer,
                                        returns answer dict
    - handle_ice(token, candidate)   → forwards ICE to correct peer
    - remove(token)                  → closes peer on student disconnect
    - close_all()                    → shutdown
"""
import asyncio
import logging
from typing import Callable, Dict, Optional

from webrtc.teacher_peer import TeacherPeer

logger = logging.getLogger(__name__)


class TeacherPeerManager:
    def __init__(
        self,
        on_local_sdp: Callable[[str, dict], None],
        on_local_ice: Callable[[str, dict], None],
        on_track_frame: Callable[[str, "object"], None],
    ):
        """
        All three callbacks are expected to forward data to the student
        (via TCP) or to the GUI (via Qt signal marshalling by the caller).
        """
        self.on_local_sdp = on_local_sdp
        self.on_local_ice = on_local_ice
        self.on_track_frame = on_track_frame

        self._peers: Dict[str, TeacherPeer] = {}

    # ------------------------------------------------------------------
    # Offer / ICE
    # ------------------------------------------------------------------
    async def handle_offer(self, token: str, sdp: dict) -> Optional[dict]:
        """
        Handle an incoming SDP offer from a student.
        Returns the SDP answer dict (caller sends it back), or None on failure.
        """
        # Close existing peer for this token (renegotiation)
        if token in self._peers:
            try:
                await self._peers[token].close()
            except Exception:
                pass
            self._peers.pop(token, None)

        peer = TeacherPeer(
            student_token=token,
            on_local_sdp=self.on_local_sdp,
            on_local_ice=self.on_local_ice,
            on_track_frame=self.on_track_frame,
        )
        self._peers[token] = peer

        try:
            await peer.set_remote_offer(sdp)
            answer = await peer.create_answer()
            return answer
        except Exception:
            logger.exception("[PeerManager] handle_offer failed for %s", token[:8])
            await self.remove(token)
            return None

    async def handle_ice(self, token: str, candidate: dict) -> None:
        peer = self._peers.get(token)
        if peer is None:
            logger.debug("[PeerManager] ICE for unknown token %s", token[:8])
            return
        await peer.add_remote_ice(candidate)

    # ------------------------------------------------------------------
    # Removal
    # ------------------------------------------------------------------
    async def remove(self, token: str) -> None:
        peer = self._peers.pop(token, None)
        if peer is not None:
            try:
                await peer.close()
            except Exception:
                pass

    async def close_all(self) -> None:
        for token in list(self._peers.keys()):
            await self.remove(token)

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------
    def count(self) -> int:
        return len(self._peers)

    def has(self, token: str) -> bool:
        return token in self._peers

    def tokens(self):
        return list(self._peers.keys())