"""
blocking/whitelist.py
Processes that must NEVER be killed + app -> executable mapping.

v4.0 — Exam lockdown comprehensive list
"""
from typing import Dict, List, Set


SYSTEM_WHITELIST = {
    # Windows system (inhe kabhi na maaro)
    "system", "system idle process", "registry", "smss.exe", "csrss.exe",
    "wininit.exe", "winlogon.exe", "services.exe", "lsass.exe",
    "svchost.exe", "fontdrvhost.exe", "dwm.exe", "explorer.exe",
    "sihost.exe", "taskhostw.exe", "ctfmon.exe", "conhost.exe",
    "runtimebroker.exe", "searchindexer.exe", "spoolsv.exe",
    "audiodg.exe", "wuauserv", "searchhost.exe", "startmenuexperiencehost.exe",
    "shellexperiencehost.exe", "textinputhost.exe",
    "msmpeng.exe", "nissrv.exe", "securityhealthservice.exe",
    "securityhealthsystray.exe",
    "python.exe", "pythonw.exe", "pycharm64.exe",
    "slems.exe",
    "idle", "memcompression",
    # Important: apna khud ka process
    "cmd.exe", "powershell.exe", "windowsterminal.exe", "wt.exe",
}


# ---------------------------------------------------------------------------
# EXAM LOCKDOWN — comprehensive cheat tools block list
# ---------------------------------------------------------------------------
APP_PROFILES: Dict[str, Dict[str, List[str]]] = {

    # ---------- AI Chat Tools ----------
    "chatgpt": {
        "parent":   ["chatgpt.exe", "chatgpt-desktop.exe", "openai.exe"],
        "children": [],
    },
    "claude": {
        "parent":   ["claude.exe", "claude-desktop.exe"],
        "children": [],
    },
    "gemini": {
        "parent":   ["gemini.exe", "google gemini.exe"],
        "children": [],
    },
    "copilot": {
        "parent":   ["copilot.exe", "githubcopilot.exe", "mscopilot.exe"],
        "children": [],
    },
    "perplexity":   {"parent": ["perplexity.exe"], "children": []},
    "cursor":       {"parent": ["cursor.exe"], "children": []},
    "ollama":       {"parent": ["ollama.exe", "ollama app.exe"], "children": []},
    "lm studio":    {"parent": ["lm studio.exe", "lmstudio.exe"], "children": []},
    "jan":          {"parent": ["jan.exe"], "children": []},
    "gpt4all":      {"parent": ["gpt4all.exe"], "children": []},
    "bard":         {"parent": ["bard.exe"], "children": []},
    "character ai": {"parent": ["characterai.exe"], "children": []},
    "poe":          {"parent": ["poe.exe"], "children": []},
    "you.com":      {"parent": ["you.exe"], "children": []},

    # ---------- Messaging / Social ----------
    "whatsapp": {
        "parent":   ["whatsapp.exe", "whatsapp.root.exe", "whatsappnative.exe"],
        "children": ["msegdewebview2.exe"],
    },
    "telegram":   {"parent": ["telegram.exe", "telegramdesktop.exe"], "children": []},
    "discord": {
        "parent":   ["discord.exe", "discordcanary.exe", "discordptb.exe"],
        "children": ["discordcrashpad.exe", "discord_voice.exe"],
    },
    "skype":      {"parent": ["skype.exe", "skypeapp.exe"], "children": []},
    "slack":      {"parent": ["slack.exe"], "children": []},
    "signal":     {"parent": ["signal.exe"], "children": []},
    "messenger":  {"parent": ["messenger.exe"], "children": []},
    "instagram":  {"parent": ["instagram.exe"], "children": []},
    "facebook":   {"parent": ["facebook.exe"], "children": []},
    "twitter":    {"parent": ["twitter.exe"], "children": []},
    "snapchat":   {"parent": ["snapchat.exe"], "children": []},
    "tiktok":     {"parent": ["tiktok.exe"], "children": []},
    "zoom":       {"parent": ["zoom.exe"], "children": ["cpthost.exe"]},
    "teams":      {"parent": ["teams.exe", "ms-teams.exe"], "children": []},
    "google meet": {"parent": ["meet.exe"], "children": []},

    # ---------- Remote Desktop / Screen Share ----------
    "teamviewer": {
        "parent":   ["teamviewer.exe"],
        "children": ["tv_w32.exe", "tv_x64.exe", "teamviewer_service.exe"],
    },
    "anydesk":    {"parent": ["anydesk.exe"], "children": []},
    "logmein":    {"parent": ["logmein.exe"], "children": []},
    "gotomypc":   {"parent": ["gotomypc.exe"], "children": []},
    "vnc":        {"parent": ["vncserver.exe", "winvnc.exe"], "children": ["vncviewer.exe"]},
    "rdp":        {"parent": ["mstsc.exe"], "children": []},
    "chrome remote": {"parent": ["remoting_host.exe"], "children": []},
    "ammyy":      {"parent": ["aa_v3.exe", "ammyy.exe"], "children": []},
    "supremo":    {"parent": ["supremo.exe"], "children": []},
    "dwservice":  {"parent": ["dwagent.exe"], "children": []},

    # ---------- Screen Recording / Streaming ----------
    "obs":        {"parent": ["obs64.exe", "obs32.exe"], "children": []},
    "bandicam":   {"parent": ["bandicam.exe", "bdcam.exe"], "children": []},
    "camtasia":   {"parent": ["camtasia.exe", "camrecorder.exe"], "children": []},
    "fraps":      {"parent": ["fraps.exe"], "children": []},
    "sharex":     {"parent": ["sharex.exe"], "children": []},
    "loom":       {"parent": ["loom.exe"], "children": []},

    # ---------- Homework Help / Study Cheating ----------
    "chegg":        {"parent": ["chegg.exe"], "children": []},
    "coursehero":   {"parent": ["coursehero.exe"], "children": []},
    "brainly":      {"parent": ["brainly.exe"], "children": []},
    "quizlet":      {"parent": ["quizlet.exe"], "children": []},
    "photomath":    {"parent": ["photomath.exe"], "children": []},
    "mathway":      {"parent": ["mathway.exe"], "children": []},
    "wolframalpha": {"parent": ["wolframalpha.exe"], "children": []},
    "wolfram":      {"parent": ["wolfram.exe", "mathematica.exe"], "children": []},
    "symbolab":     {"parent": ["symbolab.exe"], "children": []},

    # ---------- Notepad / Editor (cheating via notes) ----------
    "notepad++": {
        "parent":   ["notepad++.exe", "npp.exe", "notepad++portable.exe"],
        "children": [],
    },
    "sublime":   {"parent": ["sublime_text.exe"], "children": []},
    "vim":       {"parent": ["vim.exe", "gvim.exe"], "children": []},
    "atom":      {"parent": ["atom.exe"], "children": []},
    "brackets":  {"parent": ["brackets.exe"], "children": []},

    # ---------- Games (distraction) ----------
    "steam": {
        "parent":   ["steam.exe"],
        "children": ["steamwebhelper.exe", "steamservice.exe"],
    },
    "epic games":  {"parent": ["epicgameslauncher.exe"], "children": []},
    "battle.net":  {"parent": ["battle.net.exe"], "children": []},
    "valorant":    {"parent": ["valorant.exe"], "children": []},
    "minecraft":   {"parent": ["minecraft.exe"], "children": []},
    "roblox":      {"parent": ["robloxplayerbeta.exe", "robloxplayer.exe"], "children": []},
    "fortnite":    {"parent": ["fortnite.exe", "fortnitelauncher.exe"], "children": []},
    "pubg":        {"parent": ["pubg.exe", "tslgame.exe"], "children": []},
    "freefire":    {"parent": ["freefire.exe"], "children": []},
    "gta":         {"parent": ["gta5.exe", "gtav.exe"], "children": []},

    # ---------- Virtualization (cheating via VM) ----------
    "virtualbox": {"parent": ["virtualbox.exe"], "children": ["vboxheadless.exe"]},
    "vmware":     {"parent": ["vmware.exe"], "children": ["vmware-vmx.exe"]},
    "hyper-v":    {"parent": ["vmcompute.exe", "vmms.exe"], "children": []},
    "docker": {
        "parent":   ["docker.exe", "dockerd.exe"],
        "children": ["com.docker.backend.exe"],
    },
    "wsl":        {"parent": ["wsl.exe", "wslservice.exe"], "children": []},

    # ---------- Browsers (chatgpt.com etc via browser) ----------
    "chrome": {
        "parent":   ["chrome.exe"],
        "children": [],
    },
    "edge": {
        "parent":   ["msedge.exe"],
        "children": [],
    },
    "firefox":    {"parent": ["firefox.exe"], "children": []},
    "brave":      {"parent": ["brave.exe"], "children": []},
    "opera":      {"parent": ["opera.exe"], "children": []},
    "vivaldi":    {"parent": ["vivaldi.exe"], "children": []},
    "tor":        {"parent": ["tor.exe", "firefox.exe"], "children": []},
    "msedgewebview2": {
        "parent":   ["msedgewebview2.exe"],
        "children": [],
    },

    # ---------- Notes / Productivity (potential cheating) ----------
    "notion":     {"parent": ["notion.exe"], "children": []},
    "evernote":   {"parent": ["evernote.exe"], "children": []},
    "obsidian":   {"parent": ["obsidian.exe"], "children": []},
    "onenote":    {"parent": ["onenote.exe"], "children": []},
    "google keep": {"parent": ["googlekeep.exe"], "children": []},

    # ---------- Misc Tools ----------
    "utorrent":    {"parent": ["utorrent.exe"], "children": []},
    "bittorrent":  {"parent": ["bittorrent.exe"], "children": []},
    "qbittorrent": {"parent": ["qbittorrent.exe"], "children": []},
    "vlc":         {"parent": ["vlc.exe"], "children": []},
    "mpv":         {"parent": ["mpv.exe"], "children": []},
}


def get_app_profile(friendly_name: str) -> Dict[str, List[str]]:
    if not friendly_name:
        return {"parent": [], "children": []}
    key = friendly_name.lower().strip()
    if key in APP_PROFILES:
        p = APP_PROFILES[key]
        return {"parent": list(p["parent"]), "children": list(p["children"])}
    return {"parent": [f"{key}.exe", key], "children": []}


def get_all_executables(friendly_name: str) -> List[str]:
    p = get_app_profile(friendly_name)
    return p["parent"] + p["children"]


def get_parent_executables(friendly_name: str) -> List[str]:
    return get_app_profile(friendly_name)["parent"]


def is_whitelisted(process_name: str) -> bool:
    if not process_name:
        return True
    return process_name.lower().strip() in SYSTEM_WHITELIST


def get_executables_for_app(friendly_name: str) -> List[str]:
    return get_all_executables(friendly_name)


def looks_like_target(proc_name: str, blocklist_executables: Set[str]) -> bool:
    if not proc_name:
        return False
    name = proc_name.lower().strip()
    name_no_ext = name[:-4] if name.endswith(".exe") else name
    for exe in blocklist_executables or []:
        if not exe:
            continue
        exe_l = exe.lower().strip()
        exe_no_ext = exe_l[:-4] if exe_l.endswith(".exe") else exe_l
        if name == exe_l or name_no_ext == exe_no_ext:
            return True
        if len(exe_no_ext) >= 4 and exe_no_ext in name_no_ext:
            return True
        if len(name_no_ext) >= 4 and name_no_ext in exe_no_ext:
            return True
    return False