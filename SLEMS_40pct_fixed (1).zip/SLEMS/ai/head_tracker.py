"""
ai/head_tracker.py
Head pose estimation (yaw + pitch) via MediaPipe Face Mesh.

v2.0:
    - Thresholds tuned to reduce false positives.
    - min_detection_confidence lowered to 0.4 for stability.
"""
import logging
from dataclasses import dataclass

import cv2
import numpy as np

try:
    import mediapipe as mp
except ImportError:
    mp = None

logger = logging.getLogger(__name__)


NOSE_TIP = 1
CHIN = 152
FOREHEAD = 10
LEFT_CHEEK = 234
RIGHT_CHEEK = 454

YAW_THRESHOLD = 0.20
PITCH_THRESHOLD = 0.22


@dataclass
class HeadInfo:
    yaw: float = 0.0
    pitch: float = 0.0
    direction: str = "unknown"
    face_detected: bool = False


class HeadTracker:
    def __init__(self, max_num_faces: int = 1,
                 min_detection_confidence: float = 0.4):
        if mp is None:
            raise ImportError("mediapipe not installed. Run: pip install mediapipe")
        self._mp_face_mesh = mp.solutions.face_mesh
        self._face_mesh = self._mp_face_mesh.FaceMesh(
            max_num_faces=max_num_faces,
            refine_landmarks=False,
            min_detection_confidence=min_detection_confidence,
            min_tracking_confidence=0.5,
        )

    def detect(self, bgr_frame: np.ndarray) -> HeadInfo:
        if bgr_frame is None:
            return HeadInfo()

        h, w = bgr_frame.shape[:2]
        rgb = cv2.cvtColor(bgr_frame, cv2.COLOR_BGR2RGB)
        try:
            result = self._face_mesh.process(rgb)
        except Exception:
            logger.exception("HeadTracker.process failed")
            return HeadInfo()

        if not result.multi_face_landmarks:
            return HeadInfo(face_detected=False)

        lm = result.multi_face_landmarks[0].landmark

        nose_x = lm[NOSE_TIP].x
        nose_y = lm[NOSE_TIP].y
        left_cheek_x = lm[LEFT_CHEEK].x
        right_cheek_x = lm[RIGHT_CHEEK].x
        forehead_y = lm[FOREHEAD].y
        chin_y = lm[CHIN].y

        face_width = max(1e-6, abs(right_cheek_x - left_cheek_x))
        face_height = max(1e-6, abs(chin_y - forehead_y))

        face_center_x = (left_cheek_x + right_cheek_x) / 2.0
        yaw = (nose_x - face_center_x) / face_width

        face_center_y = (forehead_y + chin_y) / 2.0
        pitch = (nose_y - face_center_y) / face_height

        if abs(yaw) > YAW_THRESHOLD:
            direction = "right" if yaw > 0 else "left"
        elif abs(pitch) > PITCH_THRESHOLD:
            direction = "down" if pitch > 0 else "up"
        else:
            direction = "center"

        return HeadInfo(
            yaw=float(yaw),
            pitch=float(pitch),
            direction=direction,
            face_detected=True,
        )

    def close(self):
        try:
            self._face_mesh.close()
        except Exception:
            pass