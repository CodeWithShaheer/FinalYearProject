"""
gui/teacher/dashboard.py
SLEMS Teacher Dashboard — main window (v4.0 — Phase 8 complete).

Wires:
    - NetworkBridge (asyncio TeacherServer + PeerManager in QThread)
    - LiveMonitorPage (real tiles + real WebRTC video)
    - ViolationLogPage (live + DB backed)
    - ReportsPage (unchanged)
"""
import logging
import os
import sys
from datetime import datetime

from PyQt5.QtCore import Qt, QTimer, pyqtSignal
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QVBoxLayout, QHBoxLayout,
    QPushButton, QFrame, QTableWidget, QTableWidgetItem, QHeaderView,
    QStackedWidget, QFileDialog, QMessageBox, QButtonGroup, QDialog,
    QProgressBar, QListWidget, QGraphicsDropShadowEffect,
)
from PyQt5.QtGui import QPixmap, QColor

from gui.common import theme
from gui.common.widgets import StatCard
from gui.teacher.live_monitor import LiveMonitorPage
from gui.teacher.session_control import SessionControlPage
from gui.teacher.violation_log import ViolationLogPage
from gui.teacher.network_bridge import NetworkBridge
from database import (
    sessions_repo, students_repo, submissions_repo, violations_repo,
)
from utils.paths import load_logo_pixmap
from utils.helpers import format_datetime


def _drop_shadow(blur=20, y_offset=4):
    eff = QGraphicsDropShadowEffect()
    eff.setBlurRadius(blur)
    eff.setOffset(0, y_offset)
    eff.setColor(QColor(16, 24, 40, 40))
    return eff


def card(title=None):
    w = QFrame()
    w.setObjectName("card")
    w.setGraphicsEffect(_drop_shadow())
    layout = QVBoxLayout(w)
    layout.setContentsMargins(22, 18, 22, 18)
    layout.setSpacing(14)
    if title:
        t = QLabel(title)
        t.setObjectName("cardTitle")
        layout.addWidget(t)
    return w, layout


logger = logging.getLogger(__name__)


# ===========================================================================
# Reports (unchanged from v3.0)
# ===========================================================================
class ReportsPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.current_session_id = None
        self._all_students_data = []
        self._build_ui()
        self._load_data()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 24, 28, 28)
        root.setSpacing(24)

        header_row = QHBoxLayout()
        header_title = QLabel("Lab Exam Reports")
        header_title.setStyleSheet(f"font-size: 28px; font-weight: 800; color: {theme.NAVY_DARK};")
        header_row.addWidget(header_title)
        header_sub = QLabel("Track student submissions and download all lab exams")
        header_sub.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 15px;")
        header_row.addWidget(header_sub)
        header_row.addStretch()

        self.session_combo = QPushButton("All Sessions")
        self.session_combo.setObjectName("ghostBtn")
        self.session_combo.setMinimumHeight(44)
        self.session_combo.clicked.connect(self._select_session)
        header_row.addWidget(self.session_combo)
        root.addLayout(header_row)

        stats_row = QHBoxLayout()
        stats_row.setSpacing(20)
        self.stat_total = StatCard("Total Students", "0", "total")
        self.stat_submitted = StatCard("Submitted", "0", "submitted")
        self.stat_remaining = StatCard("Remaining", "0", "remaining")
        stats_row.addWidget(self.stat_total, stretch=1)
        stats_row.addWidget(self.stat_submitted, stretch=1)
        stats_row.addWidget(self.stat_remaining, stretch=1)
        root.addLayout(stats_row)

        progress_card, progress_layout = card("Submission Progress")
        progress_card.setGraphicsEffect(_drop_shadow(blur=20, y_offset=4))
        progress_header = QHBoxLayout()
        pl = QLabel("Overall Submission Rate")
        pl.setStyleSheet(f"font-size: 16px; font-weight: 700; color: {theme.NAVY_DARK};")
        progress_header.addWidget(pl)
        progress_header.addStretch()
        self.progress_percent = QLabel("0%")
        self.progress_percent.setStyleSheet(f"font-size: 18px; font-weight: 800; color: {theme.NAVY};")
        progress_header.addWidget(self.progress_percent)
        progress_layout.addLayout(progress_header)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setFixedHeight(24)
        progress_layout.addWidget(self.progress_bar)
        root.addWidget(progress_card)

        table_card, table_layout = card("Student Submission Status")
        table_card.setGraphicsEffect(_drop_shadow(blur=24, y_offset=6))

        table_header = QHBoxLayout()
        table_title = QLabel("All Students")
        table_title.setStyleSheet(f"font-size: 20px; font-weight: 700; color: {theme.NAVY_DARK};")
        table_header.addWidget(table_title)
        table_header.addStretch()

        self.filter_all_btn = QPushButton("All")
        self.filter_all_btn.setObjectName("chip")
        self.filter_all_btn.setCheckable(True)
        self.filter_all_btn.setChecked(True)
        self.filter_all_btn.clicked.connect(lambda: self._filter_table("all"))

        self.filter_submitted_btn = QPushButton("Submitted")
        self.filter_submitted_btn.setObjectName("chip")
        self.filter_submitted_btn.setCheckable(True)
        self.filter_submitted_btn.clicked.connect(lambda: self._filter_table("submitted"))

        self.filter_pending_btn = QPushButton("Pending")
        self.filter_pending_btn.setObjectName("chip")
        self.filter_pending_btn.setCheckable(True)
        self.filter_pending_btn.clicked.connect(lambda: self._filter_table("pending"))

        self.filter_group = QButtonGroup(self)
        self.filter_group.setExclusive(True)
        self.filter_group.addButton(self.filter_all_btn)
        self.filter_group.addButton(self.filter_submitted_btn)
        self.filter_group.addButton(self.filter_pending_btn)

        table_header.addWidget(self.filter_all_btn)
        table_header.addWidget(self.filter_submitted_btn)
        table_header.addWidget(self.filter_pending_btn)
        table_layout.addLayout(table_header)

        self.students_table = QTableWidget(0, 5)
        self.students_table.setHorizontalHeaderLabels(
            ["Student", "Roll No", "Status", "Submitted At", "File"]
        )
        self.students_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.students_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        for col in [1, 2, 4]:
            self.students_table.horizontalHeader().setSectionResizeMode(col, QHeaderView.ResizeToContents)
        self.students_table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.students_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.students_table.verticalHeader().setVisible(False)
        self.students_table.setMinimumHeight(400)
        table_layout.addWidget(self.students_table)
        root.addWidget(table_card, stretch=1)

        download_row = QHBoxLayout()
        download_row.addStretch()
        self.download_btn = QPushButton("Download All Submissions (ZIP)")
        self.download_btn.setObjectName("primaryBtn")
        self.download_btn.setMinimumHeight(54)
        self.download_btn.setMinimumWidth(320)
        self.download_btn.clicked.connect(self._download_zip)
        download_row.addWidget(self.download_btn)
        root.addLayout(download_row)

    def refresh(self):
        self._load_data()

    def set_session_filter(self, session_id: int):
        self.current_session_id = session_id
        sess = sessions_repo.get_session_by_id(session_id)
        if sess:
            self.session_combo.setText(f"#{sess.id} — {sess.course_name}")
        self._load_data()

    def _select_session(self):
        sessions = sessions_repo.get_all_sessions(limit=100)
        if not sessions:
            QMessageBox.information(self, "No Sessions", "No sessions found.")
            return
        dlg = QDialog(self)
        dlg.setWindowTitle("Select Session")
        dlg.setMinimumWidth(400)
        dl = QVBoxLayout(dlg)
        lw = QListWidget()
        lw.addItem("All Sessions")
        for s in sessions:
            lw.addItem(f"#{s.id} — {s.course_name} ({s.status})")
        dl.addWidget(lw)

        def on_select():
            idx = lw.currentRow()
            if idx == 0:
                self.current_session_id = None
                self.session_combo.setText("All Sessions")
            else:
                self.current_session_id = sessions[idx - 1].id
                self.session_combo.setText(f"#{sessions[idx - 1].id} — {sessions[idx - 1].course_name}")
            self._load_data()
            dlg.close()

        lw.itemClicked.connect(lambda _: on_select())
        dlg.exec_()

    def _load_data(self):
        stats = submissions_repo.get_submission_stats(self.current_session_id)
        total = stats["total"]
        submitted = stats["submitted"]
        remaining = stats["remaining"]

        self.stat_total.value.setText(str(total))
        self.stat_submitted.value.setText(str(submitted))
        self.stat_remaining.value.setText(str(remaining))

        percent = int((submitted / total * 100)) if total > 0 else 0
        self.progress_bar.setValue(percent)
        self.progress_percent.setText(f"{percent}%")
        self._load_table()

    def _load_table(self):
        if self.current_session_id:
            students = students_repo.get_students_by_session(self.current_session_id)
        else:
            students = students_repo.get_all_students(limit=500)

        subs = (
            submissions_repo.get_submissions_by_session(self.current_session_id)
            if self.current_session_id
            else submissions_repo.get_all_submissions(limit=500)
        )
        submissions = {s.student_id: (s.file_name, s.submitted_at) for s in subs}

        self._all_students_data = []
        for st in students:
            if st.id in submissions:
                fname, when = submissions[st.id]
                self._all_students_data.append({
                    "name": st.full_name, "roll_no": st.roll_no,
                    "status": "submitted",
                    "submitted_at": format_datetime(when), "file": fname,
                })
            else:
                self._all_students_data.append({
                    "name": st.full_name, "roll_no": st.roll_no,
                    "status": "pending", "submitted_at": "—", "file": "—",
                })
        self._apply_table_filter("all")

    def _filter_table(self, filter_type):
        self._apply_table_filter(filter_type)

    def _apply_table_filter(self, filter_type):
        filtered = self._all_students_data
        if filter_type == "submitted":
            filtered = [s for s in self._all_students_data if s["status"] == "submitted"]
        elif filter_type == "pending":
            filtered = [s for s in self._all_students_data if s["status"] == "pending"]

        self.students_table.setRowCount(len(filtered))
        for row, student in enumerate(filtered):
            self.students_table.setItem(row, 0, QTableWidgetItem(student["name"]))
            self.students_table.setItem(row, 1, QTableWidgetItem(student["roll_no"]))
            status_item = QTableWidgetItem(student["status"].upper())
            status_item.setForeground(Qt.green if student["status"] == "submitted" else Qt.red)
            self.students_table.setItem(row, 2, status_item)
            self.students_table.setItem(row, 3, QTableWidgetItem(student["submitted_at"]))
            self.students_table.setItem(row, 4, QTableWidgetItem(student["file"]))

    def _download_zip(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Download All Submissions",
            f"slems_submissions_{datetime.now().strftime('%Y%m%d')}.zip",
            "ZIP Files (*.zip)",
        )
        if not path:
            return
        subs = (
            submissions_repo.get_submissions_by_session(self.current_session_id)
            if self.current_session_id
            else submissions_repo.get_all_submissions(limit=1000)
        )
        if not subs:
            QMessageBox.warning(self, "No Data", "No submissions found.")
            return
        import zipfile
        try:
            with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
                count = 0
                for s in subs:
                    if s.file_path and os.path.exists(s.file_path):
                        arc = f"{s.roll_no}_{s.student_name}_{s.file_name}"
                        zf.write(s.file_path, arc)
                        count += 1
            QMessageBox.information(self, "Done", f"Downloaded {count} submissions to:\n{path}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to create ZIP:\n{e}")


# ===========================================================================
# Main Teacher Dashboard
# ===========================================================================
class TeacherDashboard(QMainWindow):
    logout_requested = pyqtSignal()

    NAV_ITEMS = [
        ("live", "Live Monitor"),
        ("session", "Session Control"),
        ("log", "Violation Log"),
        ("reports", "Reports"),
    ]

    def __init__(self, user: dict = None):
        super().__init__()
        self.user = user or {"full_name": "Teacher", "role": "Invigilator"}
        self.setWindowTitle("SLEMS - Teacher Dashboard")
        self.resize(1600, 1000)

        central = QWidget()
        central.setObjectName("centralArea")
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._build_sidebar())

        right_col = QVBoxLayout()
        right_col.setContentsMargins(0, 0, 0, 0)
        right_col.setSpacing(0)
        right_col.addWidget(self._build_top_bar())

        self.stack = QStackedWidget()
        self.live_page = LiveMonitorPage()
        self.session_page = SessionControlPage()
        self.log_page = ViolationLogPage()
        self.reports_page = ReportsPage()

        self.session_page.monitor_requested.connect(self._on_monitor_requested)
        self.session_page.report_requested.connect(self._on_report_requested)
        self.session_page.session_started.connect(self._on_session_started)
        self.session_page.session_ended.connect(self._on_session_ended)
        self.session_page.actor_user_id = self.user.get("id")

        self.pages = {
            "live": self.live_page,
            "session": self.session_page,
            "log": self.log_page,
            "reports": self.reports_page,
        }
        for key, _ in self.NAV_ITEMS:
            self.stack.addWidget(self.pages[key])
        right_col.addWidget(self.stack, stretch=1)

        right_wrap = QWidget()
        right_wrap.setLayout(right_col)
        root.addWidget(right_wrap, stretch=1)

        self._elapsed_seconds = 0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(1000)

        # ---------- Network bridge ----------
        self.bridge = NetworkBridge(self)
        self.bridge.student_connected.connect(self._on_student_connected)
        self.bridge.student_disconnected.connect(self._on_student_disconnected)
        self.bridge.violation_received.connect(self._on_violation_received)
        self.bridge.server_error.connect(self._on_server_error)
        self.bridge.server_started.connect(self._on_server_started)
        self.bridge.submission_received.connect(self._on_submission_received)
        self.bridge.block_event_received.connect(self.live_page.note_block_event)
        self.bridge.block_event_received.connect(lambda _p: self.log_page._load_events())
        self.bridge.heartbeat_received.connect(self.live_page.note_heartbeat)
        self.bridge.blocking_paused_changed.connect(self._on_blocking_paused_changed)
        self.live_page.pause_requested.connect(self._on_pause_requested)
        # WebRTC signals
        self.bridge.peer_connected.connect(self._on_peer_connected)
        self.bridge.peer_disconnected.connect(self._on_peer_disconnected)
        self.bridge.frame_ready.connect(self._on_frame_ready)
        self.bridge.start()

        self._select_nav("live")

    # ==================================================================
    # Bridge handlers
    # ==================================================================
    def _on_server_started(self):
        logger.info("Network server started.")

    def _on_server_error(self, msg: str):
        logger.warning("Server error: %s", msg)

    def _on_submission_received(self, payload: dict):
        """A student's file arrived and is already in the DB: refresh the Reports page."""
        logger.info("Submission received from %s", payload.get("roll_no"))
        self.reports_page.refresh()

    def _on_student_connected(self, payload: dict):
        self.live_page.add_student(payload)

    def _on_student_disconnected(self, payload: dict):
        self.live_page.remove_student(payload)

    def _on_violation_received(self, payload: dict):
        self.live_page.add_violation(payload)
        self.log_page.add_violation_live(payload)

    def _on_peer_connected(self, token: str):
        self.live_page.set_peer_connected(token)

    def _on_peer_disconnected(self, token: str):
        self.live_page.set_peer_disconnected(token)

    def _on_frame_ready(self, token: str, qimage):
        """Called on GUI thread (Qt signal delivery)."""
        self.live_page.update_frame(token, qimage)

    # ==================================================================
    # Session control signals
    # ==================================================================
    def _on_monitor_requested(self, session_id: int):
        self._select_nav("live")

    def _on_report_requested(self, session_id: int):
        self._select_nav("reports")
        self.reports_page.set_session_filter(session_id)

    def _on_session_started(self, session_id: int):
        self.live_page.clear_all()

    def _on_pause_requested(self, token: str, paused: bool, reason: str):
        self.bridge.set_blocking_paused(token, paused, reason, self.user.get("id"))

    def _on_blocking_paused_changed(self, payload: dict):
        self.live_page.set_paused(payload.get("token"), payload.get("paused", False))

    def _on_session_ended(self, session_id: int):
        """Teacher pressed End (or the timer hit zero): tell every student NOW so they are unlocked."""
        self.bridge.broadcast_session_end(session_id)

    # ==================================================================
    # Sidebar
    # ==================================================================
    def _build_sidebar(self) -> QWidget:
        sidebar = QFrame()
        sidebar.setObjectName("sidebar")
        sidebar.setFixedWidth(300)
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(24, 30, 24, 24)
        layout.setSpacing(8)

        logo = QLabel("SLEMS")
        logo.setObjectName("sidebarLogo")
        layout.addWidget(logo)
        subtitle = QLabel("NUML - Faisalabad Campus")
        subtitle.setObjectName("sidebarSubtitle")
        layout.addWidget(subtitle)
        layout.addSpacing(32)

        self.nav_buttons = {}
        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)
        for key, label in self.NAV_ITEMS:
            btn = QPushButton(label)
            btn.setObjectName("navButton")
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _, k=key: self._select_nav(k))
            self.nav_group.addButton(btn)
            self.nav_buttons[key] = btn
            layout.addWidget(btn)

        layout.addStretch()

        profile_container = QFrame()
        profile_container.setStyleSheet(
            f"QFrame {{ background: {theme.NAVY}; border-radius: 14px; }}"
        )
        pl = QVBoxLayout(profile_container)
        pl.setContentsMargins(18, 16, 18, 16)
        pl.setSpacing(10)

        teacher_lbl = QLabel(self.user.get("full_name", "Teacher"))
        teacher_lbl.setStyleSheet(f"color: {theme.TEXT_ON_NAVY}; font-size: 18px; font-weight: 700;")
        pl.addWidget(teacher_lbl)

        role_lbl = QLabel(str(self.user.get("role", "Invigilator")).title())
        role_lbl.setStyleSheet(f"color: {theme.GOLD_LIGHT}; font-size: 14px; font-weight: 600;")
        pl.addWidget(role_lbl)

        line = QFrame()
        line.setStyleSheet(f"background: {theme.NAVY_LIGHT};")
        line.setFixedHeight(2)
        pl.addWidget(line)

        logout_btn = QPushButton("Logout")
        logout_btn.setFixedHeight(48)
        logout_btn.setStyleSheet(f"""
            QPushButton {{
                background: {theme.STATUS_BEHAVIORAL}; color: white;
                border: none; border-radius: 10px;
                font-size: 15px; font-weight: 700;
            }}
            QPushButton:hover {{ background: #C43030; }}
        """)
        logout_btn.setCursor(Qt.PointingHandCursor)
        logout_btn.clicked.connect(self._on_logout)
        pl.addWidget(logout_btn)

        layout.addWidget(profile_container)
        return sidebar

    def _on_logout(self):
        reply = QMessageBox.question(
            self, "Logout", "Are you sure you want to logout?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No,
        )
        if reply == QMessageBox.Yes:
            self._shutdown_bridge()
            self.logout_requested.emit()

    def _shutdown_bridge(self):
        try:
            self.bridge.broadcast_session_end()
        except Exception:
            pass
        try:
            self.bridge.stop()
        except Exception:
            pass

    def closeEvent(self, event):
        self._shutdown_bridge()
        super().closeEvent(event)

    # ==================================================================
    # Top bar
    # ==================================================================
    def _build_top_bar(self) -> QWidget:
        bar = QFrame()
        bar.setObjectName("topBar")
        bar.setFixedHeight(84)
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(20, 12, 32, 12)
        layout.setSpacing(14)

        logo_container = QFrame()
        logo_container.setStyleSheet("background: transparent;")
        logo_container.setFixedSize(80, 80)
        logo_layout = QVBoxLayout(logo_container)
        logo_layout.setContentsMargins(0, 0, 0, 0)
        logo_layout.setAlignment(Qt.AlignCenter)

        logo_lbl = QLabel()
        pixmap = load_logo_pixmap(72, 72)
        if pixmap is not None:
            logo_lbl.setPixmap(pixmap)
        logo_lbl.setAlignment(Qt.AlignCenter)
        logo_layout.addWidget(logo_lbl)
        layout.addWidget(logo_container)

        title_col = QVBoxLayout()
        title_col.setSpacing(3)
        self.page_title_lbl = QLabel("Live Monitor")
        self.page_title_lbl.setObjectName("topBarTitle")
        self.page_subtitle_lbl = QLabel("Smart Lab Exam Monitoring System")
        self.page_subtitle_lbl.setObjectName("topBarSubtitle")
        title_col.addWidget(self.page_title_lbl)
        title_col.addWidget(self.page_subtitle_lbl)
        layout.addLayout(title_col)
        layout.addStretch()

        self.timer_lbl = QLabel("00:00:00")
        self.timer_lbl.setObjectName("sessionTimer")
        layout.addWidget(self.timer_lbl)
        return bar

    def _select_nav(self, key: str):
        self.nav_buttons[key].setChecked(True)
        index = [k for k, _ in self.NAV_ITEMS].index(key)
        self.stack.setCurrentIndex(index)
        titles = {
            "live": "Live Monitor",
            "session": "Session Control",
            "log": "Violation Log",
            "reports": "Reports",
        }
        self.page_title_lbl.setText(titles[key])

        if key == "session":
            self.session_page._load_sessions()
            self.session_page._refresh_timer_from_active_session()
            self.session_page._update_readiness()
        elif key == "reports":
            self.reports_page._load_data()
        elif key == "log":
            self.log_page.refresh()

    def _tick(self):
        self._elapsed_seconds += 1
        h = self._elapsed_seconds // 3600
        m = (self._elapsed_seconds % 3600) // 60
        s = self._elapsed_seconds % 60
        self.timer_lbl.setText(f"{h:02d}:{m:02d}:{s:02d}")


def main(user: dict = None):
    app = QApplication(sys.argv)
    app.setStyleSheet(theme.build_stylesheet())
    win = TeacherDashboard(user=user)
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()