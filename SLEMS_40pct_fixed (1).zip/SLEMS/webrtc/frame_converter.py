"""
webrtc/frame_converter.py
Convert aiortc av.VideoFrame → numpy RGB → Qt QImage.

Design notes:
    - Runs in the asyncio/network thread
    - Produces QImage that can be safely passed to Qt's event loop
    - QImage is created from a copy of the numpy buffer so it owns its memory
    - Caller MUST NOT retain the numpy array after conversion (we copy)
"""
import logging
from typing import Optional

import numpy as np
from PyQt5.QtGui import QImage

logger = logging.getLogger(__name__)


def av_frame_to_qimage(frame) -> Optional[QImage]:
    """
    Convert an av.VideoFrame to a QImage (RGB32 / Format_RGB888).

    Returns None if the frame cannot be converted.
    """
    if frame is None:
        return None
    try:
        # to_ndarray gives RGB24 (H, W, 3) uint8
        arr = frame.to_ndarray(format="rgb24")
    except Exception:
        logger.exception("av_frame_to_qimage: to_ndarray failed")
        return None

    try:
        h, w, ch = arr.shape
        if ch != 3:
            return None
        # Ensure contiguous
        arr = np.ascontiguousarray(arr)
        # QImage does NOT copy — we must keep `arr` alive until .copy() is called
        qimg = QImage(
            arr.data, w, h, ch * w, QImage.Format_RGB888
        )
        # .copy() deep-copies the buffer, so we own it
        return qimg.copy()
    except Exception:
        logger.exception("av_frame_to_qimage: QImage build failed")
        return None


def scale_qimage(img: QImage, target_w: int, target_h: int) -> QImage:
    """Scale a QImage to target size (keep aspect ratio not enforced)."""
    if img is None:
        return None
    from PyQt5.QtCore import Qt
    return img.scaled(
        target_w, target_h, Qt.KeepAspectRatio, Qt.SmoothTransformation
    )