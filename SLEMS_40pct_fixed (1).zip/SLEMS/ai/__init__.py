"""
ai package
Real-time on-device AI detection for SLEMS.

Runs entirely on the student PC. Never uploads video frames.
Only emits violation events over the network.
"""

from ai.detection_engine import DetectionEngine, DetectionResult
from ai.rule_engine import RuleEngine, ViolationEvent
from ai.ai_worker import AIWorker

__all__ = [
    "DetectionEngine",
    "DetectionResult",
    "RuleEngine",
    "ViolationEvent",
    "AIWorker",
]