"""
ai/yolo_detector.py
YOLOv8n-based object detector — focused on "cell phone" class.

Runs on CPU. Model: yolov8n.pt (~6 MB, auto-downloaded on first use).

COCO class 67 = "cell phone"
We only care about this class (and optionally "book" = 73).

Design:
    - load_model()  : lazy-load the YOLO model (heavy first call)
    - detect(frame) : returns list of (class_name, confidence, box)
    - phone_present : True if any "cell phone" detection above threshold
"""

import logging
from dataclasses import dataclass, field
from typing import List, Optional, Tuple

import numpy as np

logger = logging.getLogger(__name__)


# COCO class IDs we care about
COCO_CELL_PHONE = 67
COCO_BOOK = 73

INTERESTING_CLASSES = {
    COCO_CELL_PHONE: "phone",
    COCO_BOOK: "book",
}

# Confidence threshold
DEFAULT_CONF_THRESHOLD = 0.45


@dataclass
class YoloObject:
    class_id: int
    class_name: str
    confidence: float
    box: Tuple[int, int, int, int]   # x, y, w, h


@dataclass
class YoloResult:
    objects: List[YoloObject] = field(default_factory=list)
    inference_ms: float = 0.0

    # Convenience flags
    @property
    def has_phone(self) -> bool:
        return any(o.class_name == "phone" for o in self.objects)

    @property
    def has_book(self) -> bool:
        return any(o.class_name == "book" for o in self.objects)

    def phone_objects(self) -> List[YoloObject]:
        return [o for o in self.objects if o.class_name == "phone"]


class YoloDetector:
    """
    Lazy-loaded YOLOv8n wrapper.

    Usage:
        det = YoloDetector()
        det.load()                # one-time, ~1 sec
        result = det.detect(bgr)  # ~120-180 ms on CPU
    """

    _model = None             # class-level cache
    _model_loaded = False

    def __init__(self, conf_threshold: float = DEFAULT_CONF_THRESHOLD,
                 model_name: str = "yolov8n.pt"):
        self.conf_threshold = conf_threshold
        self.model_name = model_name
        self._local_model = None

    # ------------------------------------------------------------------
    def load(self) -> bool:
        """
        Load the YOLO model. Safe to call multiple times.
        Returns True on success, False on ANY failure (never crashes).
        """
        if self._local_model is not None:
            return True

        # Reuse class-level cache if available
        if YoloDetector._model is not None:
            self._local_model = YoloDetector._model
            return True

        # Try importing ultralytics (which imports torch)
        try:
            from ultralytics import YOLO
        except ImportError as e:
            logger.warning("ultralytics not installed (%s) — YOLO disabled.", e)
            return False
        except OSError as e:
            # Catches torch DLL errors (WinError 1114) gracefully
            logger.warning(
                "PyTorch DLL load failed (%s) — YOLO disabled. "
                "Install VC++ Redistributable or reinstall torch.", e
            )
            return False
        except Exception as e:
            logger.warning("ultralytics import failed (%s) — YOLO disabled.", e)
            return False

        try:
            logger.info("Loading YOLO model: %s (may download on first run)…",
                        self.model_name)
            model = YOLO(self.model_name)
            YoloDetector._model = model
            YoloDetector._model_loaded = True
            self._local_model = model
            logger.info("YOLO model loaded.")
            return True
        except Exception:
            logger.exception("Failed to load YOLO model — YOLO disabled.")
            return False

    # ------------------------------------------------------------------
    @property
    def is_loaded(self) -> bool:
        return self._local_model is not None

    # ------------------------------------------------------------------
    def detect(self, bgr_frame: np.ndarray) -> YoloResult:
        """
        Run YOLO on a BGR frame. Returns YoloResult.
        If model not loaded, returns empty result (silent).
        """
        import time
        result = YoloResult()
        if bgr_frame is None or self._local_model is None:
            return result

        t0 = time.time()
        try:
            predictions = self._local_model.predict(
                source=bgr_frame,
                conf=self.conf_threshold,
                verbose=False,
            )
        except Exception:
            logger.exception("YOLO predict failed")
            result.inference_ms = (time.time() - t0) * 1000
            return result

        for pred in predictions:
            boxes = pred.boxes
            if boxes is None:
                continue
            for box in boxes:
                cls_id = int(box.cls[0].item())
                conf = float(box.conf[0].item())
                if cls_id not in INTERESTING_CLASSES:
                    continue
                xyxy = box.xyxy[0].tolist()
                x1, y1, x2, y2 = [int(v) for v in xyxy]
                result.objects.append(YoloObject(
                    class_id=cls_id,
                    class_name=INTERESTING_CLASSES[cls_id],
                    confidence=conf,
                    box=(x1, y1, x2 - x1, y2 - y1),
                ))

        result.inference_ms = (time.time() - t0) * 1000
        return result

    # ------------------------------------------------------------------
    def close(self):
        # YOLO model stays cached; nothing to release
        pass