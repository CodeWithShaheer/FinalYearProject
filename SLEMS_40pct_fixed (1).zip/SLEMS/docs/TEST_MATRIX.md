# SLEMS test matrix (40% milestone)

Generated 2026-11-08 05:05 - **35/35 passed**.  Screenshot column: fill in by hand.

| Req | What is tested | Expected | Actual | Time (s) | Test | Screenshot |
|---|---|---|---|---|---|---|
| BLK-1 | Detect only blocklisted apps | Listed app found; unlisted app ignored | **PASS** | 0.51 | `test_blocking_engine::test_monitor_detects_only_blocklisted` | |
| BLK-1 | Unknown app names still match | <name>.exe profile generated | **PASS** | 0.00 | `test_blocking_engine::test_unknown_app_name_gets_default_profile` | |
| BLK-2 | Blocked app killed within 2 s of launch | Killed in < 2000 ms; latency + violation recorded | **PASS** | 1.17 | `test_blocking_engine::test_engine_kills_new_app_within_2_seconds` | |
| BLK-2 | Terminate a blocked process | Process is gone after terminate_all | **PASS** | 0.51 | `test_blocking_engine::test_blocker_kills_process` | |
| BLK-3 | Domain input cleaned | URL/port/www stripped; invalid rejected | **PASS** | 0.00 | `test_hosts_manager::test_normalize_domain` | |
| BLK-3 | Re-blocking does not duplicate | One SLEMS block only | **PASS** | 0.00 | `test_hosts_manager::test_block_twice_does_not_duplicate` | |
| BLK-4 | Backups are clean and limited to 5 | No SLEMS block in backups; <= 5 files | **PASS** | 0.00 | `test_hosts_manager::test_backup_is_clean_and_pruned` | |
| BLK-4 | Crash recovery on next start | Process killed mid-block -> next start cleans the file | **PASS** | 0.04 | `test_hosts_manager::test_crash_then_startup_recovery` | |
| BLK-4 | Damaged block incl. IPv6 lines | All SLEMS lines removed, user line kept | **PASS** | 0.00 | `test_hosts_manager::test_missing_end_marker_also_removes_ipv6_lines` | |
| BLK-4 | Damaged block never deletes user entries | User line kept, SLEMS lines removed | **PASS** | 0.00 | `test_hosts_manager::test_missing_end_marker_does_not_eat_user_entries` | |
| BLK-4 | Engine always restores hosts | Original hosts after stop_and_restore | **PASS** | 1.21 | `test_blocking_engine::test_engine_restores_hosts_even_if_stopped_abruptly` | |
| BLK-4 | Hosts file restored exactly | File identical to the original, byte for byte | **PASS** | 0.00 | `test_hosts_manager::test_block_then_restore_is_byte_identical` | |
| BLK-4 | Restore twice is safe | No change, no error | **PASS** | 0.00 | `test_hosts_manager::test_restore_is_idempotent` | |
| BLK-5 | Never kill SLEMS or its parent | Own/parent process survives, monitor and blocker refuse | **PASS** | 0.00 | `test_blocking_engine::test_never_kills_itself_or_parent` | |
| BLK-5 | System processes protected | explorer, svchost, lsass, winlogon, python whitelisted | **PASS** | 0.00 | `test_blocking_engine::test_system_processes_are_whitelisted` | |
| DB-3 | Lockout after 5 wrong passwords | Locked, even correct password refused, unlocks later | **PASS** | 1.92 | `test_auth_and_db::test_lockout_after_five_failures` | |
| DB-3 | No user enumeration | Same message for unknown email | **PASS** | 0.00 | `test_auth_and_db::test_unknown_email_gives_generic_error` | |
| DB-3 | Old accounts keep working | Login ok and hash upgraded to bcrypt | **PASS** | 0.29 | `test_auth_and_db::test_legacy_sha256_accepted_and_upgraded` | |
| DB-3 | bcrypt hashing is salted | Same password -> different hashes; verify works | **PASS** | 1.00 | `test_auth_and_db::test_password_roundtrip_and_salt` | |
| DB-4 | Violation filter / review / CSV | Filters work, dismiss hides, CSV has all rows | **PASS** | 0.01 | `test_auth_and_db::test_violation_filter_review_and_csv` | |
| NET-1..5 | Join, config, violation, file upload, end | All steps succeed; hash of uploaded file matches | **PASS** | 1.93 | `test_dashboard_link::test_teacher_student_link` | |
| S1 | No misleading path entries | No 'site.com/page' entries in lists | **PASS** | 0.00 | `test_hosts_manager::test_no_path_style_entries_are_offered_in_the_ui_lists` | |
| S1 | Presets list explicit sub-domains | chat.openai.com etc. present; all entries valid | **PASS** | 0.00 | `test_hosts_manager::test_presets_cover_subdomains_and_expand_cleanly` | |
| S3 | Abrupt close flagged | High-severity violation + client_offline event | **PASS** | 1.61 | `test_dashboard_link::test_student_closing_slems_mid_exam_is_flagged` | |
| S3 | Logout mid-exam flagged | 'left the exam' violation | **PASS** | 1.31 | `test_dashboard_link::test_student_logging_out_mid_exam_is_flagged` | |
| S4 | Emergency pause / resume | Paused: hosts clean + app survives; resumed: blocked again | **PASS** | 4.24 | `test_blocking_engine::test_pause_releases_everything_and_resume_restores_it` | |
| S5 | Allow-list closes only unlisted apps | Unlisted closed; allowed + system app survive | **PASS** | 0.51 | `test_blocking_engine::test_allowlist_only_closes_apps_that_are_not_allowed` | |
| S5 | Allow-list inside the engine | Unlisted app closed, allowed app kept | **PASS** | 0.56 | `test_blocking_engine::test_engine_allowlist_mode_end_to_end` | |
| S5 | Empty allow-list refused | Nothing is closed | **PASS** | 0.00 | `test_blocking_engine::test_allowlist_refuses_empty_list` | |
| S6/S4 | Block events, latency stats, override audit | Events + stats + audit rows + CSV evidence | **PASS** | 1.93 | `test_dashboard_link::test_block_events_latency_and_emergency_override` | |
| S7 | Join-code brute force blocked | 10 wrong codes -> locked out | **PASS** | 0.21 | `test_dashboard_link::test_wrong_code_brute_force_is_throttled` | |
| S8 | Open mode still works | Any roll number can join | **PASS** | 0.21 | `test_dashboard_link::test_without_roster_requirement_anyone_can_join` | |
| S8 | Roster enforced | Unregistered refused; registered becomes active | **PASS** | 0.21 | `test_dashboard_link::test_roster_blocks_unregistered_students` | |
| S9 | Teacher sign-up needs a key | Wrong/missing key refused; students free | **PASS** | 0.82 | `test_auth_and_db::test_teacher_signup_needs_key_but_students_do_not` | |
| UI-1..3, S1,S4,S6,S10,S12 | Full scenario on the real screens | Start Exam, join code, roster, table, pause, kill, auto-submit, End, auto-end, offline | **PASS** | 27.93 | `test_gui_smoke::test_gui_smoke` | |
