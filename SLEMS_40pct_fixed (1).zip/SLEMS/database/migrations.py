"""
database/migrations.py
Schema initialization + seed data.

Call init_db() once on app startup (safe to call repeatedly).
"""
import json
import logging
from pathlib import Path

from database.connection import db_cursor
from config.settings import (
    DEFAULT_COURSES,
    DEFAULT_SECURITY_OPTIONS,
)

logger = logging.getLogger(__name__)

SCHEMA_FILE = Path(__file__).resolve().parent / "schema.sql"


def _run_schema():
    """Execute schema.sql (idempotent — uses IF NOT EXISTS)."""
    if not SCHEMA_FILE.exists():
        raise FileNotFoundError(f"Schema file not found: {SCHEMA_FILE}")

    sql = SCHEMA_FILE.read_text(encoding="utf-8")

    with db_cursor() as cur:
        cur.execute(sql)

    logger.info("Schema executed successfully.")


def _seed_courses():
    """Insert default courses if the courses table is empty."""
    with db_cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM courses;")
        count = cur.fetchone()[0]

    if count > 0:
        logger.info("Courses table already has %d rows — skipping seed.", count)
        return

    with db_cursor() as cur:
        for name in DEFAULT_COURSES:
            cur.execute(
                "INSERT INTO courses (name) VALUES (%s) ON CONFLICT (name) DO NOTHING;",
                (name,),
            )
    logger.info("Seeded %d default courses.", len(DEFAULT_COURSES))


def init_db():
    """
    Initialize database:
      1. Run schema.sql
      2. Seed default courses
    """
    _run_schema()
    _seed_courses()
    logger.info("Database initialization complete.")


def get_default_security_options_json() -> str:
    """Return default security options as JSON string."""
    return json.dumps(DEFAULT_SECURITY_OPTIONS)