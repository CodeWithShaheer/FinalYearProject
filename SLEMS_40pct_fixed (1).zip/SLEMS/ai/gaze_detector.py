"""
ai/gaze_detector.py
Stand-alone gaze (iris position) detector using MediaPipe Face Mesh.

NOTE: this file previously contained an accidental copy of detection_engine.py,
so `from ai.gaze_detector import GazeDetector` failed.  The production pipeline
(ai_worker -> DetectionEngine) computes gaze in one shared pass for speed;
this class is the single-purpose version used by test_ai_detectors.py and for
unit-testing the gaze thresholds on their own (plan task AI-001).

    detect(frame) -> GazeInfo(direction, h_offset, v_offset, face_detected)
    direction is one of: center, away_left, away_right, away_up, away_down, unknown
"""
import logging
from dataclasses import dataclass

import cv2
import numpy as np

try:
    import mediapipe as mp
except ImportError:
    mp = None

logger = logging.getLogger(__name__)

LEFT_IRIS = [474, 475, 476, 477]
RIGHT_IRIS = [469, 470, 471, 472]
LEFT_EYE_CORNERS = (33, 133)
RIGHT_EYE_CORNERS = (362, 263)
LEFT_CHEEK = 234
RIGHT_CHEEK = 454

HORIZONTAL_OFFSET_THRESHOLD = 0.30
VERTICAL_OFFSET_THRESHOLD = 0.40


@dataclass
class GazeInfo:
    h_offset: float = 0.0
    v_offset: float = 0.0
    direction: str = "unknown"
    face_detected: bool = False


def classify_gaze(h_offset: float, v_offset: float) -> str:
    """Pure function (easy to unit test): offsets -> direction label."""
    if abs(h_offset) > HORIZONTAL_OFFSET_THRESHOLD:
        return "away_right" if h_offset > 0 else "away_left"
    if abs(v_offset) > VERTICAL_OFFSET_THRESHOLD:
        return "away_down" if v_offset > 0 else "away_up"
    return "center"


class GazeDetector:
    def __init__(self, min_detection_confidence: float = 0.4):
        if mp is None:
            raise ImportError("mediapipe not installed. Run: pip install mediapipe")
        self._face_mesh = mp.solutions.face_mesh.FaceMesh(
            max_num_faces=1,
            refine_landmarks=True,          # required for iris landmarks 468-477
            min_detection_confidence=min_detection_confidence,
            min_tracking_confidence=0.5,
        )

    def detect(self, bgr_frame: np.ndarray) -> GazeInfo:
        if bgr_frame is None:
            return GazeInfo()
        h, w = bgr_frame.shape[:2]
        try:
            result = self._face_mesh.process(cv2.cvtColor(bgr_frame, cv2.COLOR_BGR2RGB))
        except Exception:
            logger.exception("GazeDetector.process failed")
            return GazeInfo()
        if not result.multi_face_landmarks:
            return GazeInfo(face_detected=False)

        lm = result.multi_face_landmarks[0].landmark
        face_width = max(1.0, abs(lm[RIGHT_CHEEK].x - lm[LEFT_CHEEK].x) * w)

        def eye(corners, iris):
            a, b = corners
            x1, x2 = lm[a].x * w, lm[b].x * w
            y1, y2 = lm[a].y * h, lm[b].y * h
            ix = float(np.mean([lm[i].x * w for i in iris]))
            iy = float(np.mean([lm[i].y * h for i in iris]))
            width = max(1.0, abs(x1 - x2))
            return (ix - (x1 + x2) / 2.0) / width, (iy - (y1 + y2) / 2.0) / face_width

        lh, lv = eye(LEFT_EYE_CORNERS, LEFT_IRIS)
        rh, rv = eye(RIGHT_EYE_CORNERS, RIGHT_IRIS)
        h_off, v_off = (lh + rh) / 2.0, (lv + rv) / 2.0
        return GazeInfo(h_offset=float(h_off), v_offset=float(v_off),
                        direction=classify_gaze(h_off, v_off), face_detected=True)

    def close(self):
        try:
            self._face_mesh.close()
        except Exception:
            pass
