"""
blocking/allowlist.py
Allow-list mode (S5): only the apps the teacher lists may have a window; everything else is closed.

Safety rules (a lab PC must never be bricked by this feature):
  * Only processes that own a VISIBLE, titled, top-level window are ever considered.
    Background services, drivers, anti-virus, GPU tools etc. have no such window and are untouched.
  * System whitelist, SLEMS itself and all its parent processes are always protected.
  * An EMPTY allow-list is refused (it would close every window, including the exam editor).
  * `dry_run=True` only reports; nothing is killed.

Windows: visible windows are found with ctypes (EnumWindows).  On other OSes the default
provider returns "unsupported" and the feature stays off; tests inject their own provider.
"""
import logging
import os
import platform
from typing import Callable, Iterable, List, Optional, Set

try:
    import psutil
except ImportError:                       # pragma: no cover
    psutil = None

from blocking.process_monitor import DetectedProcess
from blocking.whitelist import SYSTEM_WHITELIST

logger = logging.getLogger(__name__)

# Windows shell / UWP host processes that own windows but must never be closed.
ALWAYS_ALLOWED = {
    "slems", "python", "pythonw", "explorer", "applicationframehost", "searchhost",
    "searchapp", "startmenuexperiencehost", "shellexperiencehost", "textinputhost",
    "lockapp", "dwm", "taskmgr", "systemsettings", "securityhealthsystray",
    "msedgewebview2",          # embedded web views used by many legitimate apps
}


def _norm(name: str) -> str:
    n = (name or "").lower().strip()
    return n[:-4] if n.endswith(".exe") else n


def visible_window_pids() -> Optional[Set[int]]:
    """PIDs owning a visible titled top-level window, or None if unsupported on this OS."""
    if platform.system().lower() != "windows":
        return None
    import ctypes
    from ctypes import wintypes
    user32, dwm = ctypes.windll.user32, ctypes.windll.dwmapi
    GW_OWNER, GWL_EXSTYLE, WS_EX_TOOLWINDOW, DWMWA_CLOAKED = 4, -20, 0x80, 14
    pids: Set[int] = set()

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def _cb(hwnd, _lparam):
        try:
            if not user32.IsWindowVisible(hwnd) or user32.GetWindow(hwnd, GW_OWNER):
                return True
            if user32.GetWindowLongW(hwnd, GWL_EXSTYLE) & WS_EX_TOOLWINDOW:
                return True
            if user32.GetWindowTextLengthW(hwnd) == 0:
                return True
            cloaked = wintypes.DWORD(0)
            dwm.DwmGetWindowAttribute(hwnd, DWMWA_CLOAKED, ctypes.byref(cloaked), ctypes.sizeof(cloaked))
            if cloaked.value:
                return True
            pid = wintypes.DWORD(0)
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if pid.value:
                pids.add(int(pid.value))
        except Exception:
            pass
        return True

    user32.EnumWindows(_cb, 0)
    return pids


class AllowListEnforcer:
    def __init__(self, allowed_apps: Iterable[str],
                 window_pid_provider: Callable[[], Optional[Set[int]]] = visible_window_pids,
                 dry_run: bool = False):
        self.allowed: Set[str] = {_norm(a) for a in (allowed_apps or []) if (a or "").strip()}
        self._provider = window_pid_provider
        self.dry_run = dry_run
        self._own = {os.getpid()}
        try:
            self._own |= {p.pid for p in psutil.Process().parents()}
        except Exception:
            pass

    @property
    def usable(self) -> bool:
        """False when the list is empty or the OS cannot enumerate windows."""
        return bool(self.allowed) and self._provider() is not None

    def scan(self) -> List[DetectedProcess]:
        """Processes that own a visible window but are neither allowed nor protected."""
        if not self.allowed:
            logger.error("Allow-list mode refused: the allowed-apps list is empty.")
            return []
        pids = self._provider()
        if not pids:
            return []
        found: List[DetectedProcess] = []
        for pid in pids:
            if pid in self._own:
                continue
            try:
                proc = psutil.Process(pid)
                name = proc.name()
            except Exception:
                continue
            low = name.lower().strip()
            n = _norm(name)
            if low in SYSTEM_WHITELIST or n in ALWAYS_ALLOWED or n in self.allowed:
                continue
            try:
                started = proc.create_time()
            except Exception:
                started = 0.0
            found.append(DetectedProcess(pid=pid, name=low, matched_app="(not on allow-list)",
                                         is_parent=True, started_at=started))
        return found
