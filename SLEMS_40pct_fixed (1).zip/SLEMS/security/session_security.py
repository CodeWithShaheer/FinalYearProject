# Session token security.
"""
security/session_security.py
Session token generation and validation.

Design:
  - Teacher issues a random 32-byte URL-safe token to each joined student.
  - Token is stored in the `connections` table (PostgreSQL).
  - Every incoming student message (except HELLO) must include a valid token.
  - Tokens are bound to a (session_id, student_id, ip) triple.
"""
import logging
import secrets
from typing import Dict, Optional, Tuple

logger = logging.getLogger(__name__)


TOKEN_BYTES = 32    # 32 bytes -> ~43 char URL-safe string


# ---------------------------------------------------------------------------
# In-memory registry of active tokens (teacher side)
# ---------------------------------------------------------------------------
# token -> {session_id, student_id, student_db_id, ip, roll_no}
# NOTE: This is the fast path. DB is the source of truth.
_active_tokens: Dict[str, dict] = {}


def generate_token() -> str:
    """Return a fresh random token."""
    return secrets.token_urlsafe(TOKEN_BYTES)


def register_token(
    token: str,
    session_id: int,
    student_id: str,
    student_db_id: int,
    ip: str,
    roll_no: str = "",
) -> None:
    """Store a token in memory (called after WELCOME is sent)."""
    _active_tokens[token] = {
        "session_id": session_id,
        "student_id": student_id,
        "student_db_id": student_db_id,
        "ip": ip,
        "roll_no": roll_no,
    }
    logger.debug("Token registered for student %s (ip=%s)", roll_no or student_id, ip)


def unregister_token(token: str) -> None:
    """Remove token (called on disconnect)."""
    if token in _active_tokens:
        _active_tokens.pop(token)
        logger.debug("Token unregistered: %s...", token[:8])


def validate_token(token: str) -> Optional[dict]:
    """
    Return the associated metadata if the token is active, else None.
    """
    if not token:
        return None
    return _active_tokens.get(token)


def get_all_active_tokens() -> Dict[str, dict]:
    """Return a shallow copy of the active token registry."""
    return dict(_active_tokens)


def active_token_count() -> int:
    return len(_active_tokens)


# ---------------------------------------------------------------------------
# Issuing WELCOME + registering in one call
# ---------------------------------------------------------------------------
def issue_token(
    session_id: int,
    student_id: str,
    student_db_id: int,
    ip: str,
    roll_no: str = "",
) -> str:
    """
    Generate a token, register it, and return it.
    The caller is responsible for sending it to the student
    (typically wrapped inside a WELCOME message).
    """
    token = generate_token()
    register_token(
        token=token,
        session_id=session_id,
        student_id=student_id,
        student_db_id=student_db_id,
        ip=ip,
        roll_no=roll_no,
    )
    return token