"""
ai/shared_camera.py
Singleton camera capture — one OpenCV VideoCapture shared by
both the WebRTC track and the AI detection engine.

Why this exists:
    On Windows, only one process can open a webcam at a time.
    If StudentPeer (WebRTC) and AIWorker both try to open
    cv2.VideoCapture(0), whichever runs first wins and the
    other silently fails (no exception, just empty frames).

Usage:
    cam = SharedCamera.get()
    cam.start()                         # idempotent
    frame = cam.read()                  # latest BGR np.ndarray
    cam.stop()

The same instance is returned everywhere in this process.
"""
import logging
import threading
import time
from typing import Optional

import cv2
import numpy as np

logger = logging.getLogger(__name__)


class SharedCamera:
    _instance: Optional["SharedCamera"] = None
    _instance_lock = threading.Lock()

    # ------------------------------------------------------------------
    @classmethod
    def get(cls) -> "SharedCamera":
        with cls._instance_lock:
            if cls._instance is None:
                cls._instance = SharedCamera()
            return cls._instance

    # ------------------------------------------------------------------
    def __init__(self, index: int = 0, width: int = 640,
                 height: int = 480, fps: int = 15):
        self.index = index
        self.width = width
        self.height = height
        self.fps = fps

        self._cap: Optional[cv2.VideoCapture] = None
        self._latest: Optional[np.ndarray] = None
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._started = False

    # ------------------------------------------------------------------
    def start(self) -> bool:
        """Idempotent. Returns True if camera is open."""
        if self._started:
            return self._cap is not None

        try:
            cap = cv2.VideoCapture(self.index, cv2.CAP_DSHOW)
            if not cap.isOpened():
                cap.release()
                cap = cv2.VideoCapture(self.index)
            if not cap.isOpened():
                logger.error("SharedCamera: cannot open camera %d", self.index)
                self._cap = None
                return False
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
            cap.set(cv2.CAP_PROP_FPS, self.fps)
            self._cap = cap
            logger.info("SharedCamera opened (index=%d, %dx%d)",
                        self.index, self.width, self.height)
        except Exception:
            logger.exception("SharedCamera open failed")
            self._cap = None
            return False

        self._stop.clear()
        self._thread = threading.Thread(target=self._run, daemon=True,
                                        name="SharedCamera")
        self._thread.start()
        self._started = True
        return True

    # ------------------------------------------------------------------
    def _run(self):
        interval = 1.0 / self.fps
        while not self._stop.is_set():
            t0 = time.time()
            try:
                ok, frame = self._cap.read()
                if ok and frame is not None:
                    with self._lock:
                        self._latest = frame
            except Exception:
                logger.exception("SharedCamera read failed")
            dt = time.time() - t0
            if dt < interval:
                time.sleep(interval - dt)

    # ------------------------------------------------------------------
    def read(self) -> Optional[np.ndarray]:
        with self._lock:
            if self._latest is None:
                return None
            return self._latest.copy()

    # ------------------------------------------------------------------
    def stop(self):
        """Not called in normal flow — camera stays for app lifetime."""
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=2.0)
            self._thread = None
        if self._cap:
            try:
                self._cap.release()
            except Exception:
                pass
            self._cap = None
        self._started = False
        logger.info("SharedCamera stopped.")