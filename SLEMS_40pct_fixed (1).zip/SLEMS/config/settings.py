"""
config/settings.py
Global application settings + constants.

Loads from .env if available, falls back to safe defaults.
"""
import os
from pathlib import Path

# ---------------------------------------------------------------------------
# Load .env (if python-dotenv available)
# ---------------------------------------------------------------------------
try:
    from dotenv import load_dotenv
    _ROOT = Path(__file__).resolve().parent.parent
    _ENV_FILE = _ROOT / ".env"
    if _ENV_FILE.exists():
        load_dotenv(_ENV_FILE)
except ImportError:
    # python-dotenv not installed yet — skip silently
    pass


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
# PROJECT_ROOT = .../stu
PROJECT_ROOT = Path(__file__).resolve().parent.parent

ASSETS_DIR = PROJECT_ROOT / "assets"
IMAGES_DIR = ASSETS_DIR / "images"
ICONS_DIR = ASSETS_DIR / "icons"

DATA_DIR = PROJECT_ROOT / "data"
SUBMISSIONS_DIR = Path(os.getenv("SUBMISSIONS_DIR") or (DATA_DIR / "submissions"))
LOGS_DIR = DATA_DIR / "logs"
LOCAL_DIR = DATA_DIR / "local"

# Create dirs on import (safe)
for _d in (DATA_DIR, SUBMISSIONS_DIR, LOGS_DIR, LOCAL_DIR, IMAGES_DIR, ICONS_DIR):
    _d.mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# App metadata
# ---------------------------------------------------------------------------
APP_NAME = "SLEMS"
APP_FULL_NAME = "Smart Lab Exam Monitoring System"
APP_CAMPUS = "NUML - Faisalabad Campus"
APP_VERSION = "2.0.0"
APP_ENV = os.getenv("APP_ENV", "development")
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")


# ---------------------------------------------------------------------------
# Exam paper constraints
# ---------------------------------------------------------------------------
MAX_EXAM_PAPER_SIZE_MB = 20
MAX_EXAM_PAPER_SIZE_BYTES = MAX_EXAM_PAPER_SIZE_MB * 1024 * 1024

ALLOWED_EXAM_PAPER_EXTENSIONS = {".pdf", ".docx", ".doc"}

ALLOWED_SUBMISSION_EXTENSIONS = {".pdf", ".docx", ".doc", ".zip", ".rar"}


# ---------------------------------------------------------------------------
# Default seed courses
# Teacher can add more at runtime via Add Course dialog.
# ---------------------------------------------------------------------------
DEFAULT_COURSES = [
    "Operating Systems",
    "Data Structures",
    "Database Systems",
    "Computer Networks",
    "Software Engineering",
    "Artificial Intelligence",
    "Web Technologies",
    "Discrete Mathematics",
]


# ---------------------------------------------------------------------------
# Default security options (6 checkboxes on Session Control page)
# Stored as JSON string in sessions.security_options
# ---------------------------------------------------------------------------
DEFAULT_SECURITY_OPTIONS = {
    "block_unauthorized_apps": True,
    "block_restricted_websites": True,
    "monitor_student_screens": True,
    "detect_suspicious_behavior": True,
    "monitor_student_connection": True,
    "enable_kiosk_mode": False,
    "require_roster": False,        # S8: only registered students may join
    "allowlist_mode": False,        # S5: close every windowed app that is not allowed
}

SECURITY_OPTION_LABELS = [
    ("block_unauthorized_apps",    "Block unauthorized applications"),
    ("block_restricted_websites",  "Block restricted websites"),
    ("monitor_student_screens",    "Monitor student screens"),
    ("detect_suspicious_behavior", "Detect suspicious behavior"),
    ("monitor_student_connection", "Monitor student connection"),
    ("enable_kiosk_mode",          "Enable exam kiosk mode"),
    ("require_roster",             "Only registered students may join (roster)"),
    ("allowlist_mode",             "Allow-list mode: close apps that are not allowed"),
]


# ---------------------------------------------------------------------------
# Default blocked apps / domains (pre-checked on Session Control page)
# These are SUGGESTIONS — teacher can uncheck.
# ---------------------------------------------------------------------------
DEFAULT_BLOCKED_APPS = [
    "ChatGPT", "WhatsApp", "Discord", "TeamViewer", "Telegram",
]

DEFAULT_BLOCKED_DOMAINS = [
    "chatgpt.com", "chat.openai.com", "copilot.github.com", "bard.google.com",
]


# Full lists shown on Session Control page.
# Websites come from blocking/presets.py (explicit sub-domains - hosts files have no wildcards).
from blocking.presets import all_domains as _all_domains, APP_PRESETS as _APP_PRESETS  # noqa: E402

AVAILABLE_BLOCKED_APPS = [
    "ChatGPT", "WhatsApp", "Discord", "TeamViewer", "Telegram",
    "Skype", "Zoom", "AnyDesk", "Copilot", "Claude",
    "Gemini", "Perplexity", "Cursor", "Slack", "Teams", "Signal",
    "Chegg", "CourseHero", "Brainly", "Quizlet", "Photomath",
    "Mathway", "WolframAlpha", "Bard", "Ollama", "LM Studio",
]

AVAILABLE_BLOCKED_DOMAINS = _all_domains()


# ---------------------------------------------------------------------------
# Helper: human-readable file size
# ---------------------------------------------------------------------------
def human_size(num_bytes: int) -> str:
    """Convert bytes to human-readable string like '2.34 MB'."""
    if num_bytes is None:
        return "—"
    num = float(num_bytes)
    for unit in ("B", "KB", "MB", "GB"):
        if num < 1024.0:
            if unit == "B":
                return f"{int(num)} {unit}"
            return f"{num:.2f} {unit}"
        num /= 1024.0
    return f"{num:.2f} TB"


# ---------------------------------------------------------------------------
# Feature flags  (40% milestone: AI model and P2P streaming are NOT enabled)
# Turn on later with ENABLE_AI_MONITORING=1 / ENABLE_P2P_STREAMING=1 in .env
# ---------------------------------------------------------------------------
def _flag(name: str, default: bool = False) -> bool:
    return os.getenv(name, "1" if default else "0").strip().lower() in ("1", "true", "yes", "on")


ENABLE_AI_MONITORING = _flag("ENABLE_AI_MONITORING", False)
ENABLE_P2P_STREAMING = _flag("ENABLE_P2P_STREAMING", False)

