"""
network/discovery.py
UDP broadcast for auto-finding the teacher on the LAN.

Robustness fixes:
    - discover_teacher() catches OSError on bind (port in use) and
      returns None instead of crashing.
    - Handles SO_REUSEADDR properly on Windows.
    - Both IP and port variants tolerate socket errors.
"""
import asyncio
import logging
import socket
from typing import Optional

from config.network_config import (
    DISCOVERY_UDP_PORT, DISCOVERY_BROADCAST_INTERVAL, TEACHER_TCP_PORT,
)

logger = logging.getLogger(__name__)


MAGIC = b"SLEMS_TEACHER"


# ===========================================================================
# TEACHER SIDE — broadcaster
# ===========================================================================
class TeacherAnnouncer:
    """Broadcasts the teacher's presence on the LAN via UDP."""

    def __init__(self, tcp_port: int = TEACHER_TCP_PORT,
                 udp_port: int = DISCOVERY_UDP_PORT):
        self.tcp_port = tcp_port
        self.udp_port = udp_port
        self._running = False
        self._task: Optional[asyncio.Task] = None

    async def start(self):
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._loop())
        logger.info("TeacherAnnouncer started on UDP:%s", self.udp_port)

    async def stop(self):
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            except Exception:
                pass
        logger.info("TeacherAnnouncer stopped.")

    async def _loop(self):
        sock = None
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            sock.setblocking(False)
        except OSError as e:
            logger.warning("Could not create announcer socket: %s", e)
            return

        payload = MAGIC + b":" + str(self.tcp_port).encode()

        try:
            while self._running:
                try:
                    sock.sendto(payload, ("255.255.255.255", self.udp_port))
                except OSError as e:
                    logger.debug("Broadcast failed: %s", e)
                await asyncio.sleep(DISCOVERY_BROADCAST_INTERVAL)
        except asyncio.CancelledError:
            pass
        finally:
            try:
                sock.close()
            except Exception:
                pass


# ===========================================================================
# STUDENT SIDE — listener
# ===========================================================================
async def discover_teacher(timeout: float = 5.0,
                           udp_port: int = DISCOVERY_UDP_PORT) -> Optional[str]:
    """
    Listen for teacher broadcast. Returns teacher IP or None.
    Never raises — returns None on any socket error.
    """
    result = await _discover_impl(timeout=timeout, udp_port=udp_port, want_port=False)
    if result is None:
        return None
    return result[0]


async def discover_teacher_with_port(timeout: float = 5.0,
                                     udp_port: int = DISCOVERY_UDP_PORT
                                     ) -> Optional[tuple]:
    """
    Same as discover_teacher but also returns TCP port.
    Returns (ip, tcp_port) or None.
    """
    return await _discover_impl(timeout=timeout, udp_port=udp_port, want_port=True)


async def _discover_impl(timeout: float, udp_port: int,
                         want_port: bool):
    """
    Shared implementation for both public functions.
    Returns:
        want_port=False → (ip, None)
        want_port=True  → (ip, tcp_port)
    or None on any failure.
    """
    loop = asyncio.get_running_loop()

    sock = None
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        # On Windows we also need SO_REUSEPORT-like behavior; SO_REUSEADDR
        # is enough for most cases, but if the port is busy we return None.
        try:
            sock.bind(("", udp_port))
        except OSError as e:
            logger.warning(
                "Discovery bind failed on UDP:%s (%s). "
                "Another app may be using this port. Returning None.",
                udp_port, e,
            )
            return None

        sock.setblocking(False)

        end_time = loop.time() + timeout
        while loop.time() < end_time:
            remaining = max(0.1, end_time - loop.time())
            try:
                data, addr = await asyncio.wait_for(
                    loop.sock_recvfrom(sock, 1024),
                    timeout=remaining,
                )
            except asyncio.TimeoutError:
                break
            except OSError as e:
                logger.warning("Discovery recv error: %s", e)
                break

            if data.startswith(MAGIC):
                teacher_ip = addr[0]
                tcp_port = TEACHER_TCP_PORT
                if want_port:
                    try:
                        _, port_str = data.decode(errors="ignore").split(":", 1)
                        tcp_port = int(port_str)
                    except (ValueError, UnicodeDecodeError):
                        pass
                logger.info("Discovered teacher at %s (tcp=%s)", teacher_ip, tcp_port)
                return (teacher_ip, tcp_port)
        return None
    except Exception as e:
        logger.warning("Discovery failed: %s", e)
        return None
    finally:
        if sock is not None:
            try:
                sock.close()
            except Exception:
                pass