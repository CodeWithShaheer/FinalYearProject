"""
tests/test_dashboard_link.py
Teacher <-> Student network link on one machine (no GUI, no camera).

Covers:  join code (S7) | roster (S8) | offline alert (S3) | block events + latency (S6)
         emergency pause / resume + audit log (S4) | file upload | session end broadcast

Needs PostgreSQL (see .env).   python -m pytest tests/test_dashboard_link.py -v
"""
import asyncio
import hashlib
import os
import sys
import tempfile
import uuid
from contextlib import asynccontextmanager
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parent.parent / ".env")
except ImportError:
    pass

import network.teacher_server as ts
from network.teacher_server import TeacherServer
from network.student_client import (
    StudentClient, EVT_CONFIG_RECEIVED, EVT_SESSION_ENDED, EVT_BLOCK_PAUSE, EVT_BLOCK_RESUME)
from database.migrations import init_db
from database.connection import db_cursor
from database import (sessions_repo, students_repo, violations_repo, submissions_repo,
                      block_events_repo, audit_repo)

init_db()
TEST_PORT = 55871


def _roll():
    return "T" + uuid.uuid4().hex[:5].upper()


@asynccontextmanager
async def link(security_options=None, roster=None):
    """Start a teacher server with a fresh DB session; yield helpers; always clean up."""
    old_host, old_port = ts.TEACHER_HOST, ts.TEACHER_TCP_PORT
    ts.TEACHER_HOST, ts.TEACHER_TCP_PORT = "127.0.0.1", TEST_PORT
    tmp = tempfile.mkdtemp()
    ok, session, _ = sessions_repo.create_session(
        "Operating Systems", "Link test", 30,
        blocked_apps=["discord", "telegram"], blocked_domains=["chatgpt.com"],
        security_options=security_options or {})
    assert ok
    if roster:
        students_repo.add_roster(session.id, roster)
    server = TeacherServer()
    server.receiver.dest_dir = Path(tmp)
    teacher_events = []
    server.on_event(lambda t, p: teacher_events.append((t, p)))
    await server.start()
    clients = []

    async def new_client(roll=None, code=None):
        c = StudentClient()
        c.events = []
        c.on_event(lambda t, p, c=c: c.events.append((t, p)))
        clients.append(c)
        r = roll or _roll()
        ok, msg = await c.connect("127.0.0.1", TEST_PORT, r, code or session.join_code)
        return c, ok, msg, r

    class Env: pass
    env = Env()
    env.session, env.server, env.tmp = session, server, Path(tmp)
    env.teacher_events, env.new_client = teacher_events, new_client
    try:
        yield env
    finally:
        for c in clients:
            try:
                await c.disconnect("test")
            except Exception:
                pass
        await asyncio.sleep(0.2)
        await server.stop()
        sessions_repo.end_session(session.id)
        ts.TEACHER_HOST, ts.TEACHER_TCP_PORT = old_host, old_port


async def _student_pk(session_id, roll):
    return students_repo.get_student_by_roll_in_session(session_id, roll).id


# --------------------------------------------------------------------------- full flow
async def _full_flow():
    async with link() as env:
        # S7: the old guessable session id no longer works, the random code does
        _, ok, msg, _ = await env.new_client(code=str(env.session.id))
        assert not ok and "code" in msg.lower()
        client, ok, msg, roll = await env.new_client()
        assert ok, msg
        await asyncio.sleep(0.5)

        assert client.blocked_domains == ["chatgpt.com"]
        assert "discord" in [a.lower() for a in client.blocked_apps]
        assert any(t == "student_connected" for t, _ in env.teacher_events)

        # violation: student -> teacher -> DB
        assert await client.send_violation("service", "Blocked discord", "medium")
        await asyncio.sleep(0.4)
        assert len(violations_repo.get_violations_by_session(env.session.id)) == 1

        # multi-chunk upload -> teacher disk + DB
        data = os.urandom(600 * 1024)
        src = env.tmp / "answer.zip"
        src.write_bytes(data)
        progress = []
        ok, msg, sub_id = await client.send_submission(str(src), progress.append)
        assert ok and sub_id, msg
        assert progress[-1] == 100
        saved = [p for p in env.tmp.iterdir() if p.name.endswith("answer.zip") and p != src]
        assert len(saved) == 1
        assert hashlib.sha256(saved[0].read_bytes()).digest() == hashlib.sha256(data).digest()
        assert submissions_repo.get_submissions_by_session(env.session.id)[0].file_name == "answer.zip"

        # dangerous type refused
        bad = env.tmp / "virus.exe"
        bad.write_bytes(b"MZ")
        ok, msg, _ = await client.send_submission(str(bad))
        assert not ok and "not allowed" in msg

        # teacher ends the session -> student told, and leaving afterwards is NOT a violation
        before = len(violations_repo.get_violations_by_session(env.session.id))
        await env.server.announce_session_end(env.session.id)
        await asyncio.sleep(0.4)
        assert any(t == EVT_SESSION_ENDED for t, _ in client.events)
        assert any(t == EVT_CONFIG_RECEIVED for t, _ in client.events)
        await client.disconnect("done")
        await asyncio.sleep(0.4)
        assert len(violations_repo.get_violations_by_session(env.session.id)) == before


def test_teacher_student_link():
    asyncio.run(_full_flow())


# --------------------------------------------------------------------------- S7 throttle
async def _throttle():
    async with link() as env:
        for _ in range(10):
            _, ok, _, _ = await env.new_client(code="000000")
            assert not ok
        _, ok, msg, _ = await env.new_client()          # even the RIGHT code is now refused
        assert not ok and "too many" in msg.lower()


def test_wrong_code_brute_force_is_throttled():
    asyncio.run(_throttle())


# --------------------------------------------------------------------------- S8 roster
async def _roster():
    async with link({"require_roster": True}, roster=[("21F-1001", "Ali Khan")]) as env:
        _, ok, msg, _ = await env.new_client(roll="99X-0000")
        assert not ok and "not registered" in msg.lower()
        client, ok, msg, _ = await env.new_client(roll="21f-1001")      # case-insensitive
        assert ok, msg
        st = students_repo.get_student_by_roll_in_session(env.session.id, "21F-1001")
        assert st.status == "active" and st.full_name == "Ali Khan"     # registered -> active


def test_roster_blocks_unregistered_students():
    asyncio.run(_roster())


async def _open_mode():
    async with link({"require_roster": False}) as env:
        client, ok, msg, roll = await env.new_client(roll="ANY-1")
        assert ok, msg                                                   # old open behaviour kept


def test_without_roster_requirement_anyone_can_join():
    asyncio.run(_open_mode())


# --------------------------------------------------------------------------- S3 offline alert
async def _offline():
    async with link() as env:
        client, ok, _, roll = await env.new_client()
        assert ok
        await asyncio.sleep(0.4)
        client.writer.close()                     # simulate SLEMS killed: no DISCONNECT message
        await asyncio.sleep(1.0)
        rows = violations_repo.get_violations_by_session(env.session.id)
        assert any("closed or the connection was lost" in v.description and v.severity == "high"
                   for v in rows)
        pk = await _student_pk(env.session.id, roll)
        assert block_events_repo.get_events(session_id=env.session.id, student_id=pk,
                                            event_type="client_offline")
        assert any(t == "violation" for t, _ in env.teacher_events)


def test_student_closing_slems_mid_exam_is_flagged():
    asyncio.run(_offline())


async def _graceful_leave():
    async with link() as env:
        client, ok, _, _ = await env.new_client()
        await asyncio.sleep(0.3)
        await client.disconnect("logout")
        await asyncio.sleep(0.8)
        assert any("left the exam" in v.description
                   for v in violations_repo.get_violations_by_session(env.session.id))


def test_student_logging_out_mid_exam_is_flagged():
    asyncio.run(_graceful_leave())


# --------------------------------------------------------------------------- S6 + S4
async def _events_and_pause():
    async with link() as env:
        client, ok, _, roll = await env.new_client()
        assert ok
        await asyncio.sleep(0.4)
        token = client.token

        assert await client.send_block_event("process_killed", target="discord.exe", pid=123,
                                             latency_ms=640, detail="discord")
        assert await client.send_block_event("process_killed", target="telegram.exe", pid=124,
                                             latency_ms=1900)
        await asyncio.sleep(0.5)
        stats = block_events_repo.latency_stats(env.session.id)
        assert stats["count"] == 2 and stats["within_2s"] == 2 and stats["max_ms"] == 1900
        pk = await _student_pk(env.session.id, roll)
        assert block_events_repo.counts_by_student(env.session.id)[pk]["kills"] == 2

        # teacher emergency override -> student receives it -> logged twice (events + audit)
        assert await env.server.set_blocking_paused(token, True, "wrong block", actor_user_id=None)
        await asyncio.sleep(0.4)
        assert any(t == EVT_BLOCK_PAUSE and p["reason"] == "wrong block" for t, p in client.events)
        assert await env.server.set_blocking_paused(token, False)
        await asyncio.sleep(0.4)
        assert any(t == EVT_BLOCK_RESUME for t, _ in client.events)

        types = [e.event_type for e in block_events_repo.get_events(session_id=env.session.id)]
        assert "blocking_paused" in types and "blocking_resumed" in types
        actions = [a.action for a in audit_repo.get_entries(session_id=env.session.id)]
        assert "blocking_paused" in actions and "blocking_resumed" in actions

        # CSV export has the evidence columns
        path = str(env.tmp / "events.csv")
        ok, _ = block_events_repo.export_csv(block_events_repo.get_events(session_id=env.session.id), path)
        text = open(path, encoding="utf-8-sig").read()
        assert ok and "Latency (ms)" in text and "discord.exe" in text


def test_block_events_latency_and_emergency_override():
    asyncio.run(_events_and_pause())


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("PASS", name)
