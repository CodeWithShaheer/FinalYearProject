"""
ai/ai_worker.py
QThread running the full AI pipeline at high rate for responsive UI.

v2.0 — Performance:
    - Default rate raised to 15 Hz (was 6 Hz)
    - Adaptive: skips sleep if inference is already slower than target
    - Status update emitted every frame (cheap dict)
    - Violation detection unchanged (rule engine handles time windows)
"""
import logging
import time
from typing import Optional

from PyQt5.QtCore import QThread, pyqtSignal

from ai.camera import CameraCapture
from ai.detection_engine import DetectionEngine, DetectionResult
from ai.rule_engine import RuleEngine, ViolationEvent

logger = logging.getLogger(__name__)


DEFAULT_RATE_HZ = 15.0


class AIWorker(QThread):
    status_update = pyqtSignal(dict)
    violation_detected = pyqtSignal(object)
    error_occurred = pyqtSignal(str)
    started_ok = pyqtSignal()
    stopped_ok = pyqtSignal()

    def __init__(self,
                 camera_index: int = 0,
                 rate_hz: float = DEFAULT_RATE_HZ,
                 enable_yolo: bool = True,
                 yolo_frame_interval: int = 5,
                 parent=None):
        super().__init__(parent)
        self._camera_index = camera_index
        self._interval = 1.0 / max(1.0, rate_hz)
        self._enable_yolo = enable_yolo
        self._yolo_frame_interval = yolo_frame_interval

        self._running = False
        self._camera: Optional[CameraCapture] = None
        self._engine: Optional[DetectionEngine] = None
        self._rules: Optional[RuleEngine] = None

        self._last_result: Optional[DetectionResult] = None

    # ------------------------------------------------------------------
    def run(self):
        try:
            self._camera = CameraCapture(
                index=self._camera_index,
                width=640, height=480, fps=30,     # camera at 30 fps now
            )
            if not self._camera.start():
                self.error_occurred.emit("Failed to open camera")
                return

            time.sleep(0.5)

            self._engine = DetectionEngine(
                enable_yolo=self._enable_yolo,
                yolo_frame_interval=self._yolo_frame_interval,
            )

            if self._enable_yolo:
                try:
                    loaded = self._engine.load()
                    if not loaded:
                        logger.warning("YOLO not loaded — MediaPipe-only mode.")
                except Exception as e:
                    logger.warning("YOLO load crashed (%s) — MediaPipe-only.", e)

            self._rules = RuleEngine()

            self._running = True
            self.started_ok.emit()
            logger.info("AIWorker started (target %.1f Hz, YOLO=%s)",
                        1.0 / self._interval, self._enable_yolo)

            # Main loop — no forced sleep; only sleep if we finish early
            while self._running:
                t0 = time.time()

                frame = self._camera.read()
                if frame is None:
                    time.sleep(0.02)
                    continue

                try:
                    result = self._engine.detect(frame)
                except Exception as e:
                    logger.exception("Detection failed")
                    self.error_occurred.emit(f"Detection error: {e}")
                    time.sleep(0.05)
                    continue

                self._last_result = result

                # Rule engine → violations + live signals
                try:
                    events = self._rules.evaluate(result)
                except Exception:
                    logger.exception("Rule evaluation failed")
                    events = []

                for ev in events:
                    self.violation_detected.emit(ev)

                # Status update every frame
                self._emit_status(result)

                # Adaptive sleep: only if we're faster than target rate
                dt = time.time() - t0
                if dt < self._interval:
                    time.sleep(self._interval - dt)
                # else: skip sleep, keep up with camera

        except Exception as e:
            logger.exception("AIWorker crashed")
            self.error_occurred.emit(f"AI worker crashed: {e}")
        finally:
            self._cleanup()
            self.stopped_ok.emit()
            logger.info("AIWorker stopped.")

    # ------------------------------------------------------------------
    def _emit_status(self, result: DetectionResult):
        self.status_update.emit({
            "face_count": result.face_count,
            "gaze": result.gaze_direction,
            "head": result.head_direction,
            "hand_count": result.hand_count,
            "phone_suspected": result.phone_suspected,
            "yolo_phone": getattr(result, "yolo_phone_present", False),
            "yolo_phone_conf": getattr(result, "yolo_phone_conf", 0.0),
            "inference_ms": round(result.inference_ms, 1),
            "active_signals": self._rules.get_active_signals() if self._rules else {},
        })

    # ------------------------------------------------------------------
    def stop(self):
        self._running = False

    def _cleanup(self):
        try:
            if self._camera:
                self._camera.stop()
        except Exception:
            pass
        try:
            if self._engine:
                self._engine.close()
        except Exception:
            pass
        self._camera = None
        self._engine = None
        self._rules = None