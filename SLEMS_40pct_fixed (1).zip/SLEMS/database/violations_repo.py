# Violation CRUD operations.
"""
database/violations_repo.py
CRUD operations for the `violations` table.

Used in Phase 11 by the AI engine + network layer.
Defined now so schema + models are ready.
"""
import logging
from typing import List, Optional

from database.connection import db_cursor
from database.models import Violation

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# CREATE
# ---------------------------------------------------------------------------
def add_violation(
    session_id: int,
    student_id: int,
    violation_type: str,
    description: str,
    severity: str = "medium",
    synced: bool = True,
    confidence: Optional[float] = None,
) -> tuple:
    """
    Returns (ok: bool, violation: Optional[Violation], message: str).
    """
    try:
        with db_cursor(dict_cursor=True) as cur:
            cur.execute(
                """
                INSERT INTO violations
                    (session_id, student_id, violation_type, description, severity, synced, confidence)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                RETURNING *;
                """,
                (session_id, student_id, violation_type, description, severity, synced, confidence),
            )
            row = cur.fetchone()
        return True, Violation.from_row(row), "Violation recorded."
    except Exception as e:
        logger.exception("Failed to add violation")
        return False, None, f"Database error: {e}"


# ---------------------------------------------------------------------------
# READ
# ---------------------------------------------------------------------------
def get_violations_by_session(session_id: int, limit: int = 500) -> List[Violation]:
    with db_cursor(dict_cursor=True) as cur:
        cur.execute(
            """
            SELECT v.*,
                   st.full_name AS student_name,
                   st.roll_no   AS roll_no
            FROM violations v
            JOIN students st ON v.student_id = st.id
            WHERE v.session_id = %s
            ORDER BY v."timestamp" DESC
            LIMIT %s;
            """,
            (session_id, limit),
        )
        rows = cur.fetchall()
    return [Violation.from_row(r) for r in rows]


def get_all_violations(limit: int = 500) -> List[Violation]:
    with db_cursor(dict_cursor=True) as cur:
        cur.execute(
            """
            SELECT v.*,
                   st.full_name AS student_name,
                   st.roll_no   AS roll_no
            FROM violations v
            JOIN students st ON v.student_id = st.id
            ORDER BY v."timestamp" DESC
            LIMIT %s;
            """,
            (limit,),
        )
        rows = cur.fetchall()
    return [Violation.from_row(r) for r in rows]


def get_violations_by_student(session_id: int, student_id: int) -> List[Violation]:
    with db_cursor(dict_cursor=True) as cur:
        cur.execute(
            """
            SELECT v.*,
                   st.full_name AS student_name,
                   st.roll_no   AS roll_no
            FROM violations v
            JOIN students st ON v.student_id = st.id
            WHERE v.session_id = %s AND v.student_id = %s
            ORDER BY v."timestamp" DESC;
            """,
            (session_id, student_id),
        )
        rows = cur.fetchall()
    return [Violation.from_row(r) for r in rows]


def count_violations_by_session(session_id: int) -> int:
    with db_cursor() as cur:
        cur.execute(
            "SELECT COUNT(*) FROM violations WHERE session_id = %s;",
            (session_id,),
        )
        return cur.fetchone()[0]


def count_violations_by_type(session_id: int, violation_type: str) -> int:
    with db_cursor() as cur:
        cur.execute(
            "SELECT COUNT(*) FROM violations WHERE session_id = %s AND violation_type = %s;",
            (session_id, violation_type),
        )
        return cur.fetchone()[0]


# ---------------------------------------------------------------------------
# FILTER / REVIEW / EXPORT   (plan UI-003: filterable, sortable, CSV export)
# ---------------------------------------------------------------------------
def search_violations(
    session_id: Optional[int] = None,
    violation_type: Optional[str] = None,
    severity: Optional[str] = None,
    student_id: Optional[int] = None,
    include_dismissed: bool = True,
    newest_first: bool = True,
    limit: int = 1000,
) -> List[Violation]:
    """Filtered violation list.  Every filter is optional."""
    where, params = [], []
    if session_id is not None:
        where.append("v.session_id = %s"); params.append(session_id)
    if violation_type:
        where.append("v.violation_type = %s"); params.append(violation_type)
    if severity:
        where.append("v.severity = %s"); params.append(severity)
    if student_id is not None:
        where.append("v.student_id = %s"); params.append(student_id)
    if not include_dismissed:
        where.append("v.dismissed = FALSE")
    clause = ("WHERE " + " AND ".join(where)) if where else ""
    order = "DESC" if newest_first else "ASC"
    params.append(limit)
    with db_cursor(dict_cursor=True) as cur:
        cur.execute(
            f"""
            SELECT v.*, st.full_name AS student_name, st.roll_no AS roll_no
            FROM violations v
            JOIN students st ON v.student_id = st.id
            {clause}
            ORDER BY v."timestamp" {order}
            LIMIT %s;
            """,
            params,
        )
        rows = cur.fetchall()
    return [Violation.from_row(r) for r in rows]


def set_review_state(violation_id: int, reviewed: bool = True, dismissed: bool = False) -> bool:
    """Teacher marks a violation reviewed / dismissed as a false positive."""
    try:
        with db_cursor() as cur:
            cur.execute(
                "UPDATE violations SET reviewed = %s, dismissed = %s WHERE id = %s;",
                (reviewed, dismissed, violation_id),
            )
            return cur.rowcount > 0
    except Exception:
        logger.exception("set_review_state failed")
        return False


CSV_COLUMNS = ["Time", "Roll No", "Student", "Type", "Severity",
               "Description", "Confidence", "Reviewed", "Dismissed"]


def export_violations_csv(violations: List[Violation], path: str) -> tuple:
    """Write violations to a CSV file (Excel-friendly UTF-8 with BOM)."""
    import csv
    try:
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(CSV_COLUMNS)
            for v in violations:
                w.writerow([
                    v.timestamp.strftime("%Y-%m-%d %H:%M:%S") if v.timestamp else "",
                    v.roll_no, v.student_name, v.violation_type, v.severity,
                    v.description,
                    "" if v.confidence is None else f"{v.confidence:.2f}",
                    "yes" if v.reviewed else "no",
                    "yes" if v.dismissed else "no",
                ])
        return True, f"Exported {len(violations)} violation(s) to {path}"
    except OSError as e:
        return False, f"Could not write file: {e}"
