"""
database/block_events_repo.py
Timestamped log of every blocking action (S6).  This is the evidence table for the
"blocked app is killed within 2 seconds of launch" requirement.
"""
import csv
import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Optional

from database.connection import db_cursor

logger = logging.getLogger(__name__)

EVENT_TYPES = ("process_killed", "domain_blocked", "blocking_paused",
               "blocking_resumed", "client_offline", "allowlist_kill")


@dataclass
class BlockEvent:
    id: int
    session_id: int
    student_id: int
    event_type: str
    target: str
    pid: Optional[int]
    latency_ms: Optional[int]
    detail: str
    created_at: Optional[datetime]
    roll_no: str = ""
    student_name: str = ""


def add_event(session_id: int, student_id: int, event_type: str, target: str = "",
              pid: Optional[int] = None, latency_ms: Optional[int] = None,
              detail: str = "") -> tuple:
    """Returns (ok, event_id)."""
    if event_type not in EVENT_TYPES:
        return False, None
    try:
        with db_cursor() as cur:
            cur.execute(
                """INSERT INTO block_events
                       (session_id, student_id, event_type, target, pid, latency_ms, detail)
                   VALUES (%s,%s,%s,%s,%s,%s,%s) RETURNING id;""",
                (session_id, student_id, event_type, (target or "")[:255], pid,
                 None if latency_ms is None else int(latency_ms), detail or ""),
            )
            return True, cur.fetchone()[0]
    except Exception:
        logger.exception("add_event failed")
        return False, None


def get_events(session_id: Optional[int] = None, student_id: Optional[int] = None,
               event_type: Optional[str] = None, limit: int = 2000) -> List[BlockEvent]:
    where, params = [], []
    if session_id is not None:
        where.append("e.session_id = %s"); params.append(session_id)
    if student_id is not None:
        where.append("e.student_id = %s"); params.append(student_id)
    if event_type:
        where.append("e.event_type = %s"); params.append(event_type)
    clause = ("WHERE " + " AND ".join(where)) if where else ""
    params.append(limit)
    with db_cursor(dict_cursor=True) as cur:
        cur.execute(
            f"""SELECT e.*, st.roll_no, st.full_name
                FROM block_events e JOIN students st ON e.student_id = st.id
                {clause} ORDER BY e.created_at DESC, e.id DESC LIMIT %s;""",
            params,
        )
        rows = cur.fetchall()
    return [BlockEvent(r["id"], r["session_id"], r["student_id"], r["event_type"],
                       r["target"] or "", r["pid"], r["latency_ms"], r["detail"] or "",
                       r["created_at"], r["roll_no"], r["full_name"]) for r in rows]


def counts_by_student(session_id: int) -> Dict[int, Dict[str, int]]:
    """{student_pk: {'kills': n, 'events': n}} for the teacher's student table (S10)."""
    out: Dict[int, Dict[str, int]] = {}
    with db_cursor() as cur:
        cur.execute(
            """SELECT student_id,
                      COUNT(*) FILTER (WHERE event_type IN ('process_killed','allowlist_kill')),
                      COUNT(*)
               FROM block_events WHERE session_id = %s GROUP BY student_id;""",
            (session_id,),
        )
        for sid, kills, total in cur.fetchall():
            out[sid] = {"kills": kills, "events": total}
    return out


def latency_stats(session_id: Optional[int] = None) -> dict:
    """Min / average / max launch->kill latency, and how many were within 2 s."""
    where, params = "WHERE event_type = 'process_killed' AND latency_ms IS NOT NULL", []
    if session_id is not None:
        where += " AND session_id = %s"; params.append(session_id)
    with db_cursor() as cur:
        cur.execute(
            f"""SELECT COUNT(*), MIN(latency_ms), AVG(latency_ms), MAX(latency_ms),
                       COUNT(*) FILTER (WHERE latency_ms <= 2000)
                FROM block_events {where};""", params)
        n, mn, avg, mx, ok = cur.fetchone()
    return {"count": n, "min_ms": mn, "avg_ms": None if avg is None else round(float(avg)),
            "max_ms": mx, "within_2s": ok}


CSV_COLUMNS = ["Time", "Roll No", "Student", "Event", "Target", "PID", "Latency (ms)", "Detail"]


def export_csv(events: List[BlockEvent], path: str) -> tuple:
    try:
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow(CSV_COLUMNS)
            for e in events:
                w.writerow([e.created_at.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3] if e.created_at else "",
                            e.roll_no, e.student_name, e.event_type, e.target,
                            "" if e.pid is None else e.pid,
                            "" if e.latency_ms is None else e.latency_ms, e.detail])
        return True, f"Exported {len(events)} event(s) to {path}"
    except OSError as e:
        return False, f"Could not write file: {e}"
