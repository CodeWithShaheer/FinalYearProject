# Windows failure tests (S15) - run these on the real PCs before the 40% evaluation

Examiners ask "what if it crashes?"  These 7 scenarios prove the answer.
Use `python tools/windows_failure_check.py` after each one - it checks the hosts file and writes a row to
`docs/WINDOWS_TEST_LOG.csv` (attach it and a screenshot to the report).

Prepare: teacher PC + student PC, both SLEMS as Administrator, session started, student joined.
Before each scenario run `python tools/windows_failure_check.py status` (hosts should show **blocked**).

| # | Scenario | How | Expected result | Check command |
|---|---|---|---|---|
| F1 | SLEMS killed on the student PC | Task Manager -> End task on python/SLEMS | Teacher: student turns red OFFLINE + high violation. Hosts stays blocked until SLEMS is started again. On next start the stale block is removed automatically. | after kill: `... check blocked F1a`  then start SLEMS: `... check clean F1b` |
| F2 | Student PC power cut / hard reset | Hold power button, boot | Same as F1: on next SLEMS start hosts is cleaned. If the student never starts SLEMS: `python restore_hosts.py` | `... check clean F2` |
| F3 | Network cable / Wi-Fi off on student PC (60 s) | Disconnect, wait 70 s, reconnect | Teacher flags OFFLINE violation. Student side: blocking is released when the link to the teacher is lost (documented design choice). Student can rejoin with the same code. | `... check clean F3` |
| F4 | Teacher closes SLEMS / PC crashes mid-exam | Close teacher window | Every student is disconnected and unlocked (hosts clean, apps allowed). | `... check clean F4` |
| F5 | Teacher presses **End** | Session Control -> End | All students see "session ended"; hosts clean; no false violations for leaving. | `... check clean F5` |
| F6 | SLEMS started WITHOUT Administrator | Run normal (not admin) | Clear warning "not running as admin"; website blocking reports it could not apply; no crash. | `... check clean F6` |
| F7 | Blocked app relaunched repeatedly | Start Discord 10 times fast | Killed each time; Block Events log shows each kill with latency; SLEMS stays responsive. | `... check clean F7` after End |

Pass rule: a scenario passes when "Expected result" is observed **and** the check command prints PASS.
Write anything unexpected in the notes column of `WINDOWS_TEST_LOG.csv` - that is valuable report material.
