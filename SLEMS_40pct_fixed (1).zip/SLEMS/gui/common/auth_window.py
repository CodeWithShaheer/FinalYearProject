"""
gui/common/auth_window.py
Login + Signup window for SLEMS.

Uses database/users_repo.py (PostgreSQL).
Password hashing is SHA-256 (see users_repo._hash_password).

Classes exported:
    AuthInput       - styled QLineEdit
    LogoHeader      - SLEMS logo + title
    LoginPage       - Sign in form
    SignupPage      - Create account form
    AuthWindow      - QWidget host with QStackedWidget(LoginPage, SignupPage)
"""
import os
import logging

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QMessageBox, QFrame, QStackedWidget, QCheckBox,
    QComboBox,
)
from PyQt5.QtGui import QPixmap

from gui.common import theme
from database import users_repo
from utils.paths import load_logo_pixmap


logger = logging.getLogger(__name__)


# ===========================================================================
# AuthInput
# ===========================================================================
class AuthInput(QLineEdit):
    def __init__(self, placeholder: str, password: bool = False, parent=None):
        super().__init__(parent)
        self.setPlaceholderText(placeholder)
        if password:
            self.setEchoMode(QLineEdit.Password)
        self.setFixedHeight(56)
        self.setStyleSheet(f"""
            QLineEdit {{
                border: 2px solid {theme.BORDER};
                border-radius: 12px;
                padding: 10px 18px;
                font-size: 17px;
                background: {theme.CARD_BG};
                color: {theme.TEXT_PRIMARY};
            }}
            QLineEdit:focus {{
                border: 2px solid {theme.NAVY};
            }}
        """)


# ===========================================================================
# LogoHeader
# ===========================================================================
class LogoHeader(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet("background: transparent;")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(8)
        layout.setAlignment(Qt.AlignCenter)

        logo_lbl = QLabel()
        pixmap = load_logo_pixmap(380, 260)
        if pixmap is not None:
            logo_lbl.setPixmap(pixmap)
        logo_lbl.setAlignment(Qt.AlignCenter)
        layout.addWidget(logo_lbl)

        title = QLabel("SLEMS")
        title.setStyleSheet(
            f"color: {theme.NAVY_DARK}; font-size: 32px; font-weight: 800; letter-spacing: 3px;"
        )
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        subtitle = QLabel("Smart Lab Exam Monitoring System")
        subtitle.setStyleSheet(
            f"color: {theme.TEXT_SECONDARY}; font-size: 16px; font-weight: 500;"
        )
        subtitle.setAlignment(Qt.AlignCenter)
        layout.addWidget(subtitle)

        campus = QLabel("NUML - Faisalabad Campus")
        campus.setStyleSheet(
            f"color: {theme.GOLD}; font-size: 14px; font-weight: 600;"
        )
        campus.setAlignment(Qt.AlignCenter)
        layout.addWidget(campus)


# ===========================================================================
# LoginPage
# ===========================================================================
class LoginPage(QWidget):
    login_success = pyqtSignal(dict)
    goto_signup = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setAlignment(Qt.AlignCenter)
        root.setContentsMargins(40, 20, 40, 20)

        card = QFrame()
        card.setFixedWidth(540)
        card.setStyleSheet(f"""
            QFrame {{
                background: {theme.CARD_BG};
                border: 1px solid {theme.BORDER};
                border-radius: 20px;
            }}
        """)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        layout.addWidget(LogoHeader())

        form = QWidget()
        fl = QVBoxLayout(form)
        fl.setContentsMargins(40, 24, 40, 36)
        fl.setSpacing(16)

        heading = QLabel("Sign In")
        heading.setStyleSheet(f"color: {theme.NAVY_DARK}; font-size: 26px; font-weight: 700;")
        fl.addWidget(heading)

        desc = QLabel("Enter your credentials to access the dashboard.")
        desc.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 16px;")
        fl.addWidget(desc)
        fl.addSpacing(8)

        self.email_input = AuthInput("Email address")
        self.password_input = AuthInput("Password", password=True)
        fl.addWidget(self.email_input)
        fl.addWidget(self.password_input)

        row = QHBoxLayout()
        self.remember_cb = QCheckBox("Remember me")
        self.remember_cb.setStyleSheet(
            f"font-size: 15px; color: {theme.TEXT_SECONDARY};"
        )
        row.addWidget(self.remember_cb)
        row.addStretch()
        fl.addLayout(row)

        self.login_btn = QPushButton("Sign In")
        self.login_btn.setFixedHeight(56)
        self.login_btn.setStyleSheet(f"""
            QPushButton {{
                background: {theme.NAVY}; color: white;
                border: none; border-radius: 12px;
                font-size: 18px; font-weight: 700;
            }}
            QPushButton:hover {{ background: {theme.NAVY_LIGHT}; }}
        """)
        self.login_btn.setCursor(Qt.PointingHandCursor)
        self.login_btn.clicked.connect(self._do_login)
        fl.addWidget(self.login_btn)

        div = QLabel("-  or  -")
        div.setAlignment(Qt.AlignCenter)
        div.setStyleSheet(
            f"color: {theme.TEXT_SECONDARY}; font-size: 15px; padding: 8px 0;"
        )
        fl.addWidget(div)

        signup_row = QHBoxLayout()
        signup_row.setAlignment(Qt.AlignCenter)
        no_acc = QLabel("Don't have an account?")
        no_acc.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 16px;")
        signup_btn = QPushButton("Create Account")
        signup_btn.setStyleSheet(f"""
            QPushButton {{
                background: transparent; color: {theme.NAVY};
                border: none; font-size: 16px; font-weight: 700;
                text-decoration: underline;
            }}
            QPushButton:hover {{ color: {theme.GOLD}; }}
        """)
        signup_btn.setCursor(Qt.PointingHandCursor)
        signup_btn.clicked.connect(self.goto_signup.emit)
        signup_row.addWidget(no_acc)
        signup_row.addWidget(signup_btn)
        fl.addLayout(signup_row)

        layout.addWidget(form)
        root.addWidget(card, alignment=Qt.AlignCenter)

    def _do_login(self):
        email = self.email_input.text().strip()
        password = self.password_input.text().strip()
        if not email or not password:
            QMessageBox.warning(self, "Login Failed", "Please enter email and password.")
            return
        try:
            ok, user, msg = users_repo.login_user(email, password)
        except Exception as e:
            logger.exception("Login error")
            QMessageBox.critical(self, "Database Error", f"Login failed:\n{e}")
            return

        if ok:
            self.login_success.emit(user)
        else:
            QMessageBox.warning(self, "Login Failed", msg)


# ===========================================================================
# SignupPage
# ===========================================================================
class SignupPage(QWidget):
    signup_success = pyqtSignal()
    goto_login = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setAlignment(Qt.AlignCenter)
        root.setContentsMargins(40, 20, 40, 20)

        card = QFrame()
        card.setFixedWidth(540)
        card.setStyleSheet(f"""
            QFrame {{
                background: {theme.CARD_BG};
                border: 1px solid {theme.BORDER};
                border-radius: 20px;
            }}
        """)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        layout.addWidget(LogoHeader())

        form = QWidget()
        fl = QVBoxLayout(form)
        fl.setContentsMargins(40, 20, 40, 32)
        fl.setSpacing(14)

        heading = QLabel("Create Account")
        heading.setStyleSheet(f"color: {theme.NAVY_DARK}; font-size: 26px; font-weight: 700;")
        fl.addWidget(heading)

        desc = QLabel("Fill in your details to register.")
        desc.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 16px;")
        fl.addWidget(desc)
        fl.addSpacing(6)

        self.name_input = AuthInput("Full Name")
        self.email_input = AuthInput("Email address")
        self.password_input = AuthInput("Password (min 6 chars)", password=True)
        self.confirm_input = AuthInput("Confirm Password", password=True)

        fl.addWidget(self.name_input)
        fl.addWidget(self.email_input)
        fl.addWidget(self.password_input)
        fl.addWidget(self.confirm_input)

        role_row = QHBoxLayout()
        self.role_combo = QComboBox()
        self.role_combo.addItems(["Teacher / Invigilator", "Admin", "Student"])
        self.role_combo.setStyleSheet(f"""
            QComboBox {{
                border: 2px solid {theme.BORDER};
                border-radius: 12px;
                padding: 10px 14px;
                font-size: 16px;
                background: {theme.CARD_BG};
                min-height: 44px;
            }}
        """)
        role_lbl = QLabel("Role:")
        role_lbl.setStyleSheet(f"color: {theme.TEXT_PRIMARY}; font-size: 15px; font-weight: 600;")
        role_row.addWidget(role_lbl)
        role_row.addWidget(self.role_combo)
        role_row.addStretch()
        fl.addLayout(role_row)

        # teacher / admin sign-up key (hidden for students)
        self.key_input = AuthInput("Teacher sign-up key (given by your administrator)", password=True)
        fl.addWidget(self.key_input)
        self.role_combo.currentIndexChanged.connect(self._on_role_changed)
        self._on_role_changed()

        self.signup_btn = QPushButton("Create Account")
        self.signup_btn.setFixedHeight(56)
        self.signup_btn.setStyleSheet(f"""
            QPushButton {{
                background: {theme.GOLD}; color: {theme.NAVY_DARK};
                border: none; border-radius: 12px;
                font-size: 18px; font-weight: 700;
            }}
            QPushButton:hover {{ background: {theme.GOLD_LIGHT}; }}
        """)
        self.signup_btn.setCursor(Qt.PointingHandCursor)
        self.signup_btn.clicked.connect(self._do_signup)
        fl.addWidget(self.signup_btn)

        div = QLabel("-  or  -")
        div.setAlignment(Qt.AlignCenter)
        div.setStyleSheet(
            f"color: {theme.TEXT_SECONDARY}; font-size: 15px; padding: 6px 0;"
        )
        fl.addWidget(div)

        login_row = QHBoxLayout()
        login_row.setAlignment(Qt.AlignCenter)
        have_acc = QLabel("Already have an account?")
        have_acc.setStyleSheet(f"color: {theme.TEXT_SECONDARY}; font-size: 16px;")
        login_btn = QPushButton("Sign In")
        login_btn.setStyleSheet(f"""
            QPushButton {{
                background: transparent; color: {theme.NAVY};
                border: none; font-size: 16px; font-weight: 700;
                text-decoration: underline;
            }}
            QPushButton:hover {{ color: {theme.GOLD}; }}
        """)
        login_btn.setCursor(Qt.PointingHandCursor)
        login_btn.clicked.connect(self.goto_login.emit)
        login_row.addWidget(have_acc)
        login_row.addWidget(login_btn)
        fl.addLayout(login_row)

        layout.addWidget(form)
        root.addWidget(card, alignment=Qt.AlignCenter)

    def _on_role_changed(self):
        """The key is only needed for Teacher / Admin."""
        self.key_input.setVisible(self.role_combo.currentIndex() in (0, 1))

    def _do_signup(self):
        name = self.name_input.text().strip()
        email = self.email_input.text().strip()
        pwd = self.password_input.text().strip()
        confirm = self.confirm_input.text().strip()

        if pwd != confirm:
            QMessageBox.warning(self, "Password Mismatch", "Passwords do not match.")
            return

        role_map = {0: "teacher", 1: "admin", 2: "student"}
        role = role_map.get(self.role_combo.currentIndex(), "teacher")

        try:
            ok, msg = users_repo.register_user(name, email, pwd, role=role,
                                               signup_key=self.key_input.text())
        except Exception as e:
            logger.exception("Signup error")
            QMessageBox.critical(self, "Database Error", f"Signup failed:\n{e}")
            return

        if ok:
            QMessageBox.information(self, "Success", msg)
            self.signup_success.emit()
        else:
            QMessageBox.warning(self, "Registration Failed", msg)


# ===========================================================================
# AuthWindow  (host)
# ===========================================================================
class AuthWindow(QWidget):
    """
    Hosts LoginPage + SignupPage in a QStackedWidget.
    Emits `authenticated(user_dict)` on successful login.
    """
    authenticated = pyqtSignal(dict)

    def __init__(self):
        super().__init__()
        self.setWindowTitle("SLEMS - Login")
        self.resize(1080, 920)
        self.setStyleSheet(f"background: {theme.BG};")

        self.stack = QStackedWidget(self)
        self.login_page = LoginPage()
        self.signup_page = SignupPage()

        self.login_page.goto_signup.connect(self._show_signup)
        self.login_page.login_success.connect(self._on_login)
        self.signup_page.goto_login.connect(self._show_login)
        self.signup_page.signup_success.connect(self._show_login)

        self.stack.addWidget(self.login_page)
        self.stack.addWidget(self.signup_page)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.stack)

    def _show_login(self):
        self.setWindowTitle("SLEMS - Sign In")
        self.stack.setCurrentIndex(0)

    def _show_signup(self):
        self.setWindowTitle("SLEMS - Sign Up")
        self.stack.setCurrentIndex(1)

    def _on_login(self, user: dict):
        self.authenticated.emit(user)