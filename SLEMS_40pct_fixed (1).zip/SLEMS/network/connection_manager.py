# Tracks connected students.
"""
network/connection_manager.py
Thread-safe registry of live student connections.

Each student gets a `StudentConnection` object that owns:
    - its asyncio StreamWriter
    - its reader task
    - metadata (roll_no, session_id, student_db_id, ip, token)
    - heartbeat timestamp
"""
import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from network import protocol as P

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Per-student connection object
# ---------------------------------------------------------------------------
@dataclass
class StudentConnection:
    token: str
    reader: asyncio.StreamReader
    writer: asyncio.StreamWriter
    session_id: int
    student_db_id: int
    student_id: str
    roll_no: str
    full_name: str = ""
    ip_address: str = ""
    connected_at: float = field(default_factory=time.time)
    last_heartbeat: float = field(default_factory=time.time)
    reader_task: Optional[asyncio.Task] = None
    status: str = "connected"   # connected / reconnecting / offline
    left_gracefully: bool = False   # student sent DISCONNECT (logout / closed app)
    blocking_paused: bool = False   # teacher emergency override active

    # ------------------------------------------------------------------
    async def send(self, frame: bytes) -> bool:
        """
        Write a framed message to this student.
        Returns True on success, False if the socket is closed.
        """
        if self.writer.is_closing():
            return False
        try:
            self.writer.write(frame)
            await self.writer.drain()
            return True
        except (ConnectionError, OSError) as e:
            logger.warning("Send failed to %s: %s", self.roll_no or self.token[:8], e)
            return False

    async def close(self):
        """Close the underlying connection."""
        try:
            if not self.writer.is_closing():
                self.writer.close()
                try:
                    await self.writer.wait_closed()
                except (ConnectionError, OSError):
                    pass
        except Exception:
            logger.exception("Error closing writer")

    def touch(self):
        """Update last_heartbeat to now."""
        self.last_heartbeat = time.time()

    def idle_seconds(self) -> float:
        return time.time() - self.last_heartbeat


# ---------------------------------------------------------------------------
# Connection manager
# ---------------------------------------------------------------------------
class ConnectionManager:
    """
    Tracks all live StudentConnection objects.
    Keyed by session_token (unique per student join).
    Also indexed by roll_no for quick lookup.
    """

    def __init__(self):
        self._by_token: Dict[str, StudentConnection] = {}
        self._by_roll: Dict[str, StudentConnection] = {}
        self._lock = asyncio.Lock()

    # ---------- add / remove ----------
    async def add(self, conn: StudentConnection) -> None:
        async with self._lock:
            self._by_token[conn.token] = conn
            if conn.roll_no:
                self._by_roll[conn.roll_no] = conn
            logger.info(
                "Student connected: roll=%s session=%s ip=%s (total=%d)",
                conn.roll_no, conn.session_id, conn.ip_address, len(self._by_token),
            )

    async def remove(self, token: str) -> Optional[StudentConnection]:
        async with self._lock:
            conn = self._by_token.pop(token, None)
            if conn and conn.roll_no:
                self._by_roll.pop(conn.roll_no, None)
            if conn:
                logger.info(
                    "Student disconnected: roll=%s (remaining=%d)",
                    conn.roll_no, len(self._by_token),
                )
            return conn

    # ---------- lookup ----------
    def get(self, token: str) -> Optional[StudentConnection]:
        return self._by_token.get(token)

    def get_by_roll(self, roll_no: str) -> Optional[StudentConnection]:
        return self._by_roll.get(roll_no)

    def has_token(self, token: str) -> bool:
        return token in self._by_token

    def has_roll(self, roll_no: str) -> bool:
        return roll_no in self._by_roll

    # ---------- enumeration ----------
    def all_connections(self) -> List[StudentConnection]:
        return list(self._by_token.values())

    def count(self) -> int:
        return len(self._by_token)

    def count_by_session(self, session_id: int) -> int:
        return sum(1 for c in self._by_token.values() if c.session_id == session_id)

    def tokens(self) -> List[str]:
        return list(self._by_token.keys())

    # ---------- broadcast ----------
    async def broadcast(self, frame: bytes, session_id: Optional[int] = None) -> int:
        """
        Send a frame to all connections (optionally filtered by session).
        Returns number of successful sends.
        """
        sent = 0
        for conn in list(self._by_token.values()):
            if session_id is not None and conn.session_id != session_id:
                continue
            if await conn.send(frame):
                sent += 1
        return sent

    # ---------- heartbeat cleanup ----------
    async def find_stale(self, timeout_seconds: float) -> List[StudentConnection]:
        """Return connections whose last_heartbeat is older than timeout."""
        now = time.time()
        return [
            c for c in self._by_token.values()
            if (now - c.last_heartbeat) > timeout_seconds
        ]

    async def close_all(self) -> None:
        """Close all connections (called on server shutdown)."""
        for conn in list(self._by_token.values()):
            try:
                await conn.close()
            except Exception:
                logger.exception("Error closing connection %s", conn.token[:8])
        async with self._lock:
            self._by_token.clear()
            self._by_roll.clear()
        logger.info("All connections closed.")