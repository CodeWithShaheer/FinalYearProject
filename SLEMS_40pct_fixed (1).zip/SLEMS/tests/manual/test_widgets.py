import sys, pathlib; sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))  # run from anywhere
# test_widgets.py  (temporary — delete after testing)
import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QFrame, QLabel

# ✅ FIXED: theme is inside gui.common
from gui.common import theme
from gui.common.widgets import (
    SectionHeader, ReadinessChip, SecurityOptionRow,
    SearchableCheckList, TimerBox, FileUploadRow, AddCourseDialog,
)


def main():
    app = QApplication(sys.argv)
    app.setStyleSheet(theme.build_stylesheet())

    win = QWidget()
    win.setWindowTitle("Widgets Test — SLEMS v2.0")
    win.resize(1000, 700)
    win.setStyleSheet(f"background: {theme.BG};")

    root = QVBoxLayout(win)
    root.setContentsMargins(28, 24, 28, 28)
    root.setSpacing(20)

    # Section Headers
    root.addWidget(SectionHeader(1, "Exam Details"))
    root.addWidget(SectionHeader(2, "Security & Restrictions"))
    root.addWidget(SectionHeader(3, "Session Readiness"))
    root.addWidget(SectionHeader(4, "Session History"))

    # Readiness chips
    chip_row = QHBoxLayout()
    for label, ok in [("Course selected", True), ("Duration configured", True),
                      ("Exam paper uploaded", False), ("Restrictions configured", False),
                      ("Students registered", False)]:
        chip_row.addWidget(ReadinessChip(label, ok))
    chip_row.addStretch()
    root.addLayout(chip_row)

    # Searchable lists
    lists_row = QHBoxLayout()
    apps_list = SearchableCheckList(
        ["ChatGPT", "WhatsApp", "Discord", "Telegram", "Skype", "Zoom",
         "AnyDesk", "Claude", "Gemini", "Perplexity"],
        default_checked=["ChatGPT", "WhatsApp", "Discord"],
    )
    apps_frame = QFrame()
    apps_frame.setStyleSheet(f"QFrame {{ background: {theme.CARD_BG}; border: 1px solid {theme.BORDER}; border-radius: 12px; }}")
    apps_layout = QVBoxLayout(apps_frame)
    apps_layout.setContentsMargins(14, 12, 14, 12)
    apps_layout.addWidget(QLabel("Blocked Applications"))
    apps_layout.addWidget(apps_list)
    lists_row.addWidget(apps_frame, stretch=1)

    domains_list = SearchableCheckList(
        ["chatgpt.com", "chat.openai.com", "stackoverflow.com", "quora.com",
         "chegg.com", "coursehero.com", "gemini.google.com", "claude.ai"],
        default_checked=["chatgpt.com", "chat.openai.com"],
    )
    domains_frame = QFrame()
    domains_frame.setStyleSheet(f"QFrame {{ background: {theme.CARD_BG}; border: 1px solid {theme.BORDER}; border-radius: 12px; }}")
    domains_layout = QVBoxLayout(domains_frame)
    domains_layout.setContentsMargins(14, 12, 14, 12)
    domains_layout.addWidget(QLabel("Blocked Websites"))
    domains_layout.addWidget(domains_list)
    lists_row.addWidget(domains_frame, stretch=1)
    root.addLayout(lists_row)

    # Security options
    sec_frame = QFrame()
    sec_frame.setStyleSheet(f"QFrame {{ background: {theme.CARD_BG}; border: 1px solid {theme.BORDER}; border-radius: 12px; }}")
    sec_layout = QVBoxLayout(sec_frame)
    sec_layout.setContentsMargins(14, 12, 14, 12)
    sec_layout.addWidget(QLabel("Security Options"))
    sec_layout.addWidget(SecurityOptionRow("block_apps", "Block unauthorized applications", True))
    sec_layout.addWidget(SecurityOptionRow("block_sites", "Block restricted websites", True))
    sec_layout.addWidget(SecurityOptionRow("monitor_screens", "Monitor student screens", True))
    sec_layout.addWidget(SecurityOptionRow("detect_sus", "Detect suspicious behavior", True))
    sec_layout.addWidget(SecurityOptionRow("monitor_conn", "Monitor student connection", True))
    sec_layout.addWidget(SecurityOptionRow("kiosk", "Enable exam kiosk mode", False))
    root.addWidget(sec_frame)

    # Timer box + File upload row
    bottom_row = QHBoxLayout()
    timer = TimerBox()
    timer.set_time(4413)  # 01:13:33
    bottom_row.addWidget(timer)

    file_row = FileUploadRow()
    bottom_row.addWidget(file_row, stretch=1)
    root.addLayout(bottom_row)

    root.addStretch()

    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()