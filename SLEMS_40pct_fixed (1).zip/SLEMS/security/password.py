"""
security/password.py
Password hashing.

* New passwords: bcrypt (as required by the project plan, Module 1).
* If the `bcrypt` package is missing, falls back to salted PBKDF2-SHA256 from the
  standard library (still salted + slow, never plain/unsalted SHA-256).
* Old accounts created before this module existed used unsalted SHA-256
  (64 hex chars).  verify_password() still accepts them, and
  needs_rehash() tells the caller to upgrade the stored hash after a
  successful login, so no account is locked out by the change.
"""
import base64
import hashlib
import hmac
import os
import re

try:
    import bcrypt
except ImportError:                      # pragma: no cover
    bcrypt = None

_PBKDF2_ITERS = 200_000
_LEGACY_SHA256 = re.compile(r"^[0-9a-f]{64}$")


def hash_password(password: str) -> str:
    pw = (password or "").encode("utf-8")
    if bcrypt is not None:
        # bcrypt only reads the first 72 bytes; pre-hash so long passwords are fully used
        digest = base64.b64encode(hashlib.sha256(pw).digest())
        return bcrypt.hashpw(digest, bcrypt.gensalt(rounds=12)).decode("ascii")
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", pw, salt, _PBKDF2_ITERS)
    return f"pbkdf2${_PBKDF2_ITERS}${salt.hex()}${dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    pw = (password or "").encode("utf-8")
    stored = stored or ""
    try:
        if stored.startswith("$2"):
            if bcrypt is None:
                return False
            digest = base64.b64encode(hashlib.sha256(pw).digest())
            return bcrypt.checkpw(digest, stored.encode("ascii"))
        if stored.startswith("pbkdf2$"):
            _, iters, salt_hex, dk_hex = stored.split("$")
            dk = hashlib.pbkdf2_hmac("sha256", pw, bytes.fromhex(salt_hex), int(iters))
            return hmac.compare_digest(dk.hex(), dk_hex)
        if _LEGACY_SHA256.match(stored):                       # legacy accounts
            return hmac.compare_digest(hashlib.sha256(pw).hexdigest(), stored)
    except Exception:
        return False
    return False


def needs_rehash(stored: str) -> bool:
    """True for legacy SHA-256 hashes (and PBKDF2 when bcrypt is now available)."""
    stored = stored or ""
    if _LEGACY_SHA256.match(stored):
        return True
    return stored.startswith("pbkdf2$") and bcrypt is not None
