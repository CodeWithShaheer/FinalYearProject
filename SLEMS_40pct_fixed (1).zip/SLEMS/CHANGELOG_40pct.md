# SLEMS - 40% milestone changes

## Service Blocking Engine (main module)
- **Hosts file bug fixed.** Restore only ran on a clean thread exit, so a crash/kill/disconnect left domains blocked forever.
  Now: marker-delimited block, crash-recovery on every start, atexit + signal handlers, restore on session end /
  disconnect / logout / window close, retry + read-back verification, byte-exact restore of the user's own entries,
  clean backups (never of an already-blocked file, max 5 kept, stored in data/hosts_backup).
- `restore_hosts.py` now removes only SLEMS lines (the old one overwrote the whole file with the Windows default).
- Process scan no longer reads cmdline/exe of every process 3x/second (heavy on low-end PCs).
- Engine can never kill SLEMS itself or its parent processes.
- Violation is reported to the teacher immediately after the kill (before the re-scan loop).
- Engine status updates throttled 20 Hz -> 1 Hz.

## Dashboards connected
- Student file submission now really uploads to the teacher (chunked, SHA-256 verified, 20 MB limit, executables refused,
  saved to data/submissions, recorded in the DB, Reports page refreshes live). Before: saved locally only.
- Fixed the stream read limit (64 KB default) that would have dropped every upload chunk.
- Fixed "Event loop is closed" crash when reconnecting after a failed connect.

## Database
- Idempotent schema upgrade: users.failed_attempts / locked_until, violations.confidence / reviewed / dismissed,
  sessions.teacher_id, unique (session, roll_no), extra index.
- Passwords: bcrypt (was unsalted SHA-256) + 5-attempt / 5-minute lockout; old accounts upgrade automatically on login.
- Violation filter / review / CSV export functions.

## Front-end / cleanup
- connect_page.py contained the whole module twice (pasted inside a method) - fixed.
- Missing logo file no longer prints "null pixmap" errors.
- ai/gaze_detector.py was an accidental copy of detection_engine.py - rebuilt as a real GazeDetector.
- AI and P2P streaming are behind feature flags (off) and import lazily, so the app runs without mediapipe/ultralytics/aiortc.
- Removed 17 empty placeholder files and old junk (pycache, 24 old hosts backups, logs, .env).
- requirements.txt completed (psutil, bcrypt were missing); optional libs split into requirements-optional.txt.

## Tests (21 automated, all pass)
hosts manager (7), auth + DB (5), teacher<->student link incl. file upload (1), blocking engine (7), headless GUI smoke test (1).

---------------------------------------------------------------------------
# Round 2 - suggestions S1 ... S15 (all implemented)

| ID | Feature | Main files |
|---|---|---|
| S1 | Preset blocklists with explicit sub-domains (7 website groups, 5 app groups); path-style entries removed | `blocking/presets.py`, `config/settings.py`, Session Control preset buttons |
| S2 | IPv6 `:: host` line next to every `0.0.0.0 host` line | `blocking/hosts_manager.py` |
| S3 | Student closes / crashes SLEMS or loses network mid-exam -> red OFFLINE + high violation + event | `network/teacher_server.py`, `gui/teacher/live_monitor.py` |
| S4 | Emergency pause / resume per student (right-click), every override in the audit log | `blocking/blocking_engine.py`, `network/teacher_server.py`, `database/audit_repo.py` |
| S5 | Allow-list mode (only windowed apps are touched; system, SLEMS and parents protected; empty list refused) | `blocking/allowlist.py` |
| S6 | Every kill / block stored with timestamp and launch->kill latency; stats + CSV export | `database/block_events_repo.py`, `gui/teacher/violation_log.py` |
| S7 | Random 6-digit join code (was the guessable session id) + 10-wrong-codes lockout | `database/sessions_repo.py`, `network/teacher_server.py` |
| S8 | Roster import / paste; "only registered students may join" | `database/students_repo.py`, Session Control |
| S9 | Teacher / admin sign-up needs `TEACHER_SIGNUP_KEY`; unknown role -> student screen | `database/users_repo.py`, `gui/common/auth_window.py`, `main.py` |
| S10 | Live Monitor table view: status, blocks, violations, last seen | `gui/teacher/live_monitor.py` |
| S11 | Real logo (navy/gold shield) replaces the 0-byte file - replace with the official NUML logo if you have it | `assets/images/slemslogo.png` |
| S12 | Time zero: teacher side ends the session by itself, student side auto-submits the selected file | `gui/teacher/session_control.py`, `gui/student/dashboard.py` |
| S13 | Test matrix generated from the real test run | `tools/make_test_matrix.py`, `docs/TEST_MATRIX.*` |
| S14 | 5-minute demo script | `docs/DEMO_SCRIPT.md` |
| S15 | Windows failure-test procedure + checker | `docs/WINDOWS_FAILURE_TESTS.md`, `tools/windows_failure_check.py` |

## Bugs found while building round 2
- **End Session did not unlock students.** The button on Session Control only updated the database; students were
  told only when the teacher closed the whole app. Now it broadcasts SESSION_END and writes the audit log.
- Teacher countdown was reset to 0 right after being computed (timer wrong after restarting the teacher app).
- Violation Log CSV export broke on descriptions containing quotes; it had no filters or sorting.
- "github.com/copilot" and "bing.com/chat" in the website list silently blocked ALL of github.com / bing.com.
- Anyone could register themselves as Teacher or Admin from the sign-up screen.
- 6 new database objects: `sessions.join_code`, tables `block_events` and `audit_log` (9 tables in total).
